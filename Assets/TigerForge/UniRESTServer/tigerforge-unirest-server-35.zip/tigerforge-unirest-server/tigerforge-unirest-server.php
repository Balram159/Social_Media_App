<?php

/**
* Plugin Name: TigerForge UniREST Server
* Plugin URI: http://tigerforge.altervista.org/docs/unirest-1-0/
* Description: TigerForge - UniREST Server Application
* Version: 3.5
* Author: TigerForge
* Author URI: http://tigerforge.altervista.org/
* License: GPL2
*/

$__URS_VERSION__ = "35";

// =============================================================

function tf_enqueue_script()
{   
	$uri = plugin_dir_url(__FILE__);
	
	$screen = get_current_screen();
	if (strpos($screen->base, "tf-application-page") !== false) {

		// PLUGINS CSS
		$css = array(
			"font-awesome/css/all.min.css",
			"jquery/jquery-ui.min.css",
			"angularjs/angular-toastr.min.css",
			"sweetalert/sweet-alert.css"
		);
		for ($i = 0; $i < count($css); $i++) wp_enqueue_style("style-$i", $uri . "plugins/" . $css[$i]);
		wp_enqueue_style("style-main", $uri . "style.css");
		wp_enqueue_style("style-opensans", "https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&display=swap");
	
		// PLUGINS JS
		$js = array(
			"jquery/jquery-3.2.1.min.js",
			"jquery/jquery-ui.min.js",
			"angularjs/angular.min.js",
			"angularjs/angular-animate.min.js",
			"angularjs/angular-touch.min.js",
			"angularjs/angular-route.min.js",
			"angularjs/angular-toastr.tpls.min.js",
			"angularjs/angular-sanitize.js",
			"sweetalert/sweet-alert.min.js",
			"sweetalert/SweetAlert.js",
			"ace/ace.js",
		);
		for ($i = 0; $i < count($js); $i++) wp_enqueue_script("sstart-plugins-$i", $uri . "plugins/" . $js[$i], array(), '1.0', false);

		// APPLICATION
		$js = array(
			"app.js",
			"core.js",
			"controllers/login.js",
			"controllers/main.js",
			"controllers/db.js",
			"controllers/api.js",
			"controllers/files.js"
		);
		for ($i = 0; $i < count($js); $i++) wp_enqueue_script("sstart-$i", $uri . "app/" . $js[$i], array(), '1.0', false);
		
	}

}
add_action('admin_enqueue_scripts', 'tf_enqueue_script');

function tf_menu() {
	$myIcon = "data:image/svg+xml;base64," . base64_encode('<svg width="32" height="32" viewBox="0 0 280 280" xmlns="http://www.w3.org/2000/svg"><path fill="black" d="M256.57,75.26v-1.28h-0.67C233.25,31.49,188.48,2.5,137.06,2.5C62.86,2.5,2.5,62.86,2.5,137.06c0,74.2,60.36,134.56,134.56,134.56c74.2,0,134.56-60.36,134.56-134.56C271.63,114.8,266.19,93.78,256.57,75.26z M137.06,27.5c36.95,0,69.68,18.39,89.54,46.49h-68.65h-3.49H47.53C67.38,45.89,100.12,27.5,137.06,27.5z M240.71,101.55c2.89,8.42,4.79,17.31,5.54,26.51h-55.24v-26.51H240.71z M137.06,246.63c-60.41,0-109.56-49.15-109.56-109.56c0-12.43,2.08-24.37,5.91-35.51H76.7v114.94h36.75V101.55h41.01v114.94h36.56v-60.87h54.03C236.21,207.23,191.15,246.63,137.06,246.63z"/></svg>');
	add_menu_page('TigerForge - UniREST Server', 'UniREST Server', 'administrator', 'tf-application-page', 'tf_application_page', $myIcon, 3);
}
add_action('admin_menu', 'tf_menu');

function tf_application_page() {
	?>

    <script>
		var WP_PLUGIN_URL = "../wp-content/plugins/tigerforge-unirest-server/views/";
		var WP_API_ID = "";
		var WP_HAS_PERMALINK = <?=(get_option( 'permalink_structure' )) ? "true" : "false"?>;
    </script>

    <div ng-app="UniREST" class="unirest_plugin_body">
        <div ng-view></div>
	</div>

    <?php

}

function my_enqueue($hook) {
    if ('plugins.php' !== $hook) return;
    wp_enqueue_script('my_custom_script', plugin_dir_url(__FILE__) . "/tigerforge-unirest-server.js");
}

add_action('admin_enqueue_scripts', 'my_enqueue');

// REST API
include("api/db-helpers.php");
include("api/rest-api.php");

// PLUGIN UPDATE ENGINE
$this_file = __FILE__;
$update_check = "https://www.stevenworks.com/unirestserver/plugin/unirestserver.chk";
require_once('gill-updates.php');

?>