'use strict';

app.factory('$core', ['$http', '$q', 'SweetAlert', 'toastr', '$location', '$sce',
	function ($http, $q, SweetAlert, toastr, $location, $sce) {

		var f = {};
		var APIurl = "../wp-json/api/v2/";

		f.version = "3.5";

		f.data = { giorno: null, mese: null, anno: null };

		f.loggedIn = false;

		f.USER = { token: "" };

		// ========================================================================================
		// ========================================================================================

		// Restituisce l'elenco delle tabelle del DB e i nomi delle loro colonne.

		f.getTablesStructure = function () {

			var def = $q.defer();

			f.post("unirest/tablelist", { action: "ALL" }).then(function (response) {

				if (typeof response.list === "undefined") {
					f.say("INIT", "An error occurred accessing to your DB data.", "error");
					def.reject("KO");
				}

				var tablesList = response.list.map(function (item) { return item.replace("tfur_", ""); });
				var tableCols = response.tableCols;

				def.resolve({ tablesList: tablesList, tableCols: tableCols });

			}, function (response) {
				f.say("INIT", "An error occurred loading your APIs.", "error");
				def.reject("KO");
			});

			return def.promise;

		}

		// Restituisce i dati delle API.

		f.getAPIs = function () {

			var def = $q.defer();

			f.post("unirest/apimanage", { action: "LOAD", group: [], delete: [] }).then(function (response) {

				if (response.data.length == 0) def.reject("");
				var list = f.parser(response.data);
				list.sort((a,b) => (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0))
				def.resolve(list);

			}, function (response) {
				f.say("LOAD API", "An error occurred loading your APIs.", "error");
				def.reject("KO");
			});

			return def.promise;

		}

		f.parser = function (fileContent) {

			var parsed = [];
			var groups = [];

			for (var i = 0; i < fileContent.length; i++) {

				var row = fileContent[i];

				if (row.indexOf("//[UNIREST_API]") >= 0) {

					var tmp = row.replace("//[UNIREST_API]|", "").split("/");
					var groupName = tmp[0];
					var apiName = tmp[1];

					var desc = fileContent[i + 1].replace("//", "");

					var data = {};
					data.table = getStringValue(fileContent[i + 4]).replace("tfur_", "");
					data.hasR = getStringValue(fileContent[i + 5]);
					data.hasW = getStringValue(fileContent[i + 6]);
					data.hasU = getStringValue(fileContent[i + 7]);
					data.hasD = getStringValue(fileContent[i + 8]);
					data.hasC = getStringValue(fileContent[i + 9]);
					data.read_type = getStringValue(fileContent[i + 10]);
					data.read_select = getStringValue(fileContent[i + 11]).split(" ");
					data.read_where = getStringValue(fileContent[i + 12]).split(" ");
					data.read_orderby = getOrderBy(fileContent[i + 13], true);
					data.read_custom_query = getStringValue(fileContent[i + 14]);
					data.write_fields = getStringValue(fileContent[i + 15]).split(" ");
					data.write_custom_query = getStringValue(fileContent[i + 16]);
					data.update_dynamic = getStringValue(fileContent[i + 17]);
					data.update_canWrite = getStringValue(fileContent[i + 18]);
					data.update_fields = getStringValue(fileContent[i + 19]).split(" ");
					data.update_where = getStringValue(fileContent[i + 20]).split(" ");
					data.update_custom_query = getStringValue(fileContent[i + 21]);
					data.delete_where = getStringValue(fileContent[i + 22]).split(" ");
					data.delete_custom_query = getStringValue(fileContent[i + 23]);

					parsed.push({
						group: groupName,
						name: apiName,
						desc: desc,
						api: data
					});

					if (groups.indexOf(groupName) < 0) groups.push(groupName);

				}

			}

			var data = [];
			for (var i = 0; i < groups.length; i++) {
				data.push({
					name: groups[i],
					APIfields: parsed.filter(function (item) { return item.group == groups[i]; }),
					locked: true,
					id: UTILS.randomString(10)
				});
			}

			return data;

		}

		function getStringValue(row) {

			row = row.replace('$unirest_db["', "").replace('"] = ', "|");

			var tmp = row.split("|");
			var value = tmp[1].trim();
			value = value.substr(0, value.length - 1);
			if (value.substr(0, 1) == '"') value = value.substr(1);
			if (value.substr(-1) == '"') value = value.substr(0, value.length - 1);
			return value;
		}

		function getOrderBy(orderby, extract) {

			if (extract) orderby = getStringValue(orderby);

			var data = { by: "", dir: "" };
			if (orderby == "") return data;

			data.dir = (orderby.indexOf(" ASC") > 0) ? "ASC" : "DESC";
			data.by = orderby.replace(" ASC", "").replace(" DESC", "").replace("ORDER BY", "").trim();

			return data;

		}

		f.newGroup = function () {
			return { name: "<New API Group>", reserved: false, APIs: [], locked: false, id: UTILS.randomString(10) };
		}

		f.newAPI = function (tablesList, lastIndex) {
			return {
				name: "<New API>",
				desc: "",
				skills: {
					R: false,
					W: false,
					U: false,
					D: false,
					C: false
				},
				tables: tablesList,
				selectedTable: "",
				menu: {
					R: ["Read", "None", "Key"],
					W: ["Write", "None"],
					U: ["Update", "None", "Key"],
					D: ["None", "Key"],
				},
				update: {
					canWrite: false,
					dynamic: false,
					useID: false
				},
				read: {
					useID: false,
					one: false,
					orderby: "None",
					orderdir: "ASC"
				},
				delete: {
					useID: false
				},
				custom: {
					R: "",
					W: "",
					U: "",
					D: ""
				},
				i: lastIndex,
				locked: false
			};
		}

		f.getGroupAPIsList = function (group, tablesList) {

			var APIs = [];

			for (var i = 0; i < group.APIfields.length; i++) {

				var g = group.APIfields[i];
				var fields = g.api;

				APIs.push({
					name: g.name,
					desc: g.desc,
					skills: {
						R: fields.hasR == "true",
						W: fields.hasW == "true",
						U: fields.hasU == "true",
						D: fields.hasD == "true",
						C: fields.hasC == "true"
					},
					tables: tablesList,
					selectedTable: fields.table,
					menu: {
						R: ["Read", "None", "Key"],
						W: ["Write", "None"],
						U: ["Update", "None", "Key"],
						D: ["None", "Key"],
					},
					update: {
						canWrite: fields.update_canWrite == "true",
						dynamic: fields.update_dynamic == "true",
						useID: fields.update_where.indexOf("id") >= 0
					},
					read: {
						useID: fields.read_where.indexOf("id") >= 0,
						one: fields.read_type == "ONE",
						orderby: (fields.read_orderby.by == "") ? "None" : fields.read_orderby.by,
						orderdir: (fields.read_orderby.dir == "") ? "ASC" : fields.read_orderby.dir
					},
					delete: {
						useID: fields.delete_where.indexOf("id") >= 0
					},
					custom: {
						R: fields.read_custom_query,
						W: fields.write_custom_query,
						U: fields.update_custom_query,
						D: fields.delete_custom_query
					},
					i: APIs.length,
					locked: true
				});

			}

			return APIs;

		}

		// ========================================================================================
		// ========================================================================================

		f.DB_tablesList = function () {
			var def = $q.defer();

			f.post("unirest/tablelist", { action: "LIST" }).then(function (response) {

				var reserved = "tfur_users";
				var tables = [];

				for (var i = 0; i < response.list.length; i++) {
					tables.push({
						name: response.list[i].replace("tfur_", ""),
						fullname: response.list[i],
						reserved: reserved.indexOf(response.list[i]) >= 0
					});
				}

				tables.sort((a,b) => (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0))

				def.resolve(tables);

			}, function (response) {
				def.reject("KO");
			});

			return def.promise;
		}

		// ========================================================================================
		// ========================================================================================

		// Effettua una chiamata API e restituisce il risultato della chiamata.
		f.post = function (path, params) {

			var def = $q.defer();
			var url = APIurl + path;

			$http.post(url, JSON.stringify(params), { headers: f.USER }).then(
				function (response) {

					if (typeof response.data === 'object' && response.data !== null) {
						def.resolve(response.data);
					} else {
						if (response.data == null) {
							def.resolve(null);
						} else {
							if (response.data.indexOf("{") > 0) {
								var data = response.data.substr(response.data.indexOf("{"));
								data = data.substr(0, data.lastIndexOf("}") + 1);
								var json = JSON.parse(data);
								def.resolve(json);
							} else {
								def.resolve(null);
							}
						}
					}

				},
				function (response) {
					var link = document.createElement("a");
					link.href = url;
					response.identifiedURL = link.href;
					def.reject(response);
				});

			return def.promise;

		}

		// ========================================================================================
		// ========================================================================================

		// Chiavi MySQL riservate che non possono essere usate nei nomi di colonna.
		f.columnNameIsReserved = function (columns) {

			var notValid = [
				"ADD", "ELSE", "LOCK", "SONAME",
				"ALL", "ENCLOSED", "LONG", "SPATIAL",
				"ALTER", "ERRORS", "LONGBLOB", "SQL_BIG_RESULT",
				"ANALYZE", "ESCAPED", "LONGTEXT", "SQL_CALC_FOUND_ROWS",
				"AND", "EXISTS", "LOW_PRIORITY", "SQL_SMALL_RESULT",
				"AS", "EXPLAIN", "MASTER_SERVER_ID", "SSL",
				"ASC", "FALSE", "MATCH", "STARTING",
				"AUTO_INCREMENT", "FIELDS", "MEDIUMBLOB", "STRAIGHT_JOIN",
				"BDB", "FLOAT", "MEDIUMINT", "STRIPED",
				"BERKELEYDB", "FOR", "MEDIUMTEXT", "TABLE",
				"BETWEEN", "FORCE", "MIDDLEINT", "TABLES",
				"BIGINT", "FOREIGN", "MINUTE_SECOND", "TERMINATED",
				"BINARY", "FROM", "MOD", "THEN",
				"BLOB", "FULLTEXT", "MRG_MYISAM", "TINYBLOB",
				"BOTH", "FUNCTION", "NATURAL", "TINYINT",
				"BTREE", "GEOMETRY", "NOT", "TINYTEXT",
				"BY", "GRANT", "NULL", "TO",
				"CASCADE", "GROUP", "NUMERIC", "TRAILING",
				"CASE", "HASH", "ON", "TRUE",
				"CHANGE", "HAVING", "OPTIMIZE", "TYPES",
				"CHAR", "HELP", "OPTION", "UNION",
				"CHARACTER", "HIGH_PRIORITY", "OPTIONALLY", "UNIQUE",
				"CHECK", "HOUR_MINUTE", "OR", "UNLOCK",
				"COLLATE", "HOUR_SECOND", "ORDER", "UNSIGNED",
				"COLUMN", "IF", "OUTER", "UPDATE",
				"COLUMNS", "IGNORE", "OUTFILE", "USAGE",
				"CONSTRAINT", "IN", "PRECISION", "USE",
				"CREATE", "INDEX", "PRIMARY", "USER_RESOURCES",
				"CROSS", "INFILE", "PRIVILEGES", "USING",
				"CURRENT_DATE", "INNER", "PROCEDURE", "VALUES",
				"CURRENT_TIME", "INNODB", "PURGE", "VARBINARY",
				"CURRENT_TIMESTAMP", "INSERT", "READ", "VARCHAR",
				"DATABASE", "INT", "REAL", "VARCHARACTER",
				"DATABASES", "INTEGER", "REFERENCES", "VARYING",
				"DAY_HOUR", "INTERVAL", "REGEXP", "WARNINGS",
				"DAY_MINUTE", "INTO", "RENAME", "WHEN",
				"DAY_SECOND", "IS", "REPLACE", "WHERE",
				"DEC", "JOIN", "REQUIRE", "WITH",
				"DECIMAL", "KEY", "RESTRICT", "WRITE",
				"DEFAULT", "KEYS", "RETURNS", "XOR",
				"DELAYED", "KILL", "REVOKE", "YEAR_MONTH",
				"DELETE", "LEADING", "RIGHT", "ZEROFILL",
				"DESC", "LEFT", "RLIKE",
				"DESCRIBE", "LIKE", "RTREE",
				"DISTINCT", "LIMIT", "SELECT",
				"DISTINCTROW", "LINES", "SET",
				"DIV", "LOAD", "SHOW",
				"DOUBLE", "LOCALTIME", "SMALLINT",
				"DROP", "LOCALTIMESTAMP", "SOME",
				"STRING", "BOOL"
			];

			for (var i = 0; i < columns.length; i++) {
				var colName = columns[i].name.toUpperCase().trim();
				if (notValid.indexOf(colName) >= 0) return columns[i].name;
			}

			return "";

		}

		// ========================================================================================
		// ========================================================================================

		// Alerts.
		f.say = function (titolo, messaggio, tipo) {
			var def = $q.defer();
			SweetAlert.swal({
				type: tipo,
				html: true,
				title: titolo,
				text: messaggio
			},
				function () {
					setTimeout(function () { def.resolve("OK"); }, 500);
				}
			);
			return def.promise;
		}
		f.ask = function (titolo, messaggio) {
			var def = $q.defer();
			SweetAlert.swal({
				html: true,
				title: titolo,
				text: messaggio,
				type: "warning",
				showCancelButton: true,
				confirmButtonColor: "#002e60",
				confirmButtonText: "YES",
				cancelButtonText: "NO",
				closeOnConfirm: true
			},
				function (response) {
					setTimeout(function () { def.resolve(response); }, 500);
				});
			return def.promise;
		}
		f.choose = function (titolo, messaggio, pulsante1, pulsante2) {
			var def = $q.defer();
			SweetAlert.swal({
				html: true,
				title: titolo,
				text: messaggio,
				type: "warning",
				showCancelButton: true,
				confirmButtonColor: "#002e60",
				confirmButtonText: pulsante1,
				cancelButtonText: pulsante2,
				closeOnConfirm: true,
				closeOnCancel: true
			},
				function (isConfirm) {
					if (isConfirm) {
						setTimeout(function () { def.resolve(1); }, 500);
					} else {
						setTimeout(function () { def.resolve(2); }, 500);
					}
				});
			return def.promise;
		}

		f.pop = function (titolo, messaggio, tipo) {

			switch (tipo) {
				case "OK":
					toastr.success(messaggio, titolo);
					break;
				case "INFO":
					toastr.info(messaggio, titolo);
					break;
				case "ERROR":
					toastr.error(messaggio, titolo);
					break;
				case "WARN":
					toastr.warning(messaggio, titolo);
					break;

				default:
					break;
			}

		}

		f.go = function (path) {
			$location.path("/" + path);
		}

		f.currentPath = function () {
			return $location.path();
		}

		f.currentPathIs = function (path) {
			return $location.path() == "/" + path;
		}

		f.notAppRoot = function () {
			return $location.path() != "/";
		}

		f.checkLogin = function () {
			if (!f.loggedIn) { f.go("/"); return; }
		}

		f.hideWordPress = function () {
			$("#adminmenumain").hide();
			$("#wpadminbar").hide();
			$("#wpfooter").hide();
		}

		// ========================================================================================
		// ========================================================================================

		return f;
	}]);
