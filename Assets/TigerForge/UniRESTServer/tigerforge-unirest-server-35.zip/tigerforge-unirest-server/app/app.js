var app = angular.module("UniREST", ["ngRoute", "ngAnimate", "ngSanitize", "toastr", "oitozero.ngSweetAlert"]);

app.config(['$routeProvider', '$locationProvider', function ($routeProvider, $locationProvider) {

	var uri = WP_PLUGIN_URL; //"wp-content/themes/tigerforge/views/";

	$routeProvider
		.when('/', {
			controller: 'loginController',
			templateUrl: uri + 'login.html'
		})
		.when('/main', {
			controller: 'mainController',
			templateUrl: uri + 'main.html'
		})
		.when('/db', {
			controller: 'dbController',
			templateUrl: uri + 'db.html'
		})
		.when('/api', {
			controller: 'apiController',
			templateUrl: uri + 'api.html'
		})
		.when('/files', {
			controller: 'filesController',
			templateUrl: uri + 'files.html'
		})
		.otherwise({
			redirectTo: '/'
		});

}]);

var UTILS = {

	toFloat2: function (value) {
		return parseFloat(value.toFixed(2));
	},

	toFloat: function (value) {
		if (typeof value === "string") value = value.replace(",", ".");
		if (isNaN(value)) return 0;
		return parseFloat(value);
	},

	objectClone: function (obj) {
		return JSON.parse(JSON.stringify(obj));
	},

	getTodayDateComponent: function (component) {
		var oggi = new Date();
		switch (component) {
			case "Y":
				return oggi.getFullYear();
				break;

			default:
				break;
		}
		return "";
	},

	notNull: function (value) {

		if (typeof value === "undefined") return false;
		if (value == null) return false;

		return true;

	},

	isUndef: function (value) {
		return (typeof value === "undefined");
	},

	random: function (from, to) {
		return Math.floor(Math.random() * to) + from;
	},

	randomString: function (length) {
		var result = '';
		var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
		var charactersLength = characters.length;
		for (var i = 0; i < length; i++) {
			result += characters.charAt(Math.floor(Math.random() * charactersLength));
		}
		return result;
	},

	isVariableNameSyntax: function (string) {
		var numbers = "0123456789";
		var letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
		var symbols = "_";
		var all = numbers + letters + symbols;
		var char = "";
		for (var i = 0; i < string.length; i++) {
			char = string.charAt(i);
			if (all.indexOf(char) < 0) return false;
		}

		char = string.charAt(0);
		if (letters.indexOf(char) < 0) return false;

		char = string.charAt(string.length - 1);
		if (char == "_") return false;

		return true;
	},

	isAPISyntax: function (string) {
		if (string.substr(0, 1) == string.substr(0, 1).toUpperCase()) return false;
		if (string.toLowerCase().indexOf("unirest") >= 0) return false;
		var myRegEx = /^(?=[a-z])[a-zA-Z0-9]*[_]*?[a-zA-Z0-9]*$/i;
		var isValid = myRegEx.test(string);
		return isValid;
	},

	clone: function (data) {
		return JSON.parse(JSON.stringify(data));
	},

	array_move: function (arr, old_index, new_index) {
		if (new_index >= arr.length) {
			var k = new_index - arr.length + 1;
			while (k--) {
				arr.push(undefined);
			}
		}
		arr.splice(new_index, 0, arr.splice(old_index, 1)[0]);
		return arr;
	},

	replaceAll: function(target, search, replacement) {
		return target.split(search).join(replacement);
	}

}