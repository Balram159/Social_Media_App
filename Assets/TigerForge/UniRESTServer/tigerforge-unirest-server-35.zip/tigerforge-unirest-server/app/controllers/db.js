app.controller("dbController", ["$scope", "$core", "$timeout", function ($scope, $core, $timeout) {

    $scope.version = $core.version;

    // ============================================================================================
    // INITIALIZATION
    // ============================================================================================

    $scope.current = { page: 1, limit: 100, max: 1, jump: 1, showBack: false, showNext: false, limitSelect: "100" };

    $scope.testAccount = { user: "", pass: "", status: "" };

    function initialize() {

        $scope.loader = true;

        initVariables();

        $scope.tables = [];
        $core.DB_tablesList().then(function (tables) {

            $scope.tables = tables;
            $scope.loader = false;

        }, function (response) {
            errorAlert("INITIALIZATION", "An error occurred during the initialization of the Database Manager.");
        });

    }

    function initVariables() {

        $scope.modal = { id: "", button: "", recordID: 0, action: "", lockedDelete: [] };

        $scope.structure = {};
        $scope.newStructure = {};
        $scope.original = null;

        $scope.table = {};
        $scope.current = { page: 1, limit: 100, max: 1, jump: 1, showBack: false, showNext: false, limitSelect: "100" };

    }

    // ============================================================================================
    // SHOW TABLE
    // ============================================================================================

    $scope.show = function (table, action) {

        $scope.loader = true;

        if (action == "START") initVariables();

        if (action == "START") $scope.current.page = 1;
        if (action == "NEXT") $scope.current.page++;
        if (action == "BACK") $scope.current.page--;

        if ($scope.current.page > $scope.current.max) $scope.current.page = $scope.current.max;
        if ($scope.current.page < 1) $scope.current.page = 1;

        $core.post("unirest/tablecontent", { table: table.fullname, page: $scope.current.page, limit: $scope.current.limit }).then(function (response) {

            $scope.table = response;
            $scope.table.data = table;

            $scope.current.max = Math.ceil($scope.table.counter / $scope.current.limit);
            if ($scope.current.max < 1) $scope.current.max = 1;

            $scope.current.showBack = true;
            $scope.current.showNext = true;
            if ($scope.current.page == 1) $scope.current.showBack = false;
            if ($scope.current.page >= $scope.current.max) $scope.current.showNext = false;

            $scope.table.isSyncTable = isSyncTable();

            $scope.loader = false;

        }, function (response) {
            errorAlert("TABLE", "An error occurred during the reading of this table.");
        });

    }

    $scope.setRecordsShow = function () {

        switch ($scope.current.limitSelect) {
            case "100":
                $scope.current.limit = 100;
                $scope.show($scope.table.data, "");
                break;
            case "200":
                $scope.current.limit = 200;
                $scope.show($scope.table.data, "");
                break;
            case "500":
                $scope.current.limit = 500;
                $scope.show($scope.table.data, "");
                break;
            case "1000":
                $scope.current.limit = 1000;
                $scope.show($scope.table.data, "");
                break;
            case "ALL":
                if ($scope.table.counter > 1000) {
                    $core.ask("SHOW ALL RECORDS", "You are going to show more than 1000 records. This may require time and memory. Proceed?").then(function (OK) {
                        if (OK) {
                            $scope.current.limit = $scope.table.counter;
                            $scope.show($scope.table.data, "");
                        } else {
                            $scope.current.limitSelect = "" + $scope.current.limit;
                        }
                    });
                } else {
                    $scope.current.limit = $scope.table.counter;
                    $scope.show($scope.table.data, "");
                }
                break;

            default:
                break;
        }
    }

    // ============================================================================================
    // TABLE MODAL (NEW / MODIFY)
    // ============================================================================================

    $scope.openTableStructure = function (action) {

        if (action == "DELROWS") {
            deleteSelectedRows();
            return;
        }

        $scope.modal.id = 'MANAGETABLE';
        $scope.modal.action = action;

        dragActivateMouseUp();

        if (action == "NEW") {

            structureInitialize(action);
            $scope.modal.button = 'CREATE';

        } else {

            structureInitialize(action);
            $scope.modal.button = 'APPLY';

        }
    }

    $scope.closeTableStructure = function () {
        $scope.modal.id = "";
        dragDeactivateMouseUp();
    }

    $scope.createTable = function () {
        if ($scope.modal.button == 'CREATE') tableCreate(); else tableModify();
    }

    $scope.createSyncTable = function () {

        if ($scope.structure.name.length <= 1 || !UTILS.isVariableNameSyntax($scope.structure.name)) {
            $core.say("NEW SYNCTABLE", "Table name must contain only letters, numbers and the underscore symbol. It must start with a letter and undescore symbols can be used in the middle of the name only.", "warning");
            return false;
        }

        $core.ask("CREATE SYNCTABLE", "A SyncTable is a special table with a predefined structure and special features. Do you want to create this kind of table?").then(function (OK) {
            if (OK) {

                var columns = [];
                columns.push({ name: "id", type: "BIGINT", size: 20, null: false, reserved: true, id: UTILS.randomString(20) });
                columns.push({ name: "user_id", type: "BIGINT", size: 20, null: false, reserved: false, id: UTILS.randomString(20) });
                for (var i = 1; i <= 10; i++) columns.push({ name: "s" + i, type: "TeXT", size: 0, null: true, reserved: false, id: UTILS.randomString(20) });
                columns.push({ name: "token", type: "VARCHAR", size: 10, null: false, reserved: false, id: UTILS.randomString(20) });

                $scope.loader = true;

                $core.post("unirest/tablecreate", { name: $scope.structure.name, columns: columns }).then(function (response) {

                    if (response.status) {
                        $core.say("NEW SYNCTABLE", "Your new SyncTable has been created.", "success");
                        initialize();
                    } else {
                        errorAlert("NEW SYNCTABLE", "An error occurred creating your new SyncTable.");
                    }

                }, function (response) {
                    errorAlert("NEW SYNCTABLE", "An error occurred creating your new SyncTable.");
                });
            }
        });
    }

    function deleteSelectedRows() {
        var ids = [];

        $("[id^='db_row_']").each(function () {
            var cb = $(this);
            if (cb.is(':checked')) ids.push(cb.attr("id").replace("db_row_", ""));
        });

        if (ids.length == 0) {
            $core.pop("DELETE SELECTED ROWS", "There are no selected rows.", "WARN");
        } else {

            $core.ask("DELETE SELECTED ROWS", "Do you want to delete all the selected rows?").then(function (OK) {
                if (OK) {

                    $scope.loader = true;
                    var name = $scope.table.data.fullname;
                    $core.post("unirest/tablerecord", { name: name, fields: [], values: ids, id: 0, action: "DELETE_ALL" }).then(function (response) {

                        if (response.status == "OK") {
                            $scope.show($scope.table.data);
                        } else {
                            $core.say("DELETE SELECTED ROWS", "An error occurred deleting the rows.", "error");
                        }

                        $scope.loader = false;

                    }, function (response) {
                        errorAlert("DELETE SELECTED ROWS", "An error occurred deleting the rows.");
                    });

                }
            });

        }
    }

    $scope.allRowsSelected = false;
    $scope.selectAllRows = function () {
        $scope.allRowsSelected = !$scope.allRowsSelected;
    }

    // ============================================================================================
    // TABLE CREATE NEW
    // ============================================================================================

    function tableCreate() {


        if (!checkTableStructure("NEW TABLE")) return;

        var columns = getCurrentStructure();

        $scope.loader = true;

        $core.post("unirest/tablecreate", { name: $scope.structure.name, columns: columns }).then(function (response) {

            if (response.status) {
                $core.say("NEW TABLE", "Your new table has been created.", "success");
                initialize();
            } else {
                errorAlert("NEW TABLE", "An error occurred creating your new table.");
            }

        }, function (response) {
            errorAlert("NEW TABLE", "An error occurred creating your new table.");
        });

    }

    function checkTableStructure(title) {

        var columns = getCurrentStructure();

        var invalidColumnName = $core.columnNameIsReserved(columns);
        if (invalidColumnName != "") {
            $core.say(title, "The column name '" + invalidColumnName + "' is reserved and can't be used. Type a different name.", "error");
            return false;
        }

        if (!UTILS.isVariableNameSyntax($scope.structure.name)) {
            $core.say(title, "Table name must contain only letters, numbers and the underscore symbol. It must start with a letter and undescore symbols can be used in the middle of the name only.", "warning");
            return false;
        }

        if (columns.length <= 1) {
            $core.say(title, "This table should contain at least one column.", "warning");
            return false;
        }

        var errors = false;
        for (var i = 0; i < columns.length; i++) {
            if (!UTILS.isVariableNameSyntax(columns[i].name)) errors = true;
        }
        if (errors) {
            $core.say(title, "Columns name must contain only letters, numbers and the underscore symbol. It must start with a letter and undescore symbols can be used in the middle of the name only.", "warning");
            return false;
        }

        return true;

    }

    // ============================================================================================
    // TABLE MODIFY
    // ============================================================================================

    function tableModify() {

        if ($scope.modal.action == "UPDATE") tableModifyUpdate(); else tableModifyDelColumns();

    }

    function tableModifyUpdate() {

        if (!checkTableStructure("UPDATE STRUCTURE")) return;

        var actions = {};
        var hasNewColumns = false;
        var columns = getCurrentStructure();

        actions.tableRename = ($scope.structure.name != $scope.original.name) ? $scope.structure.name : "";
        actions.colRename = [];
        actions.typeChange = [];
        actions.newOrder = [];
        actions.newColumns = [];

        for (var i = 1; i < columns.length; i++) {

            var newCol = columns[i];
            var oldCol = $scope.original.columns.find(function (item) { return item.id == newCol.id; });

            var newColName = newCol.name;
            var newColType = newCol.type;
            var newColSize = newCol.size;
            var newColNull = (newCol.null) ? "" : " NOT NULL";

            if (newColType == "VARCHAR" || newColType == "INT" || newColType == "BIGINT") newColType = newColType + "(" + newColSize + ")";
            newColType += newColNull;

            if (UTILS.notNull(oldCol)) {

                var oldColName = oldCol.name;
                var oldColType = oldCol.type;
                var oldColSize = oldCol.size;
                var oldColNull = (oldCol.null) ? "" : " NOT NULL";

                if (oldColType == "VARCHAR" || oldColType == "INT" || oldColType == "BIGINT") oldColType = oldColType + "(" + oldColSize + ")";

                oldColType += oldColNull;

                if (oldColName != newColName) actions.colRename.push({ from: oldColName, to: newColName, type: oldColType });
                if (oldColType != newColType) actions.typeChange.push({ from: newColName, type: newColType });

                actions.newOrder.push({ from: newColName, type: newColType });

            } else {
                hasNewColumns = true;
                actions.newColumns.push({ from: newColName, type: newColType });
                actions.newOrder.push({ from: newColName, type: newColType });
            }

        }

        var hasErrors = false;

        if (!hasErrors) {

            $core.ask("CHANGE TABLE", "Do you want to change this table structure?").then(function (OK) {
                if (OK) {

                    $core.ask("ARE YOU SURE?", "If your table already contains some records, the changes can corrupt or modifiy you data. Proceed?").then(function (OK) {
                        if (OK) {

                            $scope.loader = true;

                            var name = $scope.table.data.fullname;
                            $core.post("unirest/tablemanage", { name: name, data: actions, action: "CHANGE" }).then(function (response) {

                                if (response.status == "OK") {
                                    $core.say("CHANGE TABLE", "Your table structure has been changed.", "success");
                                    $scope.modal.id = "";
                                    $scope.table.data.fullname = "tfur_" + $scope.structure.name;
                                    $scope.table.data.name = $scope.structure.name;
                                    $scope.show($scope.table.data);
                                    $scope.loader = false;
                                } else {
                                    errorAlert("CHANGE TABLE", "An error occurred changing the structure of this table.");
                                }

                            }, function (response) {
                                errorAlert("CHANGE TABLE", "A system error occurred changing the structure of this table.");
                            });

                        }
                    });

                }
            });

        }

    }

    function tableModifyDelColumns() {

        var selected = [];
        $("[coldelete]").each(function () {
            if ($(this).is(':checked')) selected.push($(this).attr("id"));
        });

        var currentColumns = getCurrentStructure();
        var columns = currentColumns.filter(function (item) { return selected.indexOf(item.id) >= 0; });

        if (currentColumns.length <= 2) {
            $core.say("DELETE COLUMNS", "You must have at least two columns to delete one column.", "warning");
            return;
        }

        if (columns.length < 1 || columns == null) return;

        $core.ask("DELETE COLUMNS", "Do you want to delete the selected columns?").then(function (OK) {
            if (OK) {

                $scope.loader = true;

                var name = $scope.table.data.fullname;
                $core.post("unirest/tablemanage", { name: name, data: columns, action: "DELETECOLUMNS" }).then(function (response) {

                    if (response.status == "OK") {
                        $core.say("DELETE COLUMNS", "The selected columns have been deleted.", "success");
                        $scope.modal.id = "";
                        $scope.show($scope.table.data);
                    } else {
                        $core.say("DELETE COLUMNS", "An error occurred deleting the table columns.", "error");
                    }

                    $scope.loader = false;

                }, function (response) {
                    errorAlert("DELETE COLUMNS", "An error occurred deleting the table columns.");
                });

            }
        });

    }

    // ============================================================================================
    // TABLE MANAGEMENT
    // ============================================================================================

    $scope.addNewRecord = function (addRecord) {

        if (addRecord) {

            var name = $scope.table.data.fullname;
            var fields = $scope.table.structure.map(function (item) { if (item.Field != "id") return item.Field; });
            var isNull = $scope.table.structure.map(function (item) { if (item.Field != "id") return (item.Null == "YES"); });
            fields = fields.filter(function (item) { if (typeof item !== "undefined") return item; });

            var values = [];
            for (var i = 1; i <= fields.length; i++) {
                if (typeof $scope.table.values[i] === "undefined") values.push(null); else values.push($scope.table.values[i]);
            }

            if (values.length > fields.length) values = values.slice(1);
            if (isNull.length > fields.length) isNull = isNull.slice(1);

            for (var i = 0; i < fields.length; i++) {
                if (!isNull[i] && values[i] == null) {
                    $core.say("NEW RECORD", "The '" + fields[i] + "' field is mandatory and can't be null.", "error");
                    return;
                }
            }

            $scope.loader = true;

            $core.post("unirest/tablerecord", { name: name, fields: fields, values: values, id: $scope.modal.recordID, action: "WRITE" }).then(function (response) {

                if (response.status == "OK") {
                    $scope.modal.id = "";
                    $scope.show($scope.table.data);
                } else {
                    errorAlert("TABLE RECORD", "An error occurred writing record data to your table.");
                }

                $scope.loader = false;

            }, function (response) {
                errorAlert("TABLE RECORD", "An error occurred writing record data to your table.");
            });

        } else {
            $scope.modal.id = "ADDNEWRECORD";
            $scope.modal.button = "ADD RECORD";
            $scope.table.values = [];
            $scope.modal.recordID = 0;
            return;
        }

    }

    $scope.deleteTable = function () {

        $core.ask("DELETE TABLE", "Do you want to delete this table?").then(function (OK) {
            if (OK) {

                $core.ask("ARE YOU SURE?", "Once the table has been deleted, it won't be recoverable. Proceed?").then(function (OK) {
                    if (OK) {

                        $scope.loader = true;

                        var name = $scope.table.data.fullname;
                        $core.post("unirest/tablemanage", { name: name, data: [], action: "DELETE" }).then(function (response) {

                            if (response.status == "OK") {
                                $core.say("DELETE TABLE", "Your table has been deleted.", "success");
                                initialize();
                            } else {
                                $core.say("DELETE TABLE", "An error occurred deleting this table.", "error");
                            }

                            $scope.loader = false;

                        }, function (response) {
                            errorAlert("DELETE TABLE", "An error occurred deleting this table.");
                        });

                    }
                });

            }
        });

    }

    $scope.emptyTable = function () {

        $core.ask("EMPTY TABLE", "Do you want to clear the content of this table?").then(function (OK) {
            if (OK) {

                $core.ask("ARE YOU SURE?", "Once the table's records have been deleted, they won't be recoverable. Proceed?").then(function (OK) {
                    if (OK) {

                        $scope.loader = true;

                        var name = $scope.table.data.fullname;
                        $core.post("unirest/tablemanage", { name: name, data: [], action: "EMPTY" }).then(function (response) {

                            if (response.status == "OK") {
                                $core.say("EMPTY TABLE", "Your table has been cleaned.", "success");
                                initialize();
                            } else {
                                $core.say("EMPTY TABLE", "An error occurred deleting this table's records.", "error");
                            }

                            $scope.loader = false;

                        }, function (response) {
                            errorAlert("EMPTY TABLE", "An error occurred deleting this table's records.");
                        });

                    }
                });

            }
        });

    }

    $scope.recordEdit = function (row) {
        $scope.modal.id = "ADDNEWRECORD";
        $scope.modal.button = "SAVE";
        $scope.table.values = row;
        $scope.modal.recordID = row[0];
    }

    $scope.recordDelete = function (row) {

        $core.ask("DELETE RECORD", "Do you want to delete this record?").then(function (OK) {
            if (OK) {

                $scope.loader = true;

                var name = $scope.table.data.fullname;
                $scope.modal.recordID = row[0];
                $core.post("unirest/tablerecord", { name: name, fields: [], values: [], id: $scope.modal.recordID, action: "DELETE" }).then(function (response) {

                    if (response.status == "OK") {
                        $scope.show($scope.table.data);
                    } else {
                        $core.say("DELETE RECORD", "An error occurred deleting this record.", "error");
                    }

                    $scope.loader = false;

                }, function (response) {
                    errorAlert("DELETE RECORD", "An error occurred deleting this record.");
                });

            }
        });

    }

    $scope.addTestAccount = function () {
        $core.post("unirest/configmanage", { action: "CREATE_TEST_ACCOUNT" }).then(function (response) {

            $scope.testAccount = response;
            if (!response.status) $core.pop("CREATE TEST ACCOUNT", "Error creating the test account.", "ERROR"); else $scope.show($scope.table.data, "");

        }, function (response) {
            $core.pop("CREATE TEST ACCOUNT", "Error accessing the 'user' table.", "ERROR");
            $scope.loader = false;
        });
    }


    // ============================================================================================
    // DB MANAGEMENT
    // ============================================================================================

    $scope.addNewCol = function () {
        $scope.structure.columns.push({ name: "", type: "TEXT", size: 1, null: false, reserved: false, id: UTILS.randomString(20) });
        dragTable();
    }

    $scope.jumpToPage = function (keyEvent, table) {
        if (keyEvent.which === 13) {
            $scope.current.jump = parseInt($scope.current.jump + "");
            if (isNaN($scope.current.jump)) $scope.current.jump = 1;
            if ($scope.current.jump < 1) $scope.current.jump = 1;
            if ($scope.current.jump > $scope.current.max) $scope.current.jump = $scope.current.max;
            $scope.current.page = $scope.current.jump - 1;
            $scope.show(table, "NEXT");
        }
    }

    $scope.changeType = function (col) {
        if (col.type == "INT") col.size = 11;
        if (col.type == "VARCHAR") col.size = 10;
        if (col.type == "BIGINT") col.size = 20;
    }

    $scope.deleteColumn = function (i) {

        $("[row='" + i + "']").hide();

    }

    // ============================================================================================
    // HELPERS & VARIOUS
    // ============================================================================================

    $(document).ready(function () {
        if ($core.currentPathIs("db")) {
            initialize();
            $core.hideWordPress();
        }
    });

    function structureInitialize(action) {

        $("[row]").show();

        $scope.structure = { name: (UTILS.notNull($scope.table.data) && action != "NEW") ? $scope.table.data.name : "", columns: [] };

        $scope.structure.columns.push({ name: "id", type: "BIGINT", size: 20, null: false, reserved: true, id: UTILS.randomString(20) });

        if (action != "NEW")
            for (var i = 1; i < $scope.table.structure.length; i++) {

                var c = $scope.table.structure[i];

                if (c.Field != "id") {

                    var type = "TEXT";
                    if (c.Type.indexOf("text") >= 0) type = "TEXT";
                    if (c.Type.indexOf("varchar") >= 0) type = "VARCHAR";
                    if (c.Type.indexOf("int") >= 0) type = "INT";
                    if (c.Type.indexOf("float") >= 0) type = "FLOAT";
                    if (c.Type.indexOf("datetime") >= 0) type = "DATETIME";
                    if (c.Type.indexOf("bigint") >= 0) type = "BIGINT";
                    if (c.Type.indexOf("longtext") >= 0) type = "LONGTEXT";

                    var size = 1;
                    if (c.Type.indexOf("(") > 0) {
                        size = c.Type.replace("(", "|").replace(")", "|").split("|");
                        size = size[1];
                    }

                    $scope.structure.columns.push({ name: c.Field, type: type, size: size, null: c.Null == "YES", reserved: false, id: UTILS.randomString(20) });

                }
            }

        if (action == "UPDATE") {

            $scope.modal.lockedDelete = [];
            for (var i = 1; i < $scope.structure.columns.length; i++) {
                $scope.modal.lockedDelete.push($scope.structure.columns[i].id);
            }

        }

        $scope.original = UTILS.clone($scope.structure);

        dragTable();

    }

    $scope.go = function (path) {
        $core.go(path);
    }

    var drag = { first: null, second: null, isStarted: false };

    function dragTable() {

        $timeout(function () {

            $("[dragrow]").off();

            $("[dragrow]")
                .mousedown(function () {
                    drag.isStarted = true;
                    drag.first = $(this);
                    drag.first.css("background-color", "#007cba");
                })
                .mouseenter(function () {
                    if (!drag.isStarted) return;
                    if (drag.first[0].id != $(this)[0].id) {
                        drag.second = $(this);
                        drag.second.css("background-color", "#CCC");
                    }
                })
                .mouseleave(function () {
                    if (drag.second != null) drag.second.css("background-color", "");
                    drag.second = null;
                })
                .mousemove(function () {
                    document.getSelection().removeAllRanges();
                });

        }, 100);

    }

    function dragActivateMouseUp() {
        $(document).on("mouseup", function (event) {
            $("[dragrow]").css("background-color", "");
            $("[dragrow]").css("background-color", "");

            if (drag.first == null || drag.second == null || !drag.isStarted) return;

            var columns = UTILS.clone($scope.structure.columns);
            var idColumn = columns[0];
            columns.shift();

            var firstIndex = -1;
            var secondIndex = -1;
            for (var i = 0; i < columns.length; i++) {
                if (columns[i].id == drag.first.attr("colid")) firstIndex = i;
                if (columns[i].id == drag.second.attr("colid")) secondIndex = i;
            }

            if (firstIndex == secondIndex) return;

            $scope.structure.columns = UTILS.array_move(columns, firstIndex, secondIndex);
            $scope.structure.columns.unshift(idColumn);
            $scope.$digest();

            drag = { first: null, second: null, isStarted: false };
        });
    }

    function dragDeactivateMouseUp() {
        $(document).off("mouseup");
        drag = { first: null, second: null, isStarted: false };
    }

    function getCurrentStructure() {

        var newStructure = [];
        newStructure.push({ name: "id", type: "BIGINT", size: 20, null: false, reserved: true, id: UTILS.randomString(20) });

        $("[row]").each(function () {

            var id = $(this).attr("id");
            var visible = $(this).is(":visible");

            if (visible) {
                var s = $scope.structure.columns.find(function (item) { return item.id == id; });
                if (s != null) newStructure.push(s);
            }

        });

        return newStructure;
    }

    function errorAlert(title, message) {
        $core.say(title, message, "error");
        $scope.loader = false;
    }

    function isSyncTable() {

        if ($scope.table.structure.length != 13) return false;

        var cols = ["id", "user_id", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "s8", "s9", "s10", "token"];
        for (var i = 0; i < $scope.table.structure.length; i++) {
            var field = $scope.table.structure[i].Field;
            if (cols.indexOf(field) < 0) return false;
        }

        return true;

    }

}]);