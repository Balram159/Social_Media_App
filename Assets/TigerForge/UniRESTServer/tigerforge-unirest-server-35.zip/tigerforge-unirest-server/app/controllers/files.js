app.controller("filesController", ["$scope", "$core", function ($scope, $core) {

    $scope.version = $core.version;

    $scope.search = { user: "", type: "", result: [], id: 0 };

    function initialize() {

    }

    $scope.searchRun = function (action) {

        if ($scope.search.user == "") return;

        $scope.search.type = action;

        if (action == "byid") {
            if (isNaN($scope.search.user)) {
                $core.pop("SEARCH BY ID", "The given search parameter is not a valid ID.", "ERROR");
                return;
            }
        }

        $scope.loader = true;
        $core.post("unirest/userfilesmanage", { action: action, search: $scope.search.user }).then(function (response) {

            $scope.loader = false;

            if (typeof response.list === "undefined") { $scope.search.result = []; return; }

            if (response.list.length > 0) {
                $scope.search.result = response.list;
                $scope.search.id = response.id;
            } else {
                $scope.search.result = [];
            }

        }, function (response) {
            $core.say("USER", "An error occurred finding the user.", "error");
            $scope.loader = false;
        });

    }

    $scope.action = function (action, file) {
        if (action == "DELETE") {

            $core.ask("FILE DELETE", "Do you want to delete this file?").then(function (OK) {
                if (OK) {

                    $scope.loader = true;

                    var fileToDelete = ($scope.search.id == null) ? file : $scope.search.id + "/" + file;

                    $core.post("unirest/userfilesmanage", { action: "DELETE", file: fileToDelete, search: $scope.search.id }).then(function (response) {
                        $scope.searchRun($scope.search.type);
                        $scope.loader = false;
                    }, function (response) {
                        $core.say("USER", "An error occurred finding the user.", "error");
                        $scope.loader = false;
                    });

                }
            });

        }

    }

    $scope.go = function (path) {
        $core.go(path);
    }

    $(document).ready(function () {
        if ($core.currentPathIs("files")) {
            initialize();
            $core.hideWordPress();
        }
    });

}]);