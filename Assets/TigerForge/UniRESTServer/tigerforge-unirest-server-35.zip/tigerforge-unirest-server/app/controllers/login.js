app.controller("loginController", [ "$scope", "$core", function($scope, $core) {
    
    $scope.version = $core.version;

    $scope.wp_has_permalinks = WP_HAS_PERMALINK;

	$scope.go = function (path) {
        $core.go(path);
    }
	
}]);