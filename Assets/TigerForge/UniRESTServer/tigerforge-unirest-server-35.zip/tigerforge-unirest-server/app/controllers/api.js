app.controller("apiController", ["$scope", "$core", "$timeout", function ($scope, $core, $timeout) {

    $scope.version = $core.version;

    $scope.currentGroupIndex = -1;

    $scope.systemCheck = [];

    function initialize() {

        $scope.loader = true;

        $scope.groups = [];
        $scope.group = null;

        $core.getTablesStructure().then(function (response) {

            $scope.tablesList = response.tablesList;
            $scope.tableCols = response.tableCols;

            $core.getAPIs().then(function (parsed) {

                $scope.groups = parsed;

                for (var i = 0; i < $scope.groups.length; i++) $scope.groups[i].APIs = $core.getGroupAPIsList($scope.groups[i], $scope.tablesList);

                if ($scope.currentGroupIndex > -1) $scope.showGroupAPIs($scope.currentGroupIndex);

                $timeout(function () {
                    $scope.loader = false;
                    $("#api-list").show();
                }, 1000);

                systemCheck();

            }, function (response) { $scope.loader = false; });

        }, function (response) { $scope.loader = false; });

    }

    $scope.addNewGroup = function () {

        $scope.group = null;
        $scope.groups.push($core.newGroup());

    }

    $scope.addNewAPI = function () {

        if (!UTILS.isAPISyntax($scope.group.name)) {
            $core.say("ADD NEW API", "The API Group name must contains alphanumberic characters and the underscore symbol only. The first letter must be a lower case character.", "error");
            return;
        }

        $scope.group.APIs.push($core.newAPI($scope.tablesList, $scope.group.APIs.length));

    }

    $scope.showGroupAPIs = function (i) {

        $scope.currentGroupIndex = i;

        $scope.loader = true;
        $scope.fieldsUpdater = [];

        $scope.group = $scope.groups[i];
        $scope.APIlist = $scope.groups[i].APIfields;

        if ($scope.group.APIs.length > 0) {
            $timeout(function () {
                updateSelectFields();
                $scope.loader = false;
            }, 500);
        } else {
            $scope.loader = false;
        }

    }

    $(document).ready(function () {
        if ($core.currentPathIs("api")) {
            initialize();
            $core.hideWordPress();
        }
    });

    $scope.go = function (path) {
        $core.go(path);
    }

    $scope.getColumns = function (table) {

        var cols = $scope.tableCols["tfur_" + table];

        if (typeof cols === "undefined") return [];

        return cols;

    }

    $scope.labelColor = function (label, type, i) {

        var field = label + type + "__" + i;

        var value = $("#" + field).val();

        if (typeof value === "undefined") return { color: "#a9a5a5" };

        if (value == "None") return { color: "#a9a5a5" };
        if (value.indexOf("Key") > 0) return { color: "darkred" };
        if (value.indexOf("Key") >= 0) return { color: "red" };

    }

    $scope.saveAPI = function () {

        if (!UTILS.isAPISyntax($scope.group.name)) {
            $core.say("SAVE API", "The API Group name must contains alphanumberic characters and the underscore symbol only. The first letter must be a lower case character.", "error");
            return;
        }

        var duplicates = duplicateNames();
        if (duplicates != "") {

            if (duplicates == "DUPLICATE_GROUP") $core.say("SAVE API", "This API Group has the same name of another API Group. Type a different name.", "error");
            if (duplicates == "DUPLICATE_APINAME") $core.say("SAVE API", "Each API must have a different, unique name.", "error");
            if (duplicates == "APINAME_INVALID") $core.say("SAVE API", "An API Name must contains alphanumberic characters and the underscore symbol only. The first letter must be a lower case character.", "error");
            return;
        }

        if (customSQLCheck()) {
            $core.say("SAVE API", "Custom SQL query strings can't contain non-escaped double quotes. Check the queries in red and escape all the double quotes:<br> from <b>\"</b> to <b>\\\"</b>", "error");
            return;
        }

        var customPHPErrors = customPHPCheck();
        if (customPHPErrors != "") {
            if (customPHPErrors == "PHP_NOT_VALID") $core.say("SAVE API", "Custom PHP code must start with a <?php string and end with a ?> string. Check your PHP code.", "error");
            if (customPHPErrors == "PHP_HAS_ERRORS") $core.say("SAVE API", "There are errors in your PHP scripts. Check your PHP code.", "error");
            return;
        }

        $scope.loader = true;

        customPHPSave();

        for (var g = 0; g < $scope.group.APIs.length; g++) {

            var API = $scope.group.APIs[g];

            var cols = $scope.getColumns(API.selectedTable);

            var field, value;
            var R = [];
            var W = [];
            var U = [];
            var D = [];
            for (var i = 0; i < cols.length; i++) {

                field = cols[i].Field + "__R__" + g;
                value = $("#" + field).val();
                R.push({ field: cols[i].Field, value: value });

                field = cols[i].Field + "__W__" + g;
                value = $("#" + field).val();
                W.push({ field: cols[i].Field, value: value });

                field = cols[i].Field + "__U__" + g;
                value = $("#" + field).val();
                U.push({ field: cols[i].Field, value: value });

                field = cols[i].Field + "__D__" + g;
                value = $("#" + field).val();
                D.push({ field: cols[i].Field, value: value });
            }

            $scope.group.APIs[g].R = R;
            $scope.group.APIs[g].W = W;
            $scope.group.APIs[g].U = U;
            $scope.group.APIs[g].D = D;

        }

        var toDelete = [];
        $("input[id!='delete__']").each(function () {
            var id = $(this).attr("id");
            if (typeof id !== "undefined")
                if (id.indexOf("delete__") >= 0) {
                    var isChecked = $(this).prop("checked");
                    if (isChecked) {
                        var i = parseInt(id.replace("delete__", ""));
                        toDelete.push($scope.group.APIs[i].name);
                    }
                }
        });

        if (toDelete.length > 0) {
            if (toDelete.length == $scope.group.APIs.length) {
                $core.ask("SAVE API", "You have selected all the APIs for deletion. This operation will delete also the whole API Group. Proceed?").then(function (OK) {
                    if (OK) $scope.groupDelete();
                });
            } else {
                $core.ask("SAVE API", "You have selected one or more APIs for deletion. Do you want to delete that APIs?").then(function (OK) {
                    if (OK) {
                        save(toDelete);
                    } else {
                        $scope.loader = false;
                        return;
                    }
                });
            }
        } else {
            save(toDelete);
        }

    }

    function save(toDelete) {

        $core.post("unirest/apimanage", { action: "SAVE", group: $scope.group, toDelete: toDelete }).then(function (response) {

            $core.post("unirest/system", { action: "UNIRESTAPIENGINE" }).then(function (response) {
                $scope.loader = false;
                $core.say("SAVE API", "Your APIs have been saved.", "success");
                initialize();
            }, function (response) {
                $core.say("SAVE", "An error occurred updating the API Engine.", "error");
                $scope.loader = false;
            });

        }, function (response) {
            $core.say("SAVE API", "An error occurred saving your APIs.", "error");
        });

    }

    function updateSelectFields() {

        for (var n = 0; n < $scope.APIlist.length; n++) {

            var fields = $scope.APIlist[n].api;
            var tableCols = $scope.tableCols["tfur_" + fields.table];

            if (typeof tableCols !== "undefined") {
                for (var i = 0; i < tableCols.length; i++) {
                    var f = tableCols[i].Field;
                    var id = "#" + f + "__R__" + n;
                    $(id).val("None");
                    id = "#" + f + "__W__" + n;
                    $(id).val("None");
                    id = "#" + f + "__U__" + n;
                    $(id).val("None");
                    id = "#" + f + "__D__" + n;
                    $(id).val("None");
                }

                for (var i = 0; i < fields.read_select.length; i++) {
                    var f = fields.read_select[i];
                    var id = "#" + f + "__R__" + n;
                    var value = "Read";
                    $(id).val(value);
                }
                for (var i = 0; i < fields.read_where.length; i++) {
                    var f = fields.read_where[i];
                    var id = "#" + f + "__R__" + n;
                    var value = "Key";
                    if (fields.read_select.indexOf(f) < 0) { $(id).val(value); }
                }

                for (var i = 0; i < fields.write_fields.length; i++) {
                    var f = fields.write_fields[i];
                    var id = "#" + f + "__W__" + n;
                    var value = "Write";
                    $(id).val(value);
                }

                for (var i = 0; i < fields.update_fields.length; i++) {
                    var f = fields.update_fields[i];
                    var id = "#" + f + "__U__" + n;
                    var value = "Update";
                    $(id).val(value);
                }
                for (var i = 0; i < fields.update_where.length; i++) {
                    var f = fields.update_where[i];
                    var id = "#" + f + "__U__" + n;
                    var value = "Key";
                    $(id).val(value);
                }

                for (var i = 0; i < fields.delete_where.length; i++) {
                    var f = fields.delete_where[i];
                    var id = "#" + f + "__D__" + n;
                    var value = "Key";
                    $(id).val(value);
                }
            }

        }

        for (var i = 0; i < $scope.APIlist.length; i++) setEditor(i);

        customPHPLoad();

        $scope.$apply();

    }

    $scope.showAlert = function (api, type) {

        var tableCols = $scope.tableCols["tfur_" + api.selectedTable];
        if (typeof tableCols === "undefined") return true;
        if (tableCols.length <= 1) return true;
        var values = "";
        for (var i = 1; i < tableCols.length; i++) {
            values += $("#" + tableCols[i].Field + "__" + type + "__" + api.i).val() + " ";
        }

        if (type == "R") {

            if (api.read.useID) return false;

        } else if (type == "U") {

            if (api.update.useID) return false;

        } else if (type == "D") {

            if (api.delete.useID) return false;

        }

        if (values.indexOf("Key") >= 0) return false;

        return true;
    }

    $scope.apiRename = function (api) {

        var oldName = api.name;

        var newName = prompt("Type a new name for this API", "");
        if (newName == "" || newName == null) return;

        if (!UTILS.isAPISyntax(newName)) {
            $core.say("NEW API NAME", "An API Name must contains alphanumberic characters and the underscore symbol only. The first letter must be a lower case character.", "error");
            return;
        }

        if (apiNameExists(newName)) {
            $core.say("NEW API NAME", "This name is already in use by another API. Each API must have a different, unique name.", "error");
            return;
        }

        $scope.loader = true;

        $core.post("unirest/apimanage", { action: "RENAMEAPI", group: [$scope.group.name, oldName, newName], toDelete: [] }).then(function (response) {

            $scope.loader = false;
            $core.say("SAVE API", "Your APIs have been updated.", "success");
            initialize();

        }, function (response) {
            $core.say("SAVE API", "An error occurred updating your APIs.", "error");
        });

    }

    $scope.groupRename = function (api) {

        var newName = prompt("Type a new name for this API Group", "");
        if (newName == "" || newName == null) return;

        if (!UTILS.isAPISyntax(newName)) {
            $core.say("NEW API GROUP NAME", "An API Group name must contains alphanumberic characters and the underscore symbol only. The first letter must be a lower case character.", "error");
            return;
        }

        if (groupNameExists(newName)) {
            $core.say("NEW API GROUP NAME", "This name is already in use by another API Group. Type a different name.", "error");
            return;
        }

        $scope.loader = true;

        $core.post("unirest/apimanage", { action: "RENAMEGROUP", group: [$scope.group.name, newName], toDelete: [] }).then(function (response) {

            $scope.loader = false;
            $core.say("SAVE API", "Your APIs have been updated.", "success");
            initialize();

        }, function (response) {
            $core.say("SAVE API", "An error occurred updating your APIs.", "error");
        });

    }

    $scope.groupDelete = function () {

        $core.ask("DELETE API GROUP", "Do you want to delete this API Group?").then(function (OK) {
            if (OK) {

                $core.ask("ARE YOU SURE?", "If you delete this Group, all the Group APIs will be removed. Proceed?").then(function (OK) {
                    if (OK) {

                        $scope.loader = true;

                        $core.post("unirest/apimanage", { action: "DELETEGROUP", group: $scope.group, toDelete: [] }).then(function (response) {

                            $scope.loader = false;
                            $core.say("DELETE API GROUP", "Your API Group has been deleted.", "success");
                            $scope.currentGroupIndex = -1;
                            initialize();

                        }, function (response) {
                            $core.say("DELETE API GROUP", "An error occurred deleting this API Group.", "error");
                        });

                    }
                });

            }
        });

    }

    function duplicateNames() {

        var errorCode = "";
        var hasDuplicated = false;
        var names = [];

        // Controllo nomi di Gruppi duplicati
        names = [];
        for (var i = 0; i < $scope.groups.length; i++) names.push($scope.groups[i].name);
        hasDuplicate = names.some((val, i) => names.indexOf(val) !== i);
        if (hasDuplicate) errorCode = "DUPLICATE_GROUP";

        // Controllo nomi di APIs duplicati
        names = [];
        for (var i = 0; i < $scope.group.APIs.length; i++) names.push($scope.group.APIs[i].name);
        hasDuplicate = names.some((val, i) => names.indexOf(val) !== i);
        if (hasDuplicate) errorCode = "DUPLICATE_APINAME";

        // Controllo validità nomi di APIs
        names = [];
        for (var i = 0; i < $scope.group.APIs.length; i++) {
            if (!UTILS.isAPISyntax($scope.group.APIs[i].name)) errorCode = "APINAME_INVALID";
        }

        return errorCode;

    }

    function groupNameExists(name) {

        for (var i = 0; i < $scope.groups.length; i++) {

            if ($scope.groups[i].name == name) return true;

        }

        return false;

    }

    function apiNameExists(name) {

        for (var i = 0; i < $scope.group.APIs.length; i++) {

            if ($scope.group.APIs[i].name == name) return true;

        }

        return false;

    }

    function systemCheck() {
        $core.post("unirest/system", { action: "DBAPICHECK" }).then(function (response) {

            $scope.systemCheck = [];

            try {
                var API = response.API;
                if (API.length <= 0) return;
                var DB = response.DB;

                for (var i = 0; i < API.length; i++) {

                    API[i].table = systemCheckCleanText(API[i].table);

                    var operations = API[i].hasR + API[i].hasW + API[i].hasU + API[i].hasD + API[i].hasC;
                    var readFields = " " + systemCheckCleanText(API[i].read_select) + " " + systemCheckCleanText(API[i].read_where) + " ";
                    var writeFields = " " + systemCheckCleanText(API[i].write_fields) + " ";
                    var updateFields = " " + systemCheckCleanText(API[i].update_fields) + " " + systemCheckCleanText(API[i].update_where) + " ";
                    var updateIDs = systemCheckCleanText(API[i].update_where);
                    var deleteIDs = systemCheckCleanText(API[i].delete_where);
                    var hasU = systemCheckCleanText(API[i].hasU);
                    var hasD = systemCheckCleanText(API[i].hasD);
                    var isCustomPHP = API[i].read_custom_query.indexOf("[CUSTOM_PHP]") >= 0;

                    var fields = (readFields + writeFields + updateFields + " " + deleteIDs + " ").split(" ");
                    var cols = " ";
                    var colError = "";
                    if (!UTILS.isUndef(DB[API[i].table])) {
                        for (var c = 0; c < DB[API[i].table].length; c++) cols += DB[API[i].table][c].Field + " ";
                        for (var f = 0; f < fields.length; f++) {
                            if (colError == "" && fields[f].length > 1 && cols.indexOf(" " + fields[f] + " ") < 0) colError = fields[f];
                        }
                    }

                    //console.log(API[i].table, isCustomPHP);

                    if (API[i].table == "tfur_" && !isCustomPHP) {
                        $scope.systemCheck.push({ type: "NO_SELECTED_TABLE", api: API[i].url });
                    } else if (colError != "") {
                        $scope.systemCheck.push({ type: "UNKNOWN_FIELD", api: API[i].url, data: colError });
                    } else if (UTILS.isUndef(DB[API[i].table]) && !isCustomPHP) {
                        $scope.systemCheck.push({ type: "TABLE_NOT_EXISTS", api: API[i].url, data: API[i].table.replace("tfur_", "") });
                    } else if (operations.indexOf("true") < 0) {
                        if (!isCustomPHP) $scope.systemCheck.push({ type: "NO_SELECTED_OPERATION", api: API[i].url });
                    } else if (hasU == "true" && updateIDs == "") {
                        $scope.systemCheck.push({ type: "NO_UPDATE_ID", api: API[i].url });
                    } else if (hasD == "true" && deleteIDs == "") {
                        $scope.systemCheck.push({ type: "NO_DELETE_ID", api: API[i].url });
                    }

                }
            } catch (error) { }

        }, function (response) {
            $core.say("DB API CHECK", "An error occurred while checking you DB and APIs.", "error");
        });
    }

    function systemCheckCleanText(string) {

        string = string.replace(";", "").replace(";", "");
        string = string.replace('"', '').replace('"', '').replace('"', '').replace('"', '');
        string = string.trim();

        return string;
    }

    $scope.getIndexGroup = function (gruppo) {

        var apis = $scope.indice.dati.filter(function (item) { return item.gruppo == gruppo; });
        if (apis == null) return [];
        if (apis.length == 0) return [];

        return apis;

    }

    function customSQLCheck() {

        var result = false;

        var customs = $("[customSQL]");
        for (var i = 0; i < customs.length; i++) {

            var text = $(customs[i]).val();

            if (text.indexOf("\"") > 0) {

                text = UTILS.replaceAll(text, "\\\"", "!");
                if (text.indexOf("\"") >= 0) {
                    result = true;
                    $(customs[i]).css("color", "red");
                } else {
                    $(customs[i]).css("color", "#464a4c");
                }

            }

        }

        return result;

    }

    $scope.customPHP = function (i) {
        var currentR = $scope.group.APIs[i].custom.R;

        if ($scope.group.APIs[i].custom.R == "[CUSTOM_PHP]") {

            var editor = ace.edit("php_editor_" + i);
            var php = editor.getValue();
            if (php.length > 10) {
                $core.ask("Custom PHP", "The PHP editor contains some code. If you unselect the 'Custom PHP' feature now, you will lose this code.<br><br>Proceed?", "warn").then(function (OK) {
                    if (OK) {
                        $scope.group.APIs[i].custom.R = (currentR == "[CUSTOM_PHP]") ? "" : currentR;
                    }
                });
            } else {
                $scope.group.APIs[i].custom.R = (currentR == "[CUSTOM_PHP]") ? "" : currentR;
            }
            
            return;
        }

        $core.ask("Custom PHP", "You are going to link this API to your custom PHP script.<br>In this case, operations like Read, Write, and so on, won't be available.<br><br>Proceed?", "info").then(function (OK) {
            if (OK) {
                $scope.group.APIs[i].custom.R = "[CUSTOM_PHP]";
                $scope.group.APIs[i].skills.C = false;
                $scope.group.APIs[i].skills.D = false;
                $scope.group.APIs[i].skills.R = false;
                $scope.group.APIs[i].skills.U = false;
                $scope.group.APIs[i].skills.W = false;

                $timeout(function () { setEditor(i); }, 100);
            }
            else {
                $scope.group.APIs[i].custom.R = (currentR == "[CUSTOM_PHP]") ? "" : currentR;
            }
        });
    }

    function customPHPSave() {

        for (var i = 0; i < $scope.group.APIs.length; i++) {

            var api = $scope.group.APIs[i];

            if (api.custom.R == "[CUSTOM_PHP]") {

                var editor = ace.edit("php_editor_" + i);
                var php = editor.getValue();
                var decoded = btoa(php);
                
                api.custom.W = decoded;

            }

        }

    }

    function customPHPLoad() {

        for (var i = 0; i < $scope.group.APIs.length; i++) {

            var api = $scope.group.APIs[i];

            if (api.custom.R == "[CUSTOM_PHP]" && api.custom.W.length > 2) {

                var editor = ace.edit("php_editor_" + i);
                editor.setValue(atob(api.custom.W));
                editor.clearSelection();

            }

        }

    }

    function customPHPCheck() {

        for (var i = 0; i < $scope.group.APIs.length; i++) {

            var api = $scope.group.APIs[i];

            if (api.custom.R == "[CUSTOM_PHP]") {

                var editor = ace.edit("php_editor_" + i);
                var php = editor.getValue();

                if (php.indexOf("<?php") < 0 || php.indexOf("?>") < 0) return "PHP_NOT_VALID";

                var annotations = editor.getSession().getAnnotations();
                if (annotations.length > 0) return "PHP_HAS_ERRORS";


            }

        }

        return "";

    }

    $scope.customPhpWordPress = function(i) {
        var currentU = $scope.group.APIs[i].custom.U;
        if (currentU == "[CUSTOM_PHP_WP]") $scope.group.APIs[i].custom.U = ""; else $scope.group.APIs[i].custom.U = "[CUSTOM_PHP_WP]";
    }

    $scope.customPhpAuth = function(i) {
        var currentD = $scope.group.APIs[i].custom.D;
        if (currentD == "[CUSTOM_PHP_AUTH]") $scope.group.APIs[i].custom.D = ""; else $scope.group.APIs[i].custom.D = "[CUSTOM_PHP_AUTH]";
    }

    $scope.indexLoad = function () {
        $("#api-list").hide();
        $scope.currentGroupIndex = -1;
        initialize();
    }

    function setEditor(i) {
        var editor = ace.edit("php_editor_" + i);
        editor.setTheme("ace/theme/monokai");
        editor.session.setMode("ace/mode/php");
        editor.setValue("<?php ?>");
        editor.clearSelection();
    }


}]);