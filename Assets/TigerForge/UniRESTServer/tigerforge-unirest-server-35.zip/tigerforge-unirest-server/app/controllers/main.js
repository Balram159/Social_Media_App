app.controller("mainController", ["$scope", "$core", "$timeout", function ($scope, $core, $timeout) {

    $scope.version = $core.version;

    $scope.loader = true;

    $scope.backup = "";
    $scope.backupType = { selected: "API" };

    $scope.systemCheck = {};

    $scope.options = { include_api_desc: false, client_config_need_update: false, show_news_bell: false };

    function initialize() {

        $scope.showClientConfig = false;

        configLoad();

        $timeout(function () {
            $.get("https://stevenworks.com/restapi/wp-json/wp/v2/posts/", function (response) {
                if (!UTILS.notNull(response)) return;

                for (var i = 0; i < response.length; i++) {
                    if (response[i].title.rendered.toLowerCase() == "news") {
                        var table = $(response[i].content.rendered).find("table");
                        $("#news-area").html(table);
                        return;
                    }
                }

            });
        }, 500);

        $timeout(function () {

            var bell = localStorage.getItem("ur_news_bell");
            if (UTILS.notNull(bell)) {

                var l = $("#news-area").text().length;
                $scope.options.show_news_bell = (bell != l);

            } else {
                $scope.options.show_news_bell = true;
            }

        }, 1000);
    }

    function configLoad() {

        $scope.loader = true;

        $core.post("unirest/configmanage", { action: "CHECK" }).then(function (response) {

            $scope.configExists = response.exists;

            $scope.config = response.config;
            $scope.url = "";
            if ($scope.config != "" && UTILS.notNull($scope.config)) {
                $scope.url = (UTILS.notNull($scope.config.url)) ? $scope.config.url : response.url;
                $scope.url = $scope.url.replace("wp-json/api/v2/", ""); // Giusto per sicurezza...
            }
            $scope.clientConfig = "";

            if (!$scope.configExists) {
                systemCheck();
            } else {
                configUpdateCheck();
                createClientConfigCheck();
                $scope.loader = false;
            }

            if (UTILS.notNull($scope.config.data)) {
                $scope.config.data = JSON.parse($scope.config.data);
                $scope.options.include_api_desc = (UTILS.notNull($scope.config.data.include_api_desc)) ? $scope.config.data.include_api_desc : false;
            }

        }, function (response) {
            systemCheckError(response);
        });



    }

    function createClientConfigCheck() {

        $scope.options.client_config_need_update = false;

        $core.post("unirest/configmanage", { action: "CLIENT_CONFIG_UPDATE_CHECK" }).then(function (response) {

            if (!UTILS.notNull(response.client_config_check)) return;
            if (response.client_config_check == "") return;
            var check = JSON.parse(response.client_config_check);

            if (!UTILS.notNull(check.config_update)) return;

            if (!UTILS.notNull(check.config_date)) {
                $scope.options.client_config_need_update = true;
                return;
            }

            var difference = (new Date(check.config_update) - new Date(check.config_date)) / 1000;

            $scope.options.client_config_need_update = difference > 4;

            $scope.config.prefix = response.wp_tables_prefix;

        }, function (response) {
            $core.pop("INITIALIZATION", "Error reading Client Config update status.", "ERROR");
        });

    }

    function configUpdateCheck() {

        $core.post("unirest/configmanage", { action: "UPGRADE_CHECK", version: $scope.version }).then(function (response) {
            if (response.execute_update) {
                $core.say("SYSTEM UPDATE", "This UniREST Server version requires a system update.").then(function () {
                    $scope.loader = true;
                    $core.post("unirest/configmanage", { action: "UPGRADE_EXECUTE", version: $scope.version }).then(function (response) {
                        $scope.loader = false;
                        $core.pop("SYSTEM UPDATE", "Your UniREST Server system has been updated.", "OK");
                    }, function (response) {
                        $core.pop("SYSTEM UPDATE", "Error accessing to your Database upgrade info.", "ERROR");
                    });
                });
            } else {
            }
        }, function (response) {
            $core.pop("INITIALIZATION", "Error accessing to your Database upgrade info.", "ERROR");
        });

    }

    $scope.start = function () {

        $core.post("unirest/configcreate", {}).then(function (response) {

            if (response.status == "OK") {
                $core.say("CONFIGURATION", "Your UniREST Server has been configured.", "success");
                initialize();
            } else {
                if (response.status == "NO_DIR") $core.say("CONFIGURATION", "UniREST Server is trying to create a folder, but permission has been refused.", "error");
                if (response.status == "NO_FILES") $core.say("CONFIGURATION", "UniREST Server is trying to write system files in UNIREST folder, but permission has been refused.", "error");
            }

        }, function (response) {
            $core.pop("CONFIGURATION", "Error accessing to your Database.", "ERROR");
        });

    }

    $scope.createClientConfig = function () {

        $scope.loader = true;

        $core.post("unirest/system", { action: "UNIRESTAPIENGINE" }).then(function (response) {
            createClientConfig();
        }, function (response) {
            $core.say("CREATE CLIENT CONFIG", "An error occurred updating your APIs.", "error");
            $scope.loader = false;
        });

    }

    function createClientConfig() {

        $core.post("unirest/tablelist", { action: "ALL" }).then(function (response) {

            if (response.length == 0) {
                $core.say("CLIENT CONFIG", "Before to create the Client Configuration script, you should set up some Database tables and APIs.", "info");
                $scope.loader = false;
                return;
            }

            $scope.tablesList = response.list.map(function (item) { return item.replace("tfur_", ""); });
            $scope.tableCols = response.tableCols;

            $core.post("unirest/apimanage", { action: "LOAD_UPDATE", group: [], delete: [] }).then(function (response) {

                var apiCode = loadAPIGroups(response.data);

                $scope.showClientConfig = true;
                $scope.clientConfig = "";

                $scope.clientConfig += "/*" + "\n";
                $scope.clientConfig += "* =================================" + "\n";
                $scope.clientConfig += "*  TIGERFORGE UniREST Client v." + $scope.version + "\n";
                $scope.clientConfig += "* ---------------------------------" + "\n";
                $scope.clientConfig += "*     Configuration settings" + "\n";
                $scope.clientConfig += "* =================================" + "\n";
                $scope.clientConfig += "*/" + "\n";
                $scope.clientConfig += "" + "\n";
                $scope.clientConfig += "namespace TigerForge" + "\n";
                $scope.clientConfig += "{" + "\n";

                $scope.clientConfig += "public class UniRESTClientConfig" + "\n";
                $scope.clientConfig += "{" + "\n";

                $scope.clientConfig += 'public static string Key1 = "' + $scope.config.key1 + '";' + "\n";
                $scope.clientConfig += 'public static string Key2 = "' + $scope.config.key2 + '";' + "\n";
                $scope.clientConfig += 'public static string AppID = "' + $scope.config.key2.substr(4, 4) + '";' + "\n";
                /* $scope.clientConfig += '// New UniREST API Engine' + "\n"; */
                $scope.clientConfig += 'public static string ServerUrl = "' + $scope.url + 'UNIREST/";' + "\n";
                /* $scope.clientConfig += '// Old API Engine (obsolete, but still working with limitations)' + "\n";
                $scope.clientConfig += '//public static string ServerUrl = "' + $scope.url + 'wp-json/";' + "\n"; */

                $scope.clientConfig += "}" + "\n";

                $scope.clientConfig += "public static class API" + "\n";
                $scope.clientConfig += "{" + "\n";
                $scope.clientConfig += apiCode;
                $scope.clientConfig += "}" + "\n";

                $scope.clientConfig += "[System.Serializable]" + "\n";
                $scope.clientConfig += "public static class DB" + "\n";

                $scope.clientConfig += "{" + "\n";
                for (var i = 0; i < $scope.tablesList.length; i++) $scope.clientConfig += generateTableClass($scope.tablesList[i]);
                $scope.clientConfig += "}" + "\n";

                $scope.clientConfig += "}" + "\n";

                $scope.loader = false;

            }, function (response) { $core.say("CREATE CLIENT CONFIG", "An error occurred loading your tables data.", "error"); })

        }, function (response) {
            $core.say("CREATE CLIENT CONFIG", "An error occurred loading your tables data.", "error");
            $scope.loader = false;
        });

    }

    function generateTableClass(table) {

        var cols = $scope.tableCols["tfur_" + table];

        table = table.substr(0, 1).toUpperCase() + table.substr(1);

        var C = "";

        C += "[System.Serializable]" + "\n";
        C += "public class " + table + "\n";
        C += "{" + "\n";

        for (var i = 0; i < cols.length; i++) {

            if (cols[i].Type.indexOf("text") >= 0) C += "public string " + cols[i].Field + ' = "";' + "\n";
            if (cols[i].Type.indexOf("varchar") >= 0) C += "public string " + cols[i].Field + ' = "";' + "\n";
            if (cols[i].Type.indexOf("int") >= 0) C += "public int " + cols[i].Field + ' = 0;' + "\n";
            if (cols[i].Type.indexOf("float") >= 0) C += "public float " + cols[i].Field + ' = 0;' + "\n";
            if (cols[i].Type.indexOf("datetime") >= 0) C += "public string " + cols[i].Field + ' = "";' + "\n";

        }

        C += "}" + "\n\n";

        return C;

    }

    function loadAPIGroups(data) {

        var code = "";

        var n = data.length;
        for (var i = 0; i < n; i++) {

            var row = data[i];

            if (row.indexOf("//[UNIREST_API]") >= 0) {

                var tmp = row.replace("//[UNIREST_API]|", "")
                var desc = data[i + 1];

                if ($scope.options.include_api_desc && desc.length > 3) {
                    code += "///<summary>" + "\n";
                    code += "/" + desc + "\n";
                    code += "///</summary>" + "\n";
                }
                code += "public static string " + tmp.replace("/", "_") + " = \"" + tmp + "/" + "\";" + "\n";
            }

        }

        return code;

    }

    $scope.saveIncludeAPIsDesc = function () {
        $core.post("unirest/configmanage", { action: "DATA_SAVE", data: { include_api_desc: !$scope.options.include_api_desc } }).then(function (response) {

            if (response.data_save == "OK") $scope.createClientConfig();

        }, function (response) {
            $core.pop("UPDATE OPTIONS", "Error accessing to your Database.", "ERROR");
        });
    }

    $scope.go = function (path) {
        $core.go(path);
    }

    $(document).ready(function () {
        if ($core.currentPathIs("main")) {
            initialize();
            $core.hideWordPress();
        }
    });

    $scope.configToggleButton = function (id) {
        if ($("#" + id).css("right") == "0px") {
            $("#" + id).css({ "right": "0px" }).animate({ "right": "-346px" }, "fast");
        } else {
            $("#" + id).css({ "right": "-346px" }).animate({ "right": "0px" }, "fast");
        }

        if (id == "panel-news") {
            var l = $("#news-area").text().length;
            localStorage.setItem("ur_news_bell", l);
            $scope.options.show_news_bell = false;
        }
    }

    $scope.configSave = function () {

        $scope.config.url = $scope.url;

        $core.ask("SAVE SETTINGS", "You are going to update the UniREST Server Configuration. Proceed?").then(function (OK) {
            if (OK) {
                $scope.loader = true;
                $core.post("unirest/configmanage", { action: "SAVE", config: $scope.config }).then(function (response) {

                    $scope.configToggleButton();
                    initialize();

                }, function (response) {
                    $core.pop("SAVE SETTINGS", "Error accessing to your Database.", "ERROR");
                });
            }
        });

    }

    $scope.configCopyToClipboard = function () {
        $("#unityconfigscript").select();
        document.execCommand('copy');
        $core.pop("COPY", "The Unity script has been copied to Clipboard.", "OK");
    }


    $scope.apiBackup = function (action) {

        if (action == "EXPORT") {

            $scope.loader = true;

            $core.post("unirest/apibackup", { action: "EXPORT", type: $scope.backupType.selected }).then(function (response) {

                $scope.backup = JSON.stringify(response);

                $core.say("BACKUP READY!", "Your APIs backup is ready. Copy and save the provided text in a txt file.", "success");
                $scope.loader = false;

            }, function (response) {
                $core.pop("API BACKUP", "Error accessing API data.", "ERROR");
                $scope.loader = false;
            });

        } else if (action == "IMPORT") {

            if ($scope.backup == null || $scope.backup == "" || $scope.backup.length < 2 || typeof $scope.backup === "undefined") {
                $scope.backup = $("#sysbackup").val();
                if ($scope.backup == null || $scope.backup == "" || $scope.backup.length < 2 || typeof $scope.backup === "undefined") {
                    $core.say("IMPORT ERROR", "The backup text you provided is not valid and can't be used.", "error");
                    return;
                }
            }

            var backup = JSON.parse($scope.backup);

            var api = backup.api;
            var init = backup.init;
            var db = backup.db;

            if (!apiImportValid(api) || !apiImportValid(init)) {
                $core.say("ERROR!", "The backup text you provided is not valid and can't be used.", "error");
                return;
            }

            $scope.loader = true;

            $core.ask("BACKUP RESTORE", "You are going to restore a previously created backup. Proceed?").then(function (OK) {
                if (!OK) {
                    $scope.loader = false;
                    return;
                }

                $core.post("unirest/apibackup", { action: "IMPORT", api: api, init: init, db: db, type: $scope.backupType.selected }).then(function (response) {

                    $core.say("BACKUP RESTORED!", "Your APIs have been restored.", "success");
                    $scope.loader = false;

                }, function (response) {
                    $core.pop("API BACKUP", "Error accessing API data.", "ERROR");
                    $scope.loader = false;
                });
            });

        }

    }

    $scope.systemReset = function () {

        $core.ask("SYSTEM RESET", "This operation will delete all your Database tables, APIs and Keys. Proceed?").then(function (OK) {
            if (OK) {
                $core.ask("SYSTEM RESET", "Are you sure? The UniREST Server system will get back to its initial state and all the previously related data will be lost.").then(function (OK) {
                    if (OK) {
                        $scope.loader = true;
                        $core.post("unirest/system", { action: "RESET" }).then(function (response) {

                            $core.say("SYSTEM RESETTED!", "Now you can start using your UniREST Server application again.", "success").then(function (response) {
                                $scope.exit();
                                $scope.loader = false;

                            });

                        }, function (response) {
                            $core.pop("SYSTEM RESET", "Error resetting the System.", "ERROR");
                            $scope.loader = false;
                        });
                    }
                });
            }
        });

    }

    function systemCheck() {

        $core.post("unirest/system", { action: "CHECK" }).then(function (response) {

            $scope.systemCheck.hasError = false;
            $scope.systemCheck = response;
            $scope.systemCheck.hasPermissions = $scope.systemCheck.folderWriteTest && $scope.systemCheck.folderDeleteTest && $scope.systemCheck.fileWriteTest && $scope.systemCheck.fileDeleteTest;
            $scope.loader = false;

        }, function (response) {
            $core.pop("SYSTEM CHECK", "Error accessing the System.", "ERROR");
            $scope.loader = false;
        });

    }

    function systemCheckError(response) {
        $scope.loader = false;
        $core.pop("INITIALIZATION", "Error performing a POST call to your system.", "ERROR");
        $scope.systemCheck.hasError = true;
        $scope.systemCheck.error = {};
        $scope.systemCheck.error.msg = response.data.message + " (Status: " + response.status + ")";
        $scope.systemCheck.error.url = response.identifiedURL;
    }

    function apiImportValid(text) {

        if (text == "") return true;

        var pos1 = text.indexOf("<?php") >= 0;
        var pos2 = text.indexOf("?>") > 0;

        return pos1 && pos2;

    }

    $scope.exit = function () {

        $scope.loader = true;

        $("#adminmenumain").show();
        $("#wpadminbar").show();
        $("#wpfooter").show();

        window.location = "index.php";

    }

    $scope.refreshSystem = function () {
        $scope.loader = true;

        $core.post("unirest/system", { action: "UNIRESTAPIENGINE" }).then(function (response) {
            $core.pop("SYSTEM REFRESH", "Your System has been successfully refreshed. Enjoy your Server!", "OK");
            $scope.loader = false;
        }, function (response) {
            $core.say("SYSTEM REFRESH", "An error occurred updating your APIs.", "error");
            $scope.loader = false;
        });
    }

    $scope.allowSave = function () {
        if (!UTILS.notNull($scope.config.data.allow)) $scope.config.data.allow = "";

        $core.ask("SAVE ACCESS CONTROL", "You are going to apply the Access Control Allow Origin to the whole system. Proceed?").then(function (OK) {
            if (OK) {
                $scope.loader = true;
                $core.post("unirest/configmanage", { action: "DATA_SAVE", data: { allow: $scope.config.data.allow } }).then(function (response) {

                    if (response.data_save == "OK") $scope.createClientConfig();

                }, function (response) {
                    $core.pop("SAVE ACCESS CONTROL", "Error accessing to your Database.", "ERROR");
                });
            }
        });
    }

}]);