
jQuery(document).ready(function ($) {

    try {
        
        var tr = $("[data-slug='tigerforge-unirest-server']");

        if (tr.length == 0) return;
    
        var div = tr.find(".update-message");
    
        var p = div.find("p");
    
        var link = p.find(".update-link").attr("href");
    
        var tmp = p.find(".open-plugin-details-modal").text().split(" ");
        
        var version = "";
        for (var i = 0; i < tmp.length; i++) {
            if (!isNaN(tmp[i])) version = tmp[i];
        }
        
        var linkTemplate = '<a href="' + link + '" class="update-link" aria-label="Click here to update.">Click here to update!</a>';
    
        var newMessage = "UniREST Server v." + version + " is available. " + linkTemplate;
    
        p.html(newMessage);

    } catch (error) {        
    }


});