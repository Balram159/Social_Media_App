<?php

// Check if the UNIREST System is ready or still "virgin".
$TFUR_INSTALLED = file_exists(ABSPATH . "UNIREST/unirest.config.php");

// ===================================================================================================
// ===================================================================================================

add_action( 'rest_api_init', function () {
	
	// CONFIGURATION MANAGEMENT
	api("configmanage", "/unirest/configmanage");

	// CONFIG TABLE CREATION
	api("configcreate", "/unirest/configcreate");

	// TABLE LIST
	api("tablelist", "/unirest/tablelist");

	// TABLE CONTENT
	api("tablecontent", "/unirest/tablecontent");

	// TABLE CREATE
	api("tablecreate", "/unirest/tablecreate");

	// TABLE RECORD MANAGEMENT
	api("tablerecord", "/unirest/tablerecord");

	// TABLE MANAGEMENT
	api("tablemanage", "/unirest/tablemanage");

	// CUSTOM API MANAGEMENT
	api("apimanage", "/unirest/apimanage");

	// APIs BACKUP
	api("apibackup", "/unirest/apibackup");

	// SYSTEM FEATURES
	api("system", "/unirest/system");

	// USER FILES MANAGER
	api("userfilesmanage", "/unirest/userfilesmanage");

	// -------------------------
	// TEST
	api("test", "/test", "GET");
	
} );

// ===================================================================================================

include("api-engine.php");
include("server.php");

//include("client.php");
//if ($TFUR_INSTALLED) include(ABSPATH . "UNIREST/unirest.api.php");

function api_test(WP_REST_Request $request) {
	global $uniREST;

	$headers = array_change_key_case(getallheaders(), CASE_LOWER);

	$response = array();
	$response["server_url"] = home_url();
	$response["server_config"] = (isset($uniREST["Key1"])) ? "OK" : "ERROR";
	$response["unirest_installed"] = $GLOBALS["TFUR_INSTALLED"];
	$response["headers_user_agent"] = $headers["user-agent"]; 
	
	return $response;
}

// ===================================================================================================

function api($callBack, $path, $method = "POST") {

	$namespace = "api/v2";

	register_rest_route( $namespace, $path, array(
		'methods' => $method,
		'callback' => "api_" . $callBack,
		'permission_callback' => '__return_true'
	) );

}

function getData($request) {

	$dati = $request->get_body();
	return json_decode($dati);

}

function startsWith ($string, $startString) 
{ 
    $len = strlen($startString); 
    return (substr($string, 0, $len) === $startString); 
} 

function endsWith($string, $endString) 
{ 
    $len = strlen($endString); 
    if ($len == 0) { 
        return true; 
    } 
    return (substr($string, -$len) === $endString); 
} 

function contains($string, $substring) {
	return (strpos($string, $substring) !== false);
}

function createToken($type)
{
	return $type . rand(1000, 9999) . rand(1000, 9999);
}

// ================================================================================================
// DEPRECATED
// ================================================================================================

	// =========================
	//  UNIREST SYSTEM API INIT
	// =========================
	
	//[UNIREST_API]|unirest_server_call|server/call
	//api("unirest_server_call", "unirestclientserver/call");

	//[UNIREST_API]|unirest_server_connect|server/connect
	//api("unirest_server_connect", "unirestclientserver/connect");

	//[UNIREST_API]|unirest_user_login|user/login
	//api("unirest_user_login", "unirestclientuser/login");

	//[UNIREST_API]|unirest_user_registration|user/registration
	//api("unirest_user_registration", "unirestclientuser/registration");

	//[UNIREST_API]|unirest_server_newreadtoken|unirestclientserver/newreadtoken
	//api("unirest_server_newreadtoken", "unirestclientserver/newreadtoken");

	// =========================
	//  FILE MANAGER
	// =========================

	//[UNIREST_API]|unirest_file_manager|unirestclientserver/filemanager
	//api("unirest_file_manager", "unirestclientserver/filemanager");

	// =========================
	//  UNIREST CUSTOM API INIT
	// =========================

	//if ($GLOBALS["TFUR_INSTALLED"]) include(ABSPATH . "UNIREST/unirest.init.php");


?>