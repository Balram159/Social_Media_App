<?php

/*
=======================================
	APIs Generator
=======================================
*/

class UniRESTApiEngine {

    public $restFolder;
    public $config;

    public function __construct($config) 
    {
        $this->restFolder = "wp-content/plugins/tigerforge-unirest-server/api/rest/";
        $this->config = $config;
    }

    public function run() 
    {
        $this->delete_files("UNIREST/api");
		$this->mkDirs("UNIREST/api/v2/");

        $result = array();
        $result["builtin"] = $this->createUnirestApis();
        $result["user"] = $this->createUserApis();

		return $result;

    }

    private function createUnirestApis() 
    {
        $result = array();

        $DBdefs = $this->getWPconfig();
        $APIkeys = $this->getAPIkeys();
        
        $source = array();
        $source["DB"] = $this->readFile("class.DB.php", ["//{{_DB_ACCESSES_}}", $DBdefs]);
        $source["BI"] = $this->readFile("class.UniRESTbuiltin.php");
        $source["COM"] = $this->readFile("class.Comunication.php", ["//{{_KEYS_}}", $APIkeys]);

        $result["login"] = $this->createBuiltInAPI("login", "LOGIN", $source, true, "unirestclientuser");
        $result["registration"] = $this->createBuiltInAPI("registration", "REGISTRATION", $source, true, "unirestclientuser");
        $result["wplogin"] = $this->createBuiltInAPI("wplogin", "WPLOGIN", $source, true, "unirestclientuser");
        $result["wpregistration"] = $this->createBuiltInAPI("wpregistration", "WPREGISTRATION", $source, true, "unirestclientuser");
        $result["changepassword"] = $this->createBuiltInAPI("changepassword", "CHANGEPASSWORD", $source, true, "unirestclientuser");
        $result["synctableread"] = $this->createBuiltInAPI("synctableread", "SYNCTABLEREAD", $source, true, "unirestclientuser");
        $result["synctablewrite"] = $this->createBuiltInAPI("synctablewrite", "SYNCTABLEWRITE", $source, true, "unirestclientuser");
        $result["generateotp"] = $this->createBuiltInAPI("generateotp", "GENERATEOTP", $source, true, "unirestclientuser");

        $result["call"] = $this->createBuiltInAPI("call", "CALL", $source, false, "unirestclientserver");
        $result["connect"] = $this->createBuiltInAPI("connect", "CONNECT", $source, false, "unirestclientserver");
        $result["newreadtoken"] = $this->createBuiltInAPI("newreadtoken", "NEWREADTOKEN", $source, true, "unirestclientserver");
        $result["newwritetoken"] = $this->createBuiltInAPI("newwritetoken", "NEWWRITETOKEN", $source, true, "unirestclientserver");
        $result["newlogintoken"] = $this->createBuiltInAPI("newlogintoken", "NEWLOGINTOKEN", $source, true, "unirestclientserver");
        $result["gettokens"] = $this->createBuiltInAPI("gettokens", "GETTOKENS", $source, true, "unirestclientserver");
        $result["fileuploader"] = $this->createBuiltInAPI("fileuploader", "FILEUPLOADER", $source, false, "unirestclientserver");
        $result["filemanager2"] = $this->createBuiltInAPI("filemanager2", "FILEMANAGER2", $source, true, "unirestclientserver");

        // Load and Save only.
        $result["filemanager"] = $this->createBuiltInAPI("filemanager", "FILEMANAGER", $source, true, "unirestclientserver");

        return $result;

    }

    private function createUserApis()
    {
        $result = array();

        $DBdefs = $this->getWPconfig();
        $APIkeys = $this->getAPIkeys();

        $source = array();
        $source["DB"] = $this->readFile("class.DB.php", ["//{{_DB_ACCESSES_}}", $DBdefs]);
        $source["UAPI"] = $this->readFile("class.UniRESTapi.php");
        $source["COM"] = $this->readFile("class.Comunication.php", ["//{{_KEYS_}}", $APIkeys]);
        $source["AUTH"] = $this->readFile("class.UniRESTAuth.php");
		
		$apis = file("UNIREST/unirest.api.php", FILE_IGNORE_NEW_LINES);
		$n = count($apis);
		$found = false;
		$apiVars = "";
		$apiPath = "";
        $isCustomPHP = false;
        $customPHPWP = false;
        $customPHP = "";
		for ($i = 0; $i < $n; $i++) {

			if (strpos($apis[$i], "//[UNIREST_API]") !== false) {
				$found = true;
				$apiVars = "";
				$apiPath = str_replace("//[UNIREST_API]|", "", $apis[$i]);
			}

			if ($found && strpos($apis[$i], "unirest_db") !== false  && strpos($apis[$i], "apiEngine(") === false) {
				$apiVars .= $apis[$i] . "\n";
                if (strpos($apis[$i], "read_custom_query") !== false && strpos($apis[$i], "[CUSTOM_PHP]") !== false) $isCustomPHP = true;
                if (strpos($apis[$i], "update_custom_query") !== false && strpos($apis[$i], "[CUSTOM_PHP_WP]") !== false) $customPHPWP = true;
                if ($isCustomPHP && strpos($apis[$i], "write_custom_query") !== false) { 
                    $customPHP = $apis[$i];
                    $customPHP = str_replace('$unirest_db["write_custom_query"] = "', '', $customPHP);
                    $customPHP = str_replace('";', '', $customPHP);
                    $customPHP = base64_decode($customPHP);
                }
			}

			if ($found && strpos($apis[$i], "//[/UNIREST_API]") !== false) {

                $rootFolder = "UNIREST/api/v2/" . $apiPath . "/";
                $this->mkDirs($rootFolder);

                if ($isCustomPHP) 
                {
                    $indexPHP = "";

                    $indexPHP .= $this->getAccessControls();
                                        
                    if ($customPHPWP) {
                        $indexPHP .= "<?php\n";
                        $indexPHP .= 'require_once("../../../../../wp-load.php");' . "\n";
                        $indexPHP .= "?>" . "\n\n";
                    }

                    $indexPHP .= "<?php\n";
                    $indexPHP .= '$URCom = new Comunication();' . "\n";
                    $indexPHP .= '$URDb = new DB();' . "\n";
                    $indexPHP .= "?>" . "\n\n";

                    $indexPHP .= "<?php\n";
                    $indexPHP .= '$URAuth = new UniRESTAuth($URCom, $URDb);' . "\n";
                    $indexPHP .= '$URAuthResult = $URAuth->authToken();' . "\n";
                    $indexPHP .= 'if (!$URAuthResult["isAuth"]) {' . "\n\n";
                    $indexPHP .= '    $data = array();' . "\n";
                    $indexPHP .= '    $data["dberror"] = $URAuthResult["reason"];' . "\n";
                    $indexPHP .= '    $data["dbquery"] = "NO_AUTH";' . "\n";
                    $indexPHP .= '    $data["data"] = "";' . "\n\n";
                    $indexPHP .= '    $response = array();' . "\n";
                    $indexPHP .= '    $response["result"] = "ERROR";' . "\n";
                    $indexPHP .= '    $response["data"] = $URCom->EncryptJson($data);' . "\n\n";
                    $indexPHP .= '    die(json_encode($response));' . "\n";
                    $indexPHP .= '}' . "\n\n";
                    $indexPHP .= "?>" . "\n\n";

                    $indexPHP .= "<?php\n";
                    $indexPHP .= '$URdataPack = array();' . "\n";
                    $indexPHP .= '$URdataPack["tokenl"] = $URAuthResult["TOKENL"];' . "\n";
                    $indexPHP .= '$URdataPack["tokenr"] = $URAuthResult["TOKENR"];' . "\n";
                    $indexPHP .= '$URdataPack["tokenw"] = $URAuthResult["TOKENW"];' . "\n";
                    $indexPHP .= '$URdataPack["data"] = "";' . "\n\n";
                    $indexPHP .= '$URInput = $URAuth->getData();' . "\n";
                    $indexPHP .= '$UROutput = array();' . "\n";
                    $indexPHP .= "?>" . "\n\n";

                    $indexPHP .= $customPHP;
                    $indexPHP .= "\n\n<?php\n\n";
                    $indexPHP .= 'if ( isset($UROutput["result"]) && isset($UROutput["data"]) ) {' . "\n\n";
                    $indexPHP .= '$URdataPack["data"] = json_encode($UROutput["data"]);' . "\n";
                    $indexPHP .= '$UROutput["data"] = $URCom->EncryptJson($URdataPack);' . "\n";
                    $indexPHP .= 'die(json_encode($UROutput));' . "\n\n";
                    $indexPHP .= '}' . "\n\n";
                    $indexPHP .= "?>" . "\n\n";
                    $indexPHP .= $source["DB"];
                    $indexPHP .="\n\n";
                    $indexPHP .= $source["COM"];
                    $indexPHP .="\n\n";
                    
                    $indexPHP .= $source["AUTH"];
                    $indexPHP .="\n\n";

                    $result[$apiPath] = file_put_contents($rootFolder . "index.php", $indexPHP);
                } 
                else 
                {
                    $indexPHP = "";

                    $indexPHP .= $this->getAccessControls();

                    $indexPHP .= "<?php\n\n";

                    $indexPHP .= '$UR = new UniRESTapi();';
                    $indexPHP .= "\n\n";
    
                    $indexPHP .= $apiVars;
                    $indexPHP .= "\n\n";
    
                    $indexPHP .= '$UR->runAPI($unirest_db);';
                    $indexPHP .= "\n\n";
    
                    $indexPHP .="?>\n\n";
    
                    $indexPHP .= $source["UAPI"];
                    $indexPHP .="\n\n";
                    $indexPHP .= $source["DB"];
                    $indexPHP .="\n\n";
                    $indexPHP .= $source["COM"];
                    $indexPHP .="\n\n";

                    $result[$apiPath] = file_put_contents($rootFolder . "index.php", $indexPHP);
                }

				$found = false;
				$apiVars = "";
				$apiPath = "";
                $isCustomPHP = false;
                $customPHPWP = false;
                $customPHP = "";
			}
        }
        
        return $result;
    }

    private function getAccessControls() {
        $config = json_decode($this->config->data);
        $url = (isset($config->allow)) ? $config->allow : "";
        if ($url != "")
        {
            $indexPHP = "<?php\n";
            $indexPHP .= 'header("Access-Control-Allow-Origin: ' . $url . '");' . "\n";
            $indexPHP .= 'header("Access-Control-Allow-Methods: GET, POST");' . "\n";
            $indexPHP .= 'header("Access-Control-Allow-Headers: tokenw,tokenl,tokenr,tokeni,content-type");' . "\n";
            $indexPHP .= "?>\n\n";
        }
        else
        {
            $indexPHP = "";
        }

        return $indexPHP;
    }

    private function delete_files($target) {

        if (strlen($target) < 7) return;
        if (strpos($target, "UNIREST") === false) return;

        if(!is_link($target) && is_dir($target))
        {
            $files = array_diff( scandir($target), array('.', '..') );
            foreach($files as $file) {
                $this->delete_files("$target/$file");
            }
            rmdir($target);
        }
        else
        {
            if (file_exists($target)) unlink($target);
        }

    }

    private function mkDirs($path)
    {
        if (file_exists($path)) return true; else return mkdir($path, 0777, true);
    }

    private function getWPconfig()
    {
        $wpconfig = file("wp-config.php", FILE_IGNORE_NEW_LINES);
		$n = count($wpconfig);
		$DBdefs = "";
		for ($i = 0; $i < $n; $i++) {
			if (strpos($wpconfig[$i], "define") !== false && strpos($wpconfig[$i], "DB_") !== false) $DBdefs .= $wpconfig[$i] . "\n";
        }
        return $DBdefs;
    }

    private function getAPIkeys()
    {
        $content = file_get_contents("UNIREST/unirest.config.php");
        $content = str_replace("<?php", "", $content);
        $content = str_replace("?>", "", $content);
        return $content;
    }

    private function readFile($fileName, $replace = null) 
    {
        $content = file_get_contents($this->restFolder . $fileName);
        if ($replace != null) $content = str_replace($replace[0], $replace[1], $content);
        return $content;
    }

    private function createBuiltInAPI($api, $tag, $source, $hasDB, $rootFolder) 
    {
        global $uniREST;

        $result = array();
        $result["api"] = $api;

        $sourceCode = $source["BI"];
        $comClass = $source["COM"];
        $dbClass = $source["DB"];

        $this->mkDirs("UNIREST/" . substr($uniREST["Key2"], 4, 4) . "USER/");
        $this->mkDirs("UNIREST/" . substr($uniREST["Key2"], 4, 4) . "GAME/");

        $folder = "UNIREST/api/v2/" . $rootFolder . "/" . $api . "/";
        $result["folder"] = $this->mkDirs($folder);
        $fileName = $folder . "index.php";

        $code = "";
        $start_tag = "//{{" . $tag . "}}";
        $end_tag = "//{{/" . $tag . "}}";
        $startpos = strpos($sourceCode, $start_tag) + strlen($start_tag);
        if ($startpos !== false) {
            $endpos = strpos($sourceCode, $end_tag, $startpos);
            if ($endpos !== false) {
                $code = substr($sourceCode, $startpos, $endpos - $startpos);
            }
        }

        $indexPHP = "";

        $indexPHP .= $this->getAccessControls();

        $indexPHP .= "<?php\n\n";
        $indexPHP .= $code;
        $indexPHP .= "\n\n?>\n\n";

        $indexPHP .= $comClass;
        $indexPHP .= "\n\n";
        if ($hasDB) $indexPHP .= $dbClass;

        $result["file"] = file_put_contents($fileName, $indexPHP);

        return $result;

    }

}


?>