<?php

class Comunication {

    public $key1;
    public $key2;

    public function __construct() 
    {
        //{{_KEYS_}}

        $this->key1 = $uniREST["Key1"];
        $this->key2 = $uniREST["Key2"];
    }

    public function Encrypt($plaintext) 
    {  
        $encrypted = base64_encode(openssl_encrypt($plaintext, 'aes-256-cbc', $this->key1, OPENSSL_RAW_DATA, $this->key2));
        return $encrypted;
    }
    
    public function EncryptJson($data) 
    {    
        $plaintext = json_encode($data);
        $encrypted = base64_encode(openssl_encrypt($plaintext, 'aes-256-cbc', $this->key1, OPENSSL_RAW_DATA, $this->key2));
        return $encrypted;
    }
    
    public function Decrypt($encrypted) 
    {
        $decrypted = openssl_decrypt(base64_decode($encrypted), 'aes-256-cbc', $this->key1, OPENSSL_RAW_DATA, $this->key2);
        return $decrypted;
    }
    
    public function DecryptJson($data) 
    {
        $encrypted = json_encode($data);
        $decrypted = openssl_decrypt(base64_decode($encrypted), 'aes-256-cbc', $this->key1, OPENSSL_RAW_DATA, $this->key2);
        return json_decode($decrypted);
    }

    public function DecryptPHPinput() 
    {
        $encrypted = file_get_contents("php://input");
        $decrypted = openssl_decrypt(base64_decode($encrypted), 'aes-256-cbc', $this->key1, OPENSSL_RAW_DATA, $this->key2);
        return $decrypted;
    }

    public function DecryptJsonPHPinput() 
    {
        $data = file_get_contents("php://input");
        $encrypted = json_encode($data);
        $decrypted = openssl_decrypt(base64_decode($encrypted), 'aes-256-cbc', $this->key1, OPENSSL_RAW_DATA, $this->key2);
        return json_decode($decrypted);
    }

    public function GetAllHeaders()
    {
        return array_change_key_case(getallheaders(), CASE_LOWER);
    }

    public function GetKey2() 
    {
        return $this->key2;
    }

    public function GetAppID() 
    {
        return substr($this->key2, 4, 4);
    }

    public function GetUSERFolder($userID = 0) 
    {
        return substr($this->key2, 4, 4) . "USER/" . (($userID == 0) ? "" : $userID . "/");
    }

    public function GetGAMEFolder() 
    {
        return substr($this->key2, 4, 4) . "GAME/";
    }

}

?>