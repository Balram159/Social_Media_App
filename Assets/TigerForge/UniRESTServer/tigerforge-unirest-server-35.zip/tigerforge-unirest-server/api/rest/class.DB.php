<?php

class DB
{

	protected $MySQL;
	protected $query;
	protected $query_closed = TRUE;

	public $query_count = 0;
	public $info;

	public function __construct($dbhost = "localhost", $dbuser = "root", $dbpass = "", $dbname = "", $charset = "utf8")
	{

		//{{_DB_ACCESSES_}}

		$dbhost = DB_HOST;
		$dbuser = DB_USER;
		$dbpass = DB_PASSWORD;
		$dbname = DB_NAME;
		$charset = DB_CHARSET;

		$this->info["query"] = "";
		$this->info["error"] = "";

		$this->MySQL = new mysqli($dbhost, $dbuser, $dbpass, $dbname);
		if ($this->MySQL->connect_error) {
			$this->error($this->MySQL->connect_error);
		}
		$this->MySQL->set_charset($charset);
	}

	public function query($query)
	{

		$this->info["query"] = $query;
		$this->info["error"] = "";

		if (!$this->query_closed) {
			$this->query->close();
		}
		if ($this->query = $this->MySQL->prepare($query)) {

			if (func_num_args() > 1) {
				$x = func_get_args();
				$args = array_slice($x, 1);
				$types = "";
				$args_ref = array();
				foreach ($args as $k => &$arg) {
					if (is_array($args[$k])) {
						foreach ($args[$k] as $j => &$a) {
							$types .= $this->_gettype($args[$k][$j]);
							$args_ref[] = &$a;
						}
					} else {
						$types .= $this->_gettype($args[$k]);
						$args_ref[] = &$arg;
					}
				}
				array_unshift($args_ref, $types);
				call_user_func_array(array($this->query, "bind_param"), $args_ref);
			}

			$this->query->execute();
			if ($this->query->errno) {
				$this->error($this->query->error);
			}

			$this->query_closed = FALSE;
			$this->query_count++;
		} else {
			$this->error($this->MySQL->error);
		}
		return $this;
	}


	public function fetchAll($callback = null)
	{
		$params = array();
		$row = array();
		$result = array();

		if (!$this->query) return null;

		$meta = $this->query->result_metadata();

		while ($field = $meta->fetch_field()) {
			$params[] = &$row[$field->name];
		}

		call_user_func_array(array($this->query, "bind_result"), $params);

		while ($this->query->fetch()) {
			$r = array();
			foreach ($row as $key => $val) {
				$r[$key] = $val;
			}
			if ($callback != null && is_callable($callback)) {
				$value = call_user_func($callback, $r);
				if ($value == "break") break;
			} else {
				$result[] = $r;
			}
		}
		$this->query->close();
		$this->query_closed = TRUE;
		return $result;
	}

	public function fetchArray()
	{
		$params = array();
		$row = array();
		$result = array();

		if (!$this->query) return null;

		$meta = $this->query->result_metadata();

		while ($field = $meta->fetch_field()) {
			$params[] = &$row[$field->name];
		}

		call_user_func_array(array($this->query, "bind_result"), $params);

		while ($this->query->fetch()) {
			foreach ($row as $key => $val) {
				$result[$key] = $val;
			}
		}
		$this->query->close();
		$this->query_closed = TRUE;
		return (object)$result;
	}

	public function close()
	{
		return $this->MySQL->close();
	}

	public function numRows()
	{
		$this->query->store_result();
		return $this->query->num_rows;
	}

	public function affectedRows()
	{
		return $this->query->affected_rows;
	}

	public function lastInsertID()
	{
		return $this->MySQL->insert_id;
	}

	public function error($error)
	{
		$this->info["error"] = $error;
	}

	private function _gettype($var)
	{
		if (is_string($var)) return "s";
		if (is_float($var)) return "d";
		if (is_int($var)) return "i";
		return "b";
	}



	public function select($table, $where = "", $what = "*", $options = "")
	{
		$query = "SELECT $what FROM $table ";

		if ($where != "") {
			$where = $this->createSet($where, " AND ");
			$query = "SELECT $what FROM $table WHERE " . $where["markers"];
		}

		if ($options != "")  $query .= " " . $options;

		if ($where != "") $data = $this->query($query, $where["values_array"])->fetchAll();
		else $data = $this->query($query)->fetchAll();
		return $data;
	}

	public function selectOne($table, $where = "", $what = "*", $options = "")
	{
		$query = "SELECT $what FROM $table ";

		if ($where != "") {
			$where = $this->createSet($where, " AND ");
			$query = "SELECT $what FROM $table WHERE " . $where["markers"];
		}

		if ($options != "") $query .= " " . $options;

		if ($where != "") $data = $this->query($query, $where["values_array"])->fetchArray();
		else $data = $this->query($query)->fetchArray();
		return $data;
	}

	public function insert($table, $data)
	{

		$insert = $this->createInsert($data);
		$query = "INSERT INTO $table (" . $insert["columns"] . ") VALUES (" . $insert["values_markers"] . ")";
		$insert = $this->query($query, $insert["values_array"]);
		return $this->lastInsertID();
	}

	public function update($table, $data, $where)
	{
		$set = $this->createSet($data, ", ");
		$where = $this->createSet($where, " AND ");
		$query = "UPDATE $table SET " . $set["markers"] . " WHERE " . $where["markers"];
		$update = $this->query($query, array_merge($set["values_array"], $where["values_array"]));
		return $update->affectedRows();
	}

	public function updateById($table, $data, $id)
	{
		return $this->update($table, $data, array("id" => $id));
	}

	public function delete($table, $where)
	{
		$where = $this->createSet($where, " AND ");
		$query = "DELETE FROM $table WHERE " . $where["markers"];
		$delete = $this->query($query, $where["values_array"]);
		return $delete->affectedRows();
	}

	public function execute($query, $data, $type, $table)
	{
		$query = str_replace("[[*]]", $table, $query);
		$query = str_replace("[[", "tfur_", $query);
		$query = str_replace("]]", "", $query);

		$valuesArray = array();
		$tmp = str_replace("{", "|", $query);
		$tmp = str_replace("}", "|", $tmp);
		$parts = explode("|", $tmp);
		foreach ($parts as $p) {
			if (isset($data[$p])) $valuesArray[] = $data[$p];
		}

		foreach ($data as $key => $value) {
			$tag = "{" . $key . "}";
			$query = str_replace($tag, "?", $query, $count);
		}

		if ($type == "SELECT") {
			if (count($valuesArray) == 0) {
				$data = $this->query($query)->fetchAll();
			} else {
				$data = $this->query($query, $valuesArray)->fetchAll();
			}
			return $data;
		} else if ($type == "INSERT") {
			$insert = $this->query($query, $valuesArray);
			return $this->lastInsertID();
		} else if ($type == "UPDATE") {
			$update = $this->query($query, $valuesArray);
			return $update->affectedRows();
		} else if ($type == "DELETE") {
			$delete = $this->query($query, $valuesArray);
			return $delete->affectedRows();
		}
	}

	public function exists($table, $where)
	{
		return $this->count($table, $where) > 0;
	}

	public function count($table, $where)
	{
		$where = $this->createSet2($where, " AND ");
		$query = "SELECT COUNT(*) FROM $table WHERE " . $where["markers"];
		$exists = $this->query($query, $where["values_array"])->fetchArray();
		foreach (get_object_vars($exists) as $var => $val) $result = $val;
		return $result;
	}

	public function math($table, $where, $what, $formula)
	{
		$result = "";
		$record = $this->selectOne($table, $where, $what);
		if (!isset($record->$what)) return "ERROR|RECORD_NOT_FOUND|0|";

		$pattern = "/^[0-9-+().*\/ X]+$/";
		if (!preg_match($pattern, $formula)) return "ERROR|FORMULA_ERROR|" . $record->$what . "|";

		$value = $record->$what;
		if (strpos($formula, "X") === false) $formula = $value . $formula;
		else $formula = str_replace("X", $value, $formula);

		eval("\$result = $formula;");

		$this->update($table, array($what => $result), $where);

		return $result;
	}

	public function updateJSON($table, $where, $what, $data)
	{
		$record = $this->selectOne($table, $where, $what);
		if (!isset($record->$what)) return 0;

		$newValue = "";
		if ($record->$what == "" || $record->$what == null) {

			$newValue = $data;
		} else {

			$jData = json_decode($data);
			$colValue = json_decode($record->$what);

			foreach ($jData as $key => $value) {
				$colValue->$key = $value;
			}
			$newValue = json_encode($colValue);
		}

		return $this->update($table, array($what => $newValue), $where);
	}

	private function createSet($data, $joiner)
	{
		$markers = [];
		$values = [];

		foreach ($data as $column => $value) {
			$markers[] = $column . "=?";
			$values[] = $value;
		}
		$set["markers"] = implode($joiner, $markers);
		$set["values_array"] = $values;
		return $set;
	}

	private function createSet2($data, $joiner)
	{
		$markers = [];
		$values = [];
		$operator = "";

		foreach ($data as $column => $value) {

			$operator = "=";
			if (strpos($column, "%") !== false) {
				if (substr($column, 0, 1) == "%") $value = "%" . $value;
				if (substr($column, -1) == "%") $value = $value . "%";
				$column = str_replace("%", "", $column);
				$operator = " LIKE ";
			} else if (strpos($column, "!") !== false) {
				$column = str_replace("!", "", $column);
				$operator = "!=";
			} else if (strpos($column, ">=") !== false) {
				$column = str_replace(">=", "", $column);
				$operator = ">=";
			} else if (strpos($column, "<=") !== false) {
				$column = str_replace("<=", "", $column);
				$operator = "<=";
			} else if (strpos($column, ">") !== false) {
				$column = str_replace(">", "", $column);
				$operator = ">";
			} else if (strpos($column, "<") !== false) {
				$column = str_replace("<", "", $column);
				$operator = "<";
			}

			$markers[] = $column . $operator . "?";
			$values[] = $value;
		}
		$set["markers"] = implode($joiner, $markers);
		$set["values_array"] = $values;
		return $set;
	}

	private function createInsert($data)
	{
		$columns = [];
		$values = [];
		$markers = [];

		foreach ($data as $column => $value) {
			$columns[] = $column;
			$values[] = $value;
			$markers[] = "?";
		}
		$insert["columns"] = implode(', ', $columns);
		$insert["values_array"] = $values;
		$insert["values_markers"] = implode(', ', $markers);
		return $insert;
	}

	public function createToken($type)
	{
		return $type . rand(1000, 9999) . rand(1000, 9999);
	}

	public function mkDirs($path)
	{
		if (file_exists($path)) return true;
		else return mkdir($path, 0777, true);
	}

	/* DEPRECATED 3.4 16/05/2022
	public function checkLoginToken($userID, $L) 
	{
		$tokens = $this->selectOne("tfur_users", array("id" => $userID));
		return ($tokens->tokenl == $L);
	}*/
}

?>
