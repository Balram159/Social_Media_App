<?php

class UniRESTAuth {

    protected $headers;
    protected $DB;

    public function __construct($URCom, $URDb) {

        $this->comunication = $URCom;
        $this->headers = array_change_key_case(getallheaders(), CASE_LOWER);
        $this->DB = $URDb;
        $this->POST = file_get_contents("php://input");

    }

    public function getData() {
        $COM = $this->comunication;

        $body = $COM->DecryptJson($this->POST);
        return json_decode($body->data, true);
    }

    public function authToken() {
        $DB = $this->DB;

        $headers = $this->headers;

        if (!isset($headers["tokenl"])) {
            $response = array();
            $response["isAuth"] = false;
            $response["reason"] = "HEADERS_DATA_MISSING:".implode("|", $headers);
            return $response;
        }
    
        $L = $headers["tokenl"];
        $R = $headers["tokenr"];
        $W = $headers["tokenw"];
        $ID = $headers["tokeni"];
    
        if ($L == "" || $R == "" || $W == "" || $ID == "" || $ID == 0) {
            $response = array();
            $response["isAuth"] = false;
            $response["reason"] = "HEADERS_DATA_MISSING:$L|$R|$W|$ID|".implode("|", $headers);
            return $response;
        }
    
        //DEPRECATED $tokens = $DB->selectOne("tfur_users", array("id" => $ID));
    
        $response = array();
        $response["isAuth"] = true;
        $response["TOKENL"] = $L;
        $response["TOKENR"] = $R;
        $response["TOKENW"] = $W;
        
        /*
        DEPRECATED 3.4 16/05/2022
        
        if ($tokens->tokenl != $L) {
            $response["isAuth"] = false;
            $response["reason"] = "L_TOKEN_ERROR: " . $tokens->tokenl . "|" . $L;
        }*/
    
        return $response;
    
    }

    private function createToken($type)
    {
        return $type . rand(1000, 9999) . rand(1000, 9999);
    }

}


?>