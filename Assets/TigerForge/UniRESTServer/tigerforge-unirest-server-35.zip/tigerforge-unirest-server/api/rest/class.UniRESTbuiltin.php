<?php

function api_unirest_server_call() 
{
    //{{CALL}}
    $COM = new Comunication();

	$date = new DateTime();
	$date = $date->getTimestamp();
	$code = $COM->Encrypt($date);

	$response = array();
	$response["result"] = "OK";
	$response["data"] = $code;

    die(json_encode($response));
    //{{/CALL}}

}

function api_unirest_server_connect() 
{

	//{{CONNECT}}
	$COM = new Comunication();

	$date = new DateTime();
	$date = $date->getTimestamp();
	
	$reply = $COM->DecryptJsonPHPinput();
	$replyDate = $reply->data;

	$diff = $replyDate - $date;

	$response = array();
	$response["result"] = ($diff > 0) ? "OK" : "TIMEOUT";
	$response["data"] = "";

	die(json_encode($response));
	//{{/CONNECT}}

}

function api_unirest_user_login() 
{

	//{{LOGIN}}
	$COM = new Comunication();
	$DB = new DB();

	$reply = $COM->DecryptJsonPHPinput();
	$username = $reply->username;
	$password = $reply->password;
	$changeToken = $reply->lastLoginDate;

	if ($username == "" || $password == "") {

		$isOK = "ERROR";
		$data = "";

	} else {

		$user = $DB->selectOne("tfur_users", array("username" => $username));

		$isOK = ($user->password == $password) ? "OK" : "ERROR";

		$data = "";
		if ($isOK == "OK") {
			
			if ($changeToken == "_NO_TOKEN_CHANGE_") {
				if (strlen($user->tokenl) >= 8) {
					$tokenL =  $user->tokenl;
					$tokenR =  $user->tokenr;
					$tokenW =  $user->tokenw;
				}
				else
				{
					$tokenL =  $DB->createToken("L");
					$tokenR =  $DB->createToken("R");
					$tokenW =  $DB->createToken("W");
				}
			}
			else
			{
				$tokenL =  $DB->createToken("L");
				$tokenR =  $DB->createToken("R");
				$tokenW =  $DB->createToken("W");
			}

			$logDate = $user->logdate;
			$regDate = $user->regdate;
			
			$DB->updateById(
				"tfur_users", 
				array(
					"tokenl"	=> $tokenL,
					"tokenr"	=> $tokenR,
					"tokenw"	=> $tokenW,
					"logdate"	=> date("Y-m-d H:i:s")
				), 
				$user->id
			);

			$data = $COM->Encrypt("$tokenL|$tokenR|$tokenW|" . $user->id . "|$logDate|$regDate");

		}

	}

	$response = array();
	$response["result"] = $isOK;
	$response["data"] = $data;

	die(json_encode($response));
	//{{/LOGIN}}

}

function api_unirest_user_registration() 
{

	//{{REGISTRATION}}
	$COM = new Comunication();
	$DB = new DB();

	$body = $COM->DecryptJsonPHPinput();

	$username = $body->username;
	$password = $body->password;
	$id = 0;

	if ($username == "" || $password == "") {

		$isOK = false;

	} else {

		$isOK = !$DB->exists("tfur_users", array("username" => $username));

		if ($isOK) {

			$id = $DB->insert("tfur_users", array("username" => $username, "password" => $password, "regdate" => date("Y-m-d H:i:s")));
			$isOK = $id > 0;

		}

	}

	$response = array();
	$response["result"] = ($isOK) ? "OK" : "INVALID";
	$response["data"] = $id;

	die(json_encode($response));
	//{{/REGISTRATION}}

}

function api_unirest_wordpress_user_login() 
{

	//{{WPLOGIN}}
	$COM = new Comunication();
	$DB = new DB();

	require_once("../../../../../wp-includes/class-phpass.php");
	require_once("../../../../../wp-includes/formatting.php"); // Added in 3.5

	$body = $COM->DecryptJsonPHPinput();
	$username = $body->username;
	$password = $body->password;
	$clearPass = $body->useWordPressUsers;

	$data = "";
	$logDate = "";
	$regDate = "";
	$userExists = false;
	$ID = 0;

	if ($username == "" || $password == "" || $clearPass == "") {

		$isOK = "ERROR";
		$data = $COM->Encrypt("INVALID");

	} else {

		$wp_user_field = "user_login";
		if (substr($username, 0, 6) == "email:") {
			$username = substr($username, 6);
			$wp_user_field = "user_email";
		}

		$canUR = $DB->exists("tfur_users", array("username" => $username));

		$config = $DB->selectOne("tfdb_config", array("id" => 1));
		$data = json_decode($config->data);
		$canWP = $DB->exists($data->wpPrefix . "users", array($wp_user_field => $username));
		$clearPass = wp_slash($clearPass); // Added in 3.5

		if ($canUR && $canWP)
		{

			$WPuser = $DB->selectOne($data->wpPrefix . "users", array($wp_user_field => $username));
			$wp_hasher = new PasswordHash( 8, true );
			$checkPass = $wp_hasher->CheckPassword($clearPass, $WPuser->user_pass);

			if ($checkPass) {

				$isOK = "OK";

			} else {

				$isOK = "ERROR";
				$data = $COM->Encrypt("PASS_ERROR");

			}

		} 
		else if ($canWP && !$canUR) 
		{

			$WPuser = $DB->selectOne($data->wpPrefix . "users", array($wp_user_field => $username));
			$wp_hasher = new PasswordHash( 8, true );
			$checkPass = $wp_hasher->CheckPassword($clearPass, $WPuser->user_pass);

			if ($checkPass) {

				$ID = $DB->insert("tfur_users", array("username" => $username, "password" => $password, "regdate" => date("Y-m-d H:i:s")));
				if ($ID > 0) {
					$isOK = "OK";
				} else {
					$isOK = "ERROR";
					$data = $COM->Encrypt("CANT_REGISTER");
				}

			} else {

				$isOK = "ERROR";
				$data = $COM->Encrypt("PASS_ERROR");

			}

		} 
		else if ($canUR && !$canWP) 
		{

			$URuser = $DB->selectOne("tfur_users", array("username" => $username));
			$checkPass = ($URuser->password == $password);

			if ($checkPass) {

				$wp_hasher = new PasswordHash( 8, true );
				$hashed = $wp_hasher->HashPassword($clearPass);
				$wpUserID = $DB->insert($data->wpPrefix . "users", array("user_login" => $username, "user_pass" => $hashed));

				$isOK = "OK";

			} else {

				$isOK = "ERROR";
				$data = $COM->Encrypt("PASS_ERROR");

			}

		} 
		else 
		{
			$isOK = "ERROR";
			$data = $COM->Encrypt("NO_ACCOUNT");
		}


		if ($isOK == "OK") {

			$URuser = $DB->selectOne("tfur_users", array("username" => $username));
			$ID = $URuser->id;
			$logDate = $URuser->logdate;
			$regDate = $URuser->regdate;

			$tokenL =  $DB->createToken("L");
			$tokenR =  $DB->createToken("R");
			$tokenW =  $DB->createToken("W");
			
			$DB->updateById(
				"tfur_users", 
				array(
					"tokenl"	=> $tokenL,
					"tokenr"	=> $tokenR,
					"tokenw"	=> $tokenW,
					"logdate"	=> date("Y-m-d H:i:s")
				), 
				$ID
			);

			$data = $COM->Encrypt("$tokenL|$tokenR|$tokenW|" . $ID. "|$logDate|$regDate");

		}

	}

	$response = array();
	$response["result"] = $isOK;
	$response["data"] = $data;

	die(json_encode($response));
	//{{/WPLOGIN}}

}

function api_unirest_wordpress_user_registration() 
{

	//{{WPREGISTRATION}}
	$COM = new Comunication();
	$DB = new DB();

	require_once("../../../../../wp-includes/class-phpass.php");
	require_once("../../../../../wp-includes/formatting.php"); // Added in 3.5

	$body = $COM->DecryptJsonPHPinput();

	$username = $body->username;
	$password = $body->password;
	$clearPass = $body->useWordPressUsers;
	$responseData = 0;

	if ($username == "" || $password == "" || $clearPass == "") {

		$isOK = false;
		$responseData = "INVALID";

	} else {

		$canUR = !$DB->exists("tfur_users", array("username" => $username));

		$config = $DB->selectOne("tfdb_config", array("id" => 1));
		$data = json_decode($config->data);
		$canWP = !$DB->exists($data->wpPrefix . "users", array("user_login" => $username));
		$clearPass = wp_slash($clearPass); // Added in 3.5

		if ($canUR && $canWP) {

			$userID = $DB->insert("tfur_users", array("username" => $username, "password" => $password, "regdate" => date("Y-m-d H:i:s")));
			$isOK = $userID > 0;
			$responseData = $userID;

			if ($isOK) {

				$wp_hasher = new PasswordHash( 8, true );
				$hashed = $wp_hasher->HashPassword($clearPass);
				$wpUserID = $DB->insert($data->wpPrefix . "users", array("user_login" => $username, "user_pass" => $hashed));

			} else {

				$responseData = "CANT_REGISTER";

			}

		} else {

			$isOK = false;
			$responseData = (!$canUR) ? "ALREADY_IN_UR" : "ALREADY_IN_WP";

		}

	}

	$response = array();
	$response["result"] = ($isOK) ? "OK" : "ERROR";
	$response["data"] = $responseData;

	die(json_encode($response));
	//{{/WPREGISTRATION}}

}

function api_unirest_change_password() 
{

	//{{CHANGEPASSWORD}}
	$COM = new Comunication();
	$DB = new DB();

	require_once("../../../../../wp-includes/class-phpass.php");
	require_once("../../../../../wp-includes/formatting.php"); // Added in 3.5

	$body = $COM->DecryptJsonPHPinput();

	$username = $body->data1;
	$oldPassword = $body->data2;
	$newPassword = $body->data3;
	$clearOldPass = $body->data4;
	$clearNewPass = $body->data5;
	$isWordPress = ($body->data6 == "WP");

	$responseData = 0;

	if ($username == "" || $oldPassword == "" || $newPassword == "" || $clearOldPass == "" || $clearNewPass == "") {

		$isOK = false;
		$responseData = "INVALID";

	} else {

		$canUR = $DB->exists("tfur_users", array("username" => $username));

		$canWP = true;
		if ($isWordPress) {
			$config = $DB->selectOne("tfdb_config", array("id" => 1));
			$data = json_decode($config->data);
			$canWP = $DB->exists($data->wpPrefix . "users", array("user_login" => $username));
		}

		$clearOldPass = wp_slash($clearOldPass); // Added in 3.5
		$clearNewPass = wp_slash($clearNewPass); // Added in 3.5

		if ($canUR && $canWP) {

			$URuser = $DB->selectOne("tfur_users", array("username" => $username));

			// OTP added in 3.5
			$isOTP = false;
			if (substr($clearOldPass, 0, 5) == "[OTP]" && substr($clearOldPass, -6) == "[/OTP]") {
				$clearOldPass = str_replace("[OTP]", "", $clearOldPass);
				$clearOldPass = str_replace("[/OTP]", "", $clearOldPass);
				$isOTP = true;
			}

			if ($isOTP) {

				$OTP = strrev($clearOldPass);
				$pass = $URuser->password;
				$checkPass = (strpos($pass, $OTP) !== false);

			} else {
				$checkPass = ($URuser->password == $oldPassword);
			}

			if ($checkPass) 
			{
				$isOK = true;
				$responseData = $URuser->id;
				$DB->updateById("tfur_users", array("password" => $newPassword), $responseData);
			} 
			else 
			{
				$isOK = false;
				$responseData = "PASS_ERROR";
			}

			if ($isWordPress) {

				$WPuser = $DB->selectOne($data->wpPrefix . "users", array("user_login" => $username));
				$wp_hasher = new PasswordHash( 8, true );
				
				if ($isOTP && $checkPass) {
					$checkPass = true;
				} else {
					$checkPass = $wp_hasher->CheckPassword($clearOldPass, $WPuser->user_pass);
				}
	
				if ($checkPass) 
				{
					$isOK = true;
					$wp_hasher = new PasswordHash( 8, true );
					$hashed = $wp_hasher->HashPassword($clearNewPass);
					$wpUserID = $DB->updateById($data->wpPrefix . "users", array("user_pass" => $hashed), $WPuser->ID);
				} 
				else 
				{
					$isOK = false;
					$responseData = "PASS_ERROR";
				}

			}


		} else {

			$isOK = false;
			$responseData = "CANT_UPDATE";

		}

	}

	$response = array();
	$response["result"] = ($isOK) ? "OK" : "INVALID";
	$response["data"] = $responseData;

	die(json_encode($response));
	//{{/CHANGEPASSWORD}}

}


function api_unirest_server_newreadtoken() 
{
	//{{NEWREADTOKEN}}
	$COM = new Comunication();
	$DB = new DB();

	$headers = $COM->GetAllHeaders();

	$L = $headers["tokenl"];
	$R = $headers["tokenr"];
	$W = $headers["tokenw"];
	$ID = $headers["tokeni"];

	if ($L == "" || $R == "" || $W == "" || $ID == "" || $ID == 0) {
		$response = array();
		$response["result"] = "ERROR";
		die(json_encode($response));
	}

	$data = array();
	$data["tokenl"] = $L;
	$data["tokenr"] = $R;
	$data["tokenw"] = $W;
	$data["data"] = "";
	
	$tokenr = $DB->createToken("R");
	$DB->updateById("tfur_users", array("tokenr" => $tokenr), $ID);
	$data["data"] = $tokenr;

	$info = $DB->info;
	$data["dberror"] = $info["error"];
	$data["dbquery"] = $info["query"];

	$response = array();
	$response["result"] = "OK";
	$response["data"] = $COM->EncryptJson($data);

	die(json_encode($response));
	//{{/NEWREADTOKEN}}

}

function api_unirest_server_newwritetoken() 
{
	//{{NEWWRITETOKEN}}
	$COM = new Comunication();
	$DB = new DB();

	$headers = $COM->GetAllHeaders();

	$L = $headers["tokenl"];
	$R = $headers["tokenr"];
	$W = $headers["tokenw"];
	$ID = $headers["tokeni"];

	if ($L == "" || $R == "" || $W == "" || $ID == "" || $ID == 0) {
		$response = array();
		$response["result"] = "ERROR";
		die(json_encode($response));
	}

	$data = array();
	$data["tokenl"] = $L;
	$data["tokenr"] = $R;
	$data["tokenw"] = $W;
	$data["data"] = "";
	
	$tokenw = $DB->createToken("W");
	$DB->updateById("tfur_users", array("tokenw" => $tokenw), $ID);
	$data["data"] = $tokenw;

	$info = $DB->info;
	$data["dberror"] = $info["error"];
	$data["dbquery"] = $info["query"];

	$response = array();
	$response["result"] = "OK";
	$response["data"] = $COM->EncryptJson($data);

	die(json_encode($response));
	//{{/NEWWRITETOKEN}}

}

function api_unirest_server_newlogintoken() 
{
	//{{NEWLOGINTOKEN}}
	$COM = new Comunication();
	$DB = new DB();

	$headers = $COM->GetAllHeaders();

	$L = $headers["tokenl"];
	$R = $headers["tokenr"];
	$W = $headers["tokenw"];
	$ID = $headers["tokeni"];

	if ($L == "" || $R == "" || $W == "" || $ID == "" || $ID == 0) {
		$response = array();
		$response["result"] = "ERROR";
		die(json_encode($response));
	}

	$data = array();
	$data["tokenl"] = $L;
	$data["tokenr"] = $R;
	$data["tokenw"] = $W;
	$data["data"] = "";
	
	$tokenl = $DB->createToken("L");
	$DB->updateById("tfur_users", array("tokenl" => $tokenl), $ID);
	$data["data"] = $tokenl;

	$info = $DB->info;
	$data["dberror"] = $info["error"];
	$data["dbquery"] = $info["query"];

	$response = array();
	$response["result"] = "OK";
	$response["data"] = $COM->EncryptJson($data);

	die(json_encode($response));
	//{{/NEWLOGINTOKEN}}

}

function api_uniret_get_tokens() {

	//{{GETTOKENS}}
	$COM = new Comunication();
	$DB = new DB();

	$headers = $COM->GetAllHeaders();

	$L = $headers["tokenl"];
	$R = $headers["tokenr"];
	$W = $headers["tokenw"];
	$ID = $headers["tokeni"];

	if ($L == "" || $R == "" || $W == "" || $ID == "" || $ID == 0) {
		$response = array();
		$response["result"] = "ERROR";
		die(json_encode($response));
	}

	$URuser = $DB->selectOne("tfur_users", array("id" => $ID));

	$data = array();
	$data["tokenl"] = $L;
	$data["tokenr"] = $R;
	$data["tokenw"] = $W;
	$data["data"] = $URuser->tokenl."|".$URuser->tokenr."|".$URuser->tokenw;

	$info = $DB->info;
	$data["dberror"] = $info["error"];
	$data["dbquery"] = $info["query"];

	$response = array();
	$response["result"] = "OK";
	$response["data"] = $COM->EncryptJson($data);

	die(json_encode($response));
	//{{/GETTOKENS}}

}

// Load and Save only.
function api_unirest_file_manager() 
{
	//{{FILEMANAGER}}
	$COM = new Comunication();
	$DB = new DB();

	$response = array();
	$response["result"] = "OK";
	$response["data"] = "";

	$headers = $COM->GetAllHeaders();
	$L = $headers["tokenl"];
	if ($L == "") {
		$response["result"] = "ERROR";
		$response["data"] = "NO_AUTH";
		die(json_encode($response));
	}

	$body = $COM->DecryptJsonPHPinput();

	$action = $body->action;
	$data = $body->data;
	$extra = explode("|", $body->extra);

	$userID = $extra[0];
	$fileName = $extra[1] . ".php";
	$targetFolder = $extra[2];

	/* DEPRECATED 3.4
	$tokens = $DB->selectOne("tfur_users", array("id" => $userID));
	if ($tokens->tokenl != $L) {
		$response["result"] = "ERROR";
		$response["data"] = "NO_AUTH";
		die(json_encode($response));
	}*/

	if ($targetFolder == "USER") {
		$folder = "../../../../" . $COM->GetUSERFolder($userID) . "files/";
		$DB->mkDirs($folder);
	} else {
		$folder = "../../../../" . $COM->GetGAMEFolder() . "files/";
		$DB->mkDirs($folder);
	}	

	$pInfo = pathinfo($fileName);
	$DB->mkDirs($folder . $pInfo["dirname"]);

	if ($action == "SAVE") {

		$result = file_put_contents($folder . $fileName, "<?php//" . $data);
		$response["result"] = ($result === false) ? "ERROR" : "OK";
		$response["data"] = ($result === false) ? "ERROR_FILE_SAVE" : "";

	} else if ($action == "LOAD") {

		if (file_exists($folder . $fileName)) {
			$result = file_get_contents($folder . $fileName);
			$response["result"] = ($result === false) ? "ERROR" : "OK";
			$response["data"] = ($result === false) ? "" : substr($result, 7);
		} else {
			$response["result"] = "ERROR";
			$response["data"] = "FILE_NOT_EXISTS";
		}

	} else if ($action == "DELETE") { 

		if (file_exists($folder . $fileName)) {
			$response["result"] = "OK";
			$response["data"] = (unlink($folder . $fileName)) ? "" : "FILE_NOT_DELETED";
		} else {
			$response["result"] = "OK";
			$response["data"] = "FILE_NOT_EXISTS";
		}

	} else if ($action == "LIST") {

		$folder = "../../../../";

		if ($fileName == "{USER_FILES_FOLDER}.php") $folder .= $COM->GetUSERFolder($userID) . "files/";
		if ($fileName == "{USER_UPLOADS_FOLDER}.php") $folder .= $COM->GetUSERFolder($userID) . "uploads/";
		if ($fileName == "{GAME_FILES_FOLDER}.php") $folder .= $COM->GetGAMEFolder() . "files/";
		if ($fileName == "{GAME_UPLOADS_FOLDER}.php") $folder .= $COM->GetGAMEFolder();

		$data = explode("|", $data);
		$subfolder = $data[0];

		$directory = $folder . $subfolder;

		$list = array();

		if (file_exists($folder)) {

			foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($directory)) as $filename)
			{
				if ($filename->isDir()) continue;
				
				$fname = $filename->getPathname();
				$fname = str_replace($folder, "", $fname);

				$list[]= $fname;
			}

		}

		$response["data"] = implode("|", $list);
		$response["result"] = "OK";

	}

	die(json_encode($response));
	//{{/FILEMANAGER}}

}

function api_unirest_file_manager2() 
{
	//{{FILEMANAGER2}}
	$COM = new Comunication();
	$DB = new DB();

	$response = array();
	$response["result"] = "OK";
	$response["data"] = "";

	$headers = $COM->GetAllHeaders();
	$body = $COM->DecryptJsonPHPinput();

	$tmp1 = explode("|", $body->action);
	$userID = $tmp1[0];
	$action = $tmp1[1];
	$target = $tmp1[2];

	/* DEPRECATED 3.4 16/05/2011
	$security = $DB->checkLoginToken($userID, $headers["tokenl"]);
	if (!$security) {
		$response["result"] = "ERROR";
		$response["data"] = "NO_AUTH";
		die(json_encode($response));
	}*/

	$tmp1 = explode("|", $body->extra);
	$fileName = $tmp1[0];
	$newName = $tmp1[1];

	$folder = "../../../../";
	if ($target == "UserFilesFolder") $folder .= $COM->GetUSERFolder($userID) . "files/";
	if ($target == "UserUploadsFolder") $folder .= $COM->GetUSERFolder($userID) . "uploads/";
	if ($target == "GameFilesFolder") $folder .= $COM->GetGAMEFolder() . "files/";
	if ($target == "GameUploadsFolder") $folder .= $COM->GetGAMEFolder();
	
	switch ($action) 
	{
		case "DELETE":

			if ($target == "UserFilesFolder" || $target == "GameFilesFolder") $fileName .= ".php";

			if (file_exists($folder . $fileName)) {
				$response["result"] = "OK";
				$response["data"] = (unlink($folder . $fileName)) ? "" : "FILE_NOT_DELETED";
			} else {
				$response["result"] = "OK";
				$response["data"] = "FILE_NOT_EXISTING";
			}
			break;

		case "RENAME":

			if ($target == "UserFilesFolder" || $target == "GameFilesFolder") { $fileName .= ".php"; $newName .= ".php"; }

			if (file_exists($folder . $fileName)) {
				$response["result"] = "OK";
				$response["data"] = (rename($fileName, $newName)) ? "" : "FILE_NOT_RENAMED";
			} else {
				$response["result"] = "OK";
				$response["data"] = "FILE_NOT_EXISTING";
			}
			break;

		case "EXISTS":

			if ($target == "UserFilesFolder" || $target == "GameFilesFolder") { $fileName .= ".php"; $newName .= ".php"; }

			if (file_exists($folder . $fileName)) {
				$response["result"] = "OK";
				$response["data"] = "";
			} else {
				$response["result"] = "OK";
				$response["data"] = "FILE_NOT_EXISTING";
			}
			break;

		case "SIZE":

			if ($target == "UserFilesFolder" || $target == "GameFilesFolder") { $fileName .= ".php"; $newName .= ".php"; }

			if (file_exists($folder . $fileName)) {
				$response["result"] = "OK";
				$response["data"] = filesize($folder . $fileName);
			} else {
				$response["result"] = "OK";
				$response["data"] = "FILE_NOT_EXISTING";
			}
			break;

		case "LIST":

			$directory = $folder . $fileName;
			$list = array();

			if (is_dir($directory)) {

				foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($directory)) as $filename)
				{
					if ($filename->isDir()) continue;
					
					$fname = $filename->getPathname();
					$fname = str_replace($folder, "", $fname);

					$list[]= $fname;
				}

			}

			$response["result"] = "OK";
			$response["data"] = implode("|", $list);
			break;
		
		default:
			break;
	}

	die(json_encode($response));
	//{{/FILEMANAGER2}}

}

function file_uploader() {

	//{{FILEUPLOADER}}
	$COM = new Comunication();

	$folder = $_POST["folder"];
	$code = $_POST["code"];

	$key2code = $COM->GetAppID();
	$key2code = $COM->Encrypt($key2code);
	
	if ($code == $key2code) {

		if ($folder != "") {
			$folder = "../../../../".$folder;
			if (!file_exists($folder)) mkdir($folder, 0777, true);
		}

		$total = count($_FILES['files']['name']);
		$uploadError = false;
		for ( $i = 0; $i < $total; $i++)
		{
			$tmpFilePath = $_FILES['files']['tmp_name'][$i];
			
			if ($tmpFilePath != "")
			{
				$newFilePath = $folder.$_FILES['files']['name'][$i];
				if (!move_uploaded_file($tmpFilePath, $newFilePath))
					$uploadError = true;
			}
		} 

	}	
	//{{/FILEUPLOADER}}

}

function api_unirest_synctable_read() 
{

	//{{SYNCTABLEREAD}}
	$COM = new Comunication();
	$DB = new DB();

	$body = $COM->DecryptJsonPHPinput();

	$table 		= $body->tableName;
	$user_id 	= $body->user_id;
	$token		= $body->token;

	$response = array();
	$response["has_data"] = false;
	$response["data"] = null;

	$data = $DB->selectOne($table, array("user_id" => $user_id));
	if (isset($data->token)) 
	{
		if ($data->token != $token) 
		{
			$response["has_data"] = true;
			$response["data"] = $COM->EncryptJson($data);
		}
	}	

	die(json_encode($response));
	//{{/SYNCTABLEREAD}}

}

function api_unirest_synctable_write() 
{

	//{{SYNCTABLEWRITE}}
	$COM = new Comunication();
	$DB = new DB();

	$body = $COM->DecryptJsonPHPinput();
	
	$table 		= $body->tableName;
	$user_id 	= $body->user_id;
	$s1			= $body->s1;
	$s2			= $body->s2;
	$s3			= $body->s3;
	$s4			= $body->s4;
	$s5			= $body->s5;
	$s6			= $body->s6;
	$s7			= $body->s7;
	$s8			= $body->s8;
	$s9			= $body->s9;
	$s10		= $body->s10;

	$token 		= substr(str_shuffle(rand(1000, 9999).rand(1000, 9999)."abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 10);

	$isOK = false;

	$userExists = $DB->exists($table, array("user_id" => $user_id));

	$data = array();
	if ($s1 != null) $data["s1"] = $s1;
	if ($s2 != null) $data["s2"] = $s2;
	if ($s3 != null) $data["s3"] = $s3;
	if ($s4 != null) $data["s4"] = $s4;
	if ($s5 != null) $data["s5"] = $s5;
	if ($s6 != null) $data["s6"] = $s6;
	if ($s7 != null) $data["s7"] = $s7;
	if ($s8 != null) $data["s8"] = $s8;
	if ($s9 != null) $data["s9"] = $s9;
	if ($s10 != null) $data["s10"] = $s10;
	$data["token"] = $token;

	if ($userExists)
	{
		$id = $DB->update($table, $data, array( "user_id" => $user_id ));
		$isOK = true;
	}
	else
	{
		$data["user_id"] = $user_id;
		$id = $DB->insert($table, $data);
		$isOK = $id > 0;
	}

	$response = array();
	$response["result"] = ($isOK) ? "OK" : "INVALID";
	$response["data"] = $id;

	die(json_encode($response));
	//{{/SYNCTABLEWRITE}}

}

function api_unirest_generate_otp() 
{

	//{{GENERATEOTP}}
	$COM = new Comunication();
	$DB = new DB();

	$body = $COM->DecryptJsonPHPinput();

	$username = $body->data1;
	$responseData = "";

	if ($username == "") {

		$isOK = false;
		$responseData = "INVALID";

	} else {

		$userExists = $DB->exists("tfur_users", array("username" => $username));

		if ($userExists) {

			$URuser = $DB->selectOne("tfur_users", array("username" => $username));
			$pass = $URuser->password;
			$isOK = true;
			if (strlen($pass) <= 30) {
				$isOK = false;
				$responseData = "INVALID_PASSWORD";
			} else {
				$responseData = strrev(substr($pass, 30));
			}

		} else {

			$isOK = false;
			$responseData = "CANT_FIND_USER";

		}

	}

	$response = array();
	$response["result"] = ($isOK) ? "OK" : "INVALID";
	$response["data"] = $responseData;

	die(json_encode($response));
	//{{/GENERATEOTP}}

}


?>
