<?php

class UniRESTapi {

    protected $comunication;
    protected $headers;
    protected $DB;
    protected $POST;

    public function __construct() {

        $this->comunication = new Comunication();
        $this->headers = array_change_key_case(getallheaders(), CASE_LOWER);
        $this->DB = new db();
        $this->POST = file_get_contents("php://input");

    }

    public function runAPI($unirest_db) {
        $DB = $this->DB;
        $COM = $this->comunication;

        $body = $COM->DecryptJson($this->POST);
    
        $unirest_action = $body->action;
        $extra = $body->extra;
    
        $auth = $this->authToken($unirest_action);
        if (!$auth["isAuth"]) $this->returnResponse($this->noAuthResponse($auth));
    
        $unirest_data = json_decode($body->data, true);
        $table = $unirest_db["table"];
    
        $data = array();
        $data["tokenl"] = $auth["TOKENL"];
        $data["tokenr"] = $auth["TOKENR"];
        $data["tokenw"] = $auth["TOKENW"];
        $data["data"] = "";
    
        $response = array();
    
        $unirest_action = str_replace("*", "", $unirest_action);
        switch ($unirest_action) {
    
            case "READ":
    
                if ($unirest_db["hasC"] && $unirest_db["read_custom_query"] != "") {

                    $data["data"] = $DB->execute($unirest_db["read_custom_query"], $unirest_data, "SELECT", $table);
                    
                } else {
    
                    if (!$unirest_db["hasR"]) $this->returnResponse($this->emptyResponse($data));
        
                    $what = str_replace(" ", ",", $unirest_db["read_select"]);
                    $options =  $unirest_db["read_orderby"];
                    $where = $this->createDataArray($unirest_db["read_where"], $unirest_data);

                    if ($unirest_db["read_type"] == "ONE") 
                    {
                        $data["data"] = $DB->selectOne($table, $where, $what, $options);
                    }
                    else
                    {
                        $data["data"] = $DB->select($table, $where, $what, $options);
                    }
    
                }
    
                break;
    
            case "WRITE":
    
                if ($unirest_db["hasC"] && $unirest_db["write_custom_query"] != "") {
    
                    $data["data"] = $DB->execute($unirest_db["write_custom_query"], $unirest_data, "INSERT", $table);
    
                } else {
    
                    if (!$unirest_db["hasW"]) $this->returnResponse($this->emptyResponse($data));
        
                    $newData = $this->createDataArray($unirest_db["write_fields"], $unirest_data);
                    $data["data"] = $DB->insert($table, $newData);
    
                }
                
                break;
    
            case "UPDATE":
    
                if ($unirest_db["hasC"] && $unirest_db["update_custom_query"] != "") {
    
                    $data["data"] = $DB->execute($unirest_db["update_custom_query"], $unirest_data, "UPDATE", $table);

                } else {
                
                    if (!$unirest_db["hasU"]) $this->returnResponse($this->emptyResponse($data));

                    $where = $this->createDataArray($unirest_db["update_where"], $unirest_data);

                    $exists = true;
                    if ($unirest_db["update_canWrite"]) {
                        $exists = $DB->exists($table, $where);
                    }

                    if ($exists) {
                        $fields = $this->createDataArraySelectedFields($unirest_db["update_fields"], $unirest_data, $extra);
                        $data["data"] = $DB->update($table, $fields, $where);
                    } else {
                        $fields = $this->createDataArrayExcludedFields($unirest_db["update_fields"] . " " . $unirest_db["update_where"], $unirest_data, "id");
                        $data["data"] = $DB->insert($table, $fields);
                    }
                
                }
    
                break;
    
            case "DELETE":
    
                if ($unirest_db["hasC"] && $unirest_db["delete_custom_query"] != "") {
    
                    $data["data"] = $DB->execute($unirest_db["delete_custom_query"], $unirest_data, "DELETE", $table);
    
                } else {
    
                    if (!$unirest_db["hasD"]) $this->returnResponse($this->emptyResponse($data));
        
                    $where = $this->createDataArray($unirest_db["delete_where"], $unirest_data);
                    if ($where != "") $data["data"] = $DB->delete($table, $where);
    
                }
                
                break;

            case "EXISTS":

                $where = $this->createDataArray2($extra, $unirest_data);
                if ($where != "") $data["data"] = ($DB->exists($table, $where)) ? 1 : 0;
                break;

            case "COUNT":

                $where = $this->createDataArray2($extra, $unirest_data);
                if ($where != "") $data["data"] = $DB->count($table, $where);
                break;

            case "MATH":

                $where = $this->createDataArray($unirest_db["update_where"], $unirest_data);
                $tmp = explode("|", $extra);
                if ($where != "") $data["data"] = $DB->math($table, $where, $tmp[0], $tmp[1]);
                break;

            case "UPDATEJSON":

                $where = $this->createDataArray($unirest_db["update_where"], $unirest_data);
                $tmp = explode("|", $extra, 2);
                if ($where != "") $data["data"] = $DB->updateJSON($table, $where, $tmp[0], $tmp[1]);
                break;
    
        }
        
        $data["dbquery"] = $DB->info["query"];
        $data["dberror"] = $DB->info["error"];
        $data["data"] = json_encode($data["data"]);
    
        $response["result"] = ($data["dberror"] == "") ? "OK" : "ERROR";
        $response["data"] = $COM->EncryptJson($data);
    
        $this->returnResponse($response);
    
    }

    private function returnResponse($response)
    {
        die(json_encode($response));
    }


    private function noAuthResponse($auth) 
    {
        $data = array();
        $data["dberror"] = $auth["reason"];
        $data["dbquery"] = "NO_AUTH";
        $data["data"] = "";

        $response = array();
        $response["result"] = "ERROR";
        $response["data"] = $this->comunication->EncryptJson($data);

        return $response;
    }

    private function emptyResponse($data) 
    {
        $response = array();
        $response["result"] = "ERROR";
        $response["data"] = $this->comunication->EncryptJson($data);
        return $response;
    }

    private function createDataArray($fields, $data)
    {
        if ($fields == "") return "";

        $response = array();

        $fields = explode(" ", $fields);
        foreach ($fields as $f) {
            $response[$f] = $data[$f];
        }

        return $response;
    }

    private function createDataArray2($fields, $data)
    {
        if ($fields == "") return "";

        $response = array();

        $fields = explode(" ", $fields);
        foreach ($fields as $f) {
            $field = str_replace(array("=", "!", "%", ">", "<", ">=", "<="), "", $f);
            $response[$f] = $data[$field];
        }

        return $response;
    }

    private function createDataArraySelectedFields($fields, $data, $onlyThisFields)
    {
        if ($onlyThisFields == "") return $this->createDataArray($fields, $data);

        $response = array();
        
        $onlyThisFields = explode(" ", $onlyThisFields);
        $fields = explode(" ", $fields);
        foreach ($fields as $f) {
            if (in_array($f, $onlyThisFields)) $response[$f] = $data[$f];
        }

        return $response;
    }

    private function createDataArrayExcludedFields($fields, $data, $excludeThisFields)
    {
        if ($excludeThisFields == "") return $this->createDataArray($fields, $data);

        $response = array();
        
        $excludeThisFields = explode(" ", $excludeThisFields);
        $fields = explode(" ", $fields);
        foreach ($fields as $f) {
            if (!in_array($f, $excludeThisFields)) $response[$f] = $data[$f];
        }

        return $response;
    }
    
    public function authToken($action) {
        $DB = $this->DB;

        $headers = $this->headers;
    
        $L = $headers["tokenl"];
        $R = $headers["tokenr"];
        $W = $headers["tokenw"];
        $ID = $headers["tokeni"];
    
        if ($L == "" || $R == "" || $W == "" || $ID == "" || $ID == 0) {
            $response = array();
            $response["isAuth"] = false;
            $response["reason"] = "HEADERS_DATA_MISSING:$L|$R|$W|$ID|".implode("|", $headers);
            return $response;
        }
    
        // DEPRECATED $tokens = $DB->selectOne("tfur_users", array("id" => $ID));
    
        $response = array();
        $response["isAuth"] = true;
        $response["TOKENL"] = $L;
        $response["TOKENR"] = $R;
        $response["TOKENW"] = $W;
        
        /* DEPRECATED 3.4 16/05/2022

        if ($tokens->tokenl != $L) {
            $response["isAuth"] = false;
            $response["reason"] = "L_TOKEN_ERROR: " . $tokens->tokenl . "|" . $L;
        }

        $tokenUpdate = false;
        if (substr($action, 0, 1) == "*") {
            $action = substr($action, 1);
            $tokenUpdate = true;
        }
    
        if ($action == "READ" && $tokens->tokenr != $R) {
    
            $response["isAuth"] = false;
            $response["reason"] = "R_TOKEN_ERROR: " . $tokens->tokenr . "|" . $R;
    
        } else if (($action == "WRITE" || $action == "UPDATE" || $action == "DELETE" || $action == "MATH" || $action == "UPDATEJSON") && $tokens->tokenw != $W) {
    
            $response["isAuth"] = false;
            $response["reason"] = "W_TOKEN_ERROR: " . $tokens->tokenw . "|" . $W;
    
        }
    
        if ($response["isAuth"] && $tokenUpdate)
        {
            if ($action == "READ")
            {
                $tokenr = $this->createToken("R");
                $DB->updateById("tfur_users", array("tokenr" => $tokenr), $ID);
                $response["TOKENR"] = $tokenr;
            }
            else if ($action == "WRITE" || $action == "UPDATE" || $action == "DELETE" || $action == "MATH" || $action == "UPDATEJSON")
            {
                $tokenw = $this->createToken("W");
                $DB->updateById("tfur_users", array("tokenw" => $tokenw), $ID);
                $response["TOKENW"] = $tokenw;
            }
        }*/
    
        return $response;
    
    }

    private function createToken($type)
    {
        return $type . rand(1000, 9999) . rand(1000, 9999);
    }
    
}

?>