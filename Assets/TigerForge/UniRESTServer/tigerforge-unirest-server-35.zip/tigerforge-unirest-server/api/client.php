<?php

/*
=======================================
	UniREST Client Asset APIs

	DEPRECATED 3.4 16/05/2022

=======================================
*/

// UniREST Server Keys
if ($TFUR_INSTALLED) include(ABSPATH . "UNIREST/unirest.config.php");

// ------------------------------------
//      System APIs 
// ------------------------------------

//[UNIREST_API]|unirest_server_call|server/call|unirest
function api_unirest_server_call(WP_REST_Request $request) {

	$date = new DateTime();
	$date = $date->getTimestamp();
	$code = Encrypt($date);

	$response = array();
	$response["result"] = "OK";
	$response["data"] = $code;

	return $response;

}

//[UNIREST_API]|unirest_server_connect|server/connect|unirest
function api_unirest_server_connect(WP_REST_Request $request) {

	$body = $request->get_body();

	$date = new DateTime();
	$date = $date->getTimestamp();
	
	$decoded = Decrypt($body);
	$reply = json_decode($decoded);
	$replyDate = $reply->data;

	$diff = $replyDate - $date;

	$response = array();
	$response["result"] = ($diff > 0) ? "OK" : "TIMEOUT";
	$response["data"] = "";

	return $response;

}

//[UNIREST_API]|unirest_user_login|user/login|unirest
function api_unirest_user_login(WP_REST_Request $request) {

	$body = $request->get_body();

	$decoded = Decrypt($body);
	$reply = json_decode($decoded);

	if ($reply->username == "" || $reply->password == "") {
		$isOK = false;
	} else {

		$user = selectOne("tfur_users", "username='" . $reply->username . "'");

		$isOK = ($user->password == $reply->password) ? "OK" : "ERROR";

		$data = "";
		if ($isOK == "OK") {
			
			$tokenL =  createToken("L");
			$tokenR =  createToken("R");
			$tokenW =  createToken("W");
			
			updateById(
				"tfur_users", 
				array(
					"tokenl"	=> $tokenL,
					"tokenr"	=> $tokenR,
					"tokenw"	=> $tokenW
				), 
				$user->id
			);

			$data = Encrypt("$tokenL|$tokenR|$tokenW|" . $user->id);

		}

	}

	$response = array();
	$response["result"] = $isOK;
	$response["data"] = $data;

	return $response;

}

//[UNIREST_API]|unirest_user_registration|user/registration|unirest
function api_unirest_user_registration(WP_REST_Request $request) {

	$body = DecryptJsonRequest($request);

	$username = $body->username;
	$password = $body->password;

	if ($username == "" || $password == "") {
		$isOK = false;
	} else {

		$isOK = !exists("tfur_users", "username='$username'");

		if ($isOK) {

			$id = insert("tfur_users", array("username" => $username, "password" => $password));
			$isOK = $id > 0;

		}

	}

	$response = array();
	$response["result"] = ($isOK) ? "OK" : "INVALID";
	$response["data"] = "";

	return $response;

}

//[UNIREST_API]|unirest_server_newreadtoken|unirestclientserver/newreadtoken|unirest
function api_unirest_server_newreadtoken(WP_REST_Request $request) {

	$headers = array_change_key_case(getallheaders(), CASE_LOWER);

	$L = $headers["tokenl"];
	$R = $headers["tokenr"];
	$W = $headers["tokenw"];
	$ID = $headers["tokeni"];

	if ($L == "" || $R == "" || $W == "" || $ID == "" || $ID == 0) {
		$response = array();
		$response["result"] = "ERROR";
		return $response;
	}

	$tokens = selectOne("tfur_users", "id='$ID'");

	$data = array();
	$data["tokenl"] = $L;
	$data["tokenr"] = $R;
	$data["tokenw"] = $W;
	$data["data"] = "";
	
	$tokenr = createToken("R");
	updateById("tfur_users", array("tokenr" => $tokenr), $ID);
	$data["tokenr"] = $tokenr;

	$info = getInfo();
	$data["dberror"] = $info["error"];
	$data["dbquery"] = $info["query"];

	$response = array();
	$response["result"] = "OK";
	$response["data"] = EncryptJson($data);

	return $response;

}

// ------------------------------------
//      UniREST APIs Engine 
// ------------------------------------

function apiEngine($request, $unirest_db) {

	$body = DecryptJsonRequest($request);

	$unirest_action = $body->action;

	$auth = authToken($unirest_action);
	if (!$auth["isAuth"]) {
		$response = array();
		$data["dberror"] = $auth["reason"];
		$data["dbquery"] = "NO_AUTH";
		$data["data"] = "";
		$response["result"] = "ERROR";
		$response["data"] = EncryptJson($data);
		return $response;
	}

	$unirest_data = json_decode($body->data, true);

	$data = array();
	$data["tokenl"] = $auth["TOKENL"];
	$data["tokenr"] = $auth["TOKENR"];
	$data["tokenw"] = $auth["TOKENW"];
	$data["data"] = "";

	$response = array();

	switch ($unirest_action) {

		case "READ":

			if ($unirest_db["hasC"] && $unirest_db["read_custom_query"] != "") {

				$data["data"] = queryGetResults($unirest_db["read_custom_query"], $unirest_data);
				
			} else {

				if (!$unirest_db["hasR"]) {
					$response["data"] = EncryptJson($data);
					return $response;
				}
	
				$what = str_replace(" ", ",", $unirest_db["read_select"]);
	
				$where = "";
				if ($unirest_db["read_where"] != "") {
					$a = arraysFromKeys($unirest_data, explode(" ", $unirest_db["read_where"]), "AND");
					$where = $a["query"];
				}
	
				if ($unirest_db["read_type"] == "ONE") 
				{
					$data["data"] = selectOne($unirest_db["table"], $where, $what, $unirest_db["read_orderby"]);
				}
				else
				{
					$data["data"] = select($unirest_db["table"], $where, $what, $unirest_db["read_orderby"]);
				}

			}

			break;

		case "WRITE":

			if ($unirest_db["hasC"] && $unirest_db["write_custom_query"] != "") {

				$data["data"] = queryExecute($unirest_db["write_custom_query"], $unirest_data);

			} else {

				if (!$unirest_db["hasW"]) {
					$response["data"] = EncryptJson($data);
					return $response;
				}
	
				$newData = keysRemoveUnknown($unirest_data, explode(" ", $unirest_db["write_fields"]));
				$data["data"] = insert($unirest_db["table"], $newData);

			}
			
			break;

		case "UPDATE":

			if ($unirest_db["hasC"] && $unirest_db["update_custom_query"] != "") {

				$data["data"] = queryExecute($unirest_db["update_custom_query"], $unirest_data);

			} else {
			
				if (!$unirest_db["hasU"]) {
					$response["data"] = EncryptJson($data);
					return $response;
				}
	
				$a = arraysFromKeys($unirest_data, explode(" ", $unirest_db["update_where"]), "AND");
	
				$exists = true;
				if ($unirest_db["update_canWrite"]) {
					$exists = exists($unirest_db["table"], $a["query"]);
				}
	
				if ($unirest_db["update_dynamic"]) {
					$extra = $body->extra;
					if ($extra == "") $extra = $unirest_db["update_fields"];
					if (!$exists) $extra = $extra . " " . $unirest_db["update_where"];
					$newData = keysRemoveUnknown($unirest_data, explode(" ", $extra));
				} else {
					$newData = keysRemoveUnknown($unirest_data, explode(" ", $unirest_db["update_fields"] . " " . $unirest_db["update_where"]));
				}
	
				if ($exists) {
					$data["data"] = update($unirest_db["table"], $newData, $a["assArray"]);
				} else {
					if ($unirest_db["update_canWrite"]) $data["data"] = insert($unirest_db["table"], $newData);
				}
			
			}

			break;

		case "DELETE":

			if ($unirest_db["hasC"] && $unirest_db["delete_custom_query"] != "") {

				$data["data"] = queryExecute($unirest_db["delete_custom_query"], $unirest_data);

			} else {

				if (!$unirest_db["hasD"]) {
					$response["data"] = EncryptJson(array());
					return $response;
				}
	
				$a = arraysFromKeys($unirest_data, explode(" ", $unirest_db["delete_where"]));
				$data["data"] = delete($unirest_db["table"], $a["assArray"]);

			}
			
			break;

	}
	
	$info = getInfo();
	$data["dberror"] = $info["error"];
	$data["dbquery"] = $info["query"];

	$data["data"] = json_encode($data["data"]);

	$response["result"] = ($data["dberror"] == "") ? "OK" : "ERROR";
	$response["data"] = EncryptJson($data);

	return $response;

}

// ------------------------------------
//      File Manager
// ------------------------------------

//[UNIREST_API]|unirest_file_manager|unirestclientserver/filemanager
function api_unirest_file_manager(WP_REST_Request $request) {
	global $uniREST;

	$response = array();

	$response["result"] = "OK";
	$response["data"] = "CIAO!";

	$headers = array_change_key_case(getallheaders(), CASE_LOWER);
	$L = $headers["tokenl"];
	if ($L == "") {
		$response["result"] = "ERROR";
		$response["data"] = "NO_AUTH";
		return $response;
	}

	$body = DecryptJsonRequest($request);

	$action = $body->action;
	$data = $body->data;
	$extra = explode("|", $body->extra);

	$userID = $extra[0];
	$fileName = $extra[1] . ".php";

	$tokens = selectOne("tfur_users", "id='$userID'");
	if ($tokens->tokenl != $L) {
		$response["result"] = "ERROR";
		$response["data"] = "NO_AUTH";
		return $response;
	}

	$folder = "UNIREST/" . $uniREST["Key2"] . "/";
	if (!file_exists($folder)) mkdir($folder);

	$folder .= $userID . "/";
	if (!file_exists($folder)) mkdir($folder);

	if ($action == "SAVE") {

		$result = file_put_contents($folder . $fileName, "<?php//" . $data);
		$response["result"] = ($result === false) ? "ERROR" : "OK";
		$response["data"] = ($result === false) ? "ERROR_FILE_SAVE" : "";

	} else if ($action == "LOAD") {

		if (file_exists($folder . $fileName)) {
			$result = file_get_contents($folder . $fileName);
			$response["result"] = ($result === false) ? "ERROR" : "OK";
			$response["data"] = ($result === false) ? "" : substr($result, 7);
		} else {
			$response["result"] = "ERROR";
			$response["data"] = "FILE_NOT_EXISTS";
		}

	} else if ($action == "DELETE") { 
		if (file_exists($folder . $fileName)) {
			$response["result"] = "OK";
			$response["data"] = (unlink($folder . $fileName)) ? "" : "FILE_NOT_DELETED";
		} else {
			$response["result"] = "OK";
			$response["data"] = "FILE_NOT_EXISTS";
		}
	}

	return $response;

}

// ------------------------------------
//      Encryption / Descryption 
// ------------------------------------

function Encrypt($plaintext) {
	global $uniREST;

	$encrypted = base64_encode(openssl_encrypt($plaintext, 'aes-256-cbc', $uniREST["Key1"], OPENSSL_RAW_DATA, $uniREST["Key2"]));
	return $encrypted;
}

function EncryptJson($data) {
	global $uniREST;

	$plaintext = json_encode($data);
	$encrypted = base64_encode(openssl_encrypt($plaintext, 'aes-256-cbc', $uniREST["Key1"], OPENSSL_RAW_DATA, $uniREST["Key2"]));
	return $encrypted;
}

function Decrypt($encrypted) {
	global $uniREST;

	$decrypted = openssl_decrypt(base64_decode($encrypted), 'aes-256-cbc', $uniREST["Key1"], OPENSSL_RAW_DATA, $uniREST["Key2"]);
	return $decrypted;
}

function DecryptRequest($request) {
	global $uniREST;

	$encrypted = $request->get_body();
	$decrypted = openssl_decrypt(base64_decode($encrypted), 'aes-256-cbc', $uniREST["Key1"], OPENSSL_RAW_DATA, $uniREST["Key2"]);
	return $decrypted;
}

function DecryptJsonRequest($request) {
	global $uniREST;

	$encrypted = $request->get_body();
	$decrypted = openssl_decrypt(base64_decode($encrypted), 'aes-256-cbc', $uniREST["Key1"], OPENSSL_RAW_DATA, $uniREST["Key2"]);
	return json_decode($decrypted);
}

// ------------------------------------
//      Functionalities 
// ------------------------------------

function authToken($action) {

	$headers = array_change_key_case(getallheaders(), CASE_LOWER);

	$L = $headers["tokenl"];
	$R = $headers["tokenr"];
	$W = $headers["tokenw"];
	$ID = $headers["tokeni"];

	if ($L == "" || $R == "" || $W == "" || $ID == "" || $ID == 0) {
		$response = array();
		$response["isAuth"] = false;
		$response["reason"] = "HEADERS_DATA_MISSING:$L|$R|$W|$ID|".implode("|", $headers);
		return $response;
	}

	$tokens = selectOne("tfur_users", "id='$ID'");

	$response = array();
	$response["isAuth"] = true;
	$response["TOKENL"] = $L;
	$response["TOKENR"] = $R;
	$response["TOKENW"] = $W;
	
	if ($tokens->tokenl != $L) {
		$response["isAuth"] = false;
		$response["reason"] = "L_TOKEN_ERROR: " . $tokens->tokenl . "|" . $L;
	}

	if ($action == "READ" && $tokens->tokenr != $R) {

		$response["isAuth"] = false;
		$response["reason"] = "R_TOKEN_ERROR: " . $tokens->tokenr . "|" . $R;

	} else if (($action == "WRITE" || $action == "UPDATE" || $action == "DELETE") && $tokens->tokenw != $W) {

		$response["isAuth"] = false;
		$response["reason"] = "W_TOKEN_ERROR: " . $tokens->tokenw . "|" . $W;

	}

	if ($response["isAuth"] && ($action == "WRITE" || $action == "UPDATE" || $action == "DELETE")) {

		$tokenw = createToken("W");
		updateById("tfur_users", array("tokenw" => $tokenw), $ID);
		$response["TOKENW"] = $tokenw;
	}

	return $response;

}

?>