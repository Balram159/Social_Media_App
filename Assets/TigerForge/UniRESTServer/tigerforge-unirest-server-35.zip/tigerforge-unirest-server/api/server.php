<?php

/*
=======================================
	UniREST Server Application APIs
=======================================
*/

function api_configmanage(WP_REST_Request $request) {

	$body = getData($request);
	$action = $body->action;
	$response = array();

	if ($action == "CHECK") {

		if ($GLOBALS["TFUR_INSTALLED"]) {

			$check = select("tfdb_config", "", "1", "LIMIT 1");
			$config = "";
			if ($check) {
				$config = selectOne("tfdb_config", "", "*", "LIMIT 1");
			}
			$response["exists"] = count($check) > 0;
			$response["config"] = $config;
			$response["url"] = home_url() . "/";
		} else {
			$response["exists"] = false;
			$response["config"] = "";
			$response["url"] = home_url() . "/";
		}
		

	} else if ($action == "SAVE") {

		$config = $body->config;
		update(
			"tfdb_config", 
			array(
				"key1"		=> $config->key1,
				"key2"		=> $config->key2,
				"url"		=> $config->url
			), 
			array("id" => 1)
		);

		$content = '<?php' . "\n";
		$content .= '$uniREST = array();' . "\n";
		$content .= '$uniREST["Key1"] = "' . $config->key1 . '";' . "\n";
		$content .= '$uniREST["Key2"] = "' . $config->key2 . '";' . "\n";
		$content .= '?>' . "\n";
		file_put_contents("UNIREST/unirest.config.php", $content);

		$response["status"] = "OK";

	} else if ($action == "UPGRADE_CHECK") {

		$response["execute_update"] = false;

		$col_version_exists = tableColumnExists("tfdb_config", "version");
		if (!$col_version_exists) $response["execute_update"] = true;

		$col_logindate_exists = tableColumnExists("tfur_users", "regdate");
		if (!$col_logindate_exists) $response["execute_update"] = true;


	} else if ($action == "UPGRADE_EXECUTE") {
		
		$col_version_exists = tableColumnExists("tfdb_config", "version");
		$version = str_replace(".", "", $body->version);
		if (!$col_version_exists) {
			tableColumnAdd("tfdb_config", "version", "TEXT");
			tableColumnAdd("tfdb_config", "data", "TEXT");
			update("tfdb_config", array("version" => $version), array("id" => 1));
		}

		$col_logindate_exists = tableColumnExists("tfur_users", "regdate");
		if (!$col_logindate_exists) {
			tableColumnAdd("tfur_users", "regdate", "DATETIME");
			tableColumnAdd("tfur_users", "logdate", "DATETIME");
		}

	} else if ($action == "DATA_SAVE") {

		$data = $body->data;
		$response["data_save"] = updateJSONfield("tfdb_config", "data", $data, "1");
	}
	else if ($action == "CLIENT_CONFIG_UPDATE_CHECK")
	{
		$data = readJSONfield("tfdb_config", "data", "1");
		$response["client_config_check"] = $data;

		$response["wp_tables_prefix"] = tablesPrefix();
		updateJSONfield("tfdb_config", "data", array( "wpPrefix" => $response["wp_tables_prefix"]), "1");

	}
	else if ($action == "CREATE_TEST_ACCOUNT") {

		$response["user"] = "test" . rand(1000, 9999);
		$response["pass"] = "pass" . rand(1000, 9999);

		$result = insert("tfur_users", array(
			"username"		=> $response["user"],
			"password"		=> hash("sha256", $response["pass"]),
			"tokenl"		=> "",
			"tokenr"		=> "",
			"tokenw"		=> ""
		));

		$response["status"] = ($response > 0);

	}

	return $response;
}

function api_configcreate(WP_REST_Request $request) {

	$response = array();

	if (!file_exists("UNIREST")) {
		if (!mkdir("UNIREST")) {
			$response["status"] = "NO_DIR";
			return $response;
		} else {
			$fileError = false;
			$data = '<?php' . "\n\n" . '?>' . "\n";
			if (!file_put_contents("UNIREST/unirest.api.php", $data)) $fileError = true;
			if (!file_put_contents("UNIREST/unirest.config.php", $data)) $fileError = true;
			if (!file_put_contents("UNIREST/unirest.init.php", $data)) $fileError = true;
			if ($fileError) {
				$response["status"] = "NO_FILES";
				return $response;
			}
		}
	}

	$t = tableCreate("tfdb_config", "key1 VARCHAR(32), key2 VARCHAR(16), url TEXT, version TEXT, data TEXT");

	$t = tableCreate("tfur_users", "username VARCHAR(100) NOT NULL UNIQUE, password TEXT NOT NULL, tokenl TEXT, tokenr TEXT, tokenw TEXT, regdate DATETIME, logdate DATETIME");

	$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters) - 1;
    $key1 =  "";
    $key2 =  "";
    for ($i = 0; $i < 32; $i++) {
        $key1 .= $characters[rand(0, $charactersLength)];
        $key2 .= $characters[rand(0, $charactersLength)];
	}
	$key2 = substr($key2, 0, 16);

	insert("tfdb_config", array(
		"key1"		=> $key1,
		"key2"		=> $key2,
		"version"	=> $GLOBALS["__URS_VERSION__"]
	));

	$content = '<?php' . "\n";
	$content .= '$uniREST = array();' . "\n";
	$content .= '$uniREST["Key1"] = "' . $key1 . '";' . "\n";
	$content .= '$uniREST["Key2"] = "' . $key2 . '";' . "\n";
	$content .= '?>' . "\n";
	file_put_contents("UNIREST/unirest.config.php", $content);

	$response["status"] = "OK";
	return $response;
}

function api_tablelist(WP_REST_Request $request) {

	$body = getData($request);
	$action = $body->action;

	$tableCols = null;
	$tableList = array();
	$list = tableList("tfur_", "ARRAY_N");
	foreach ($list as $table) {
		$tableList[] = $table[0];
	}

	if ($action == "LIST") {
	} else if ($action == "ALL") {

		$tableCols = array();
		foreach ($tableList as $table) {
			$tableCols[$table] = tableStructure($table);
		}

	}

	$response = array();
	$response["list"] = $tableList;
	$response["tableCols"] = $tableCols;

	return $response;

}

function api_tablecontent(WP_REST_Request $request) {

	$body = getData($request);
	$table = $body->table;
	$page = $body->page;
	$limit = $body->limit;

	$page -= 1;
	if ($page < 0) $page = 0;
	$page *= $limit;

	$response = array();
	$response["table"] = $table;
	$response["content"] = select($table, "", "*", "ORDER BY id LIMIT $page, $limit", "ARRAY_N");
	$response["structure"] = tableStructure($table);
	$response["counter"] = counter($table);

	return $response;

}

function api_tablecreate(WP_REST_Request $request) {

	$body = getData($request);

	$tableName = $body->name;
	$cols = $body->columns;

	$query = array();
	for ($i = 1; $i < count($cols); $i++) {

		$name = $cols[$i]->name;
		$type = $cols[$i]->type;
		if ($type != "TEXT" && $type != "DATETIME"  && $type != "FLOAT") $type .= "(" . $cols[$i]->size . ")";
		$null = ($cols[$i]->null) ? "" : "NOT NULL";

		$query[] = "$name $type $null";
	}

	$query = implode(", ", $query);

	$t = tableCreate("tfur_$tableName", $query);

	updateJSONfield("tfdb_config", "data", array("config_update" => getTodayDate()), "1");

	$response = array();
	$response["name"] = $name;
	$response["cols"] = $cols;
	$response["query"] = $query;
	$response["status"] = $t;
	$response["body"] = $body;
	$response["table"] = $tableName;

	return $response;

}

function api_tablerecord(WP_REST_Request $request) {

	$body = getData($request);

	$name = $body->name;
	$fields = $body->fields;
	$values = $body->values;
	$id = $body->id;
	$action = $body->action;

	$data = array();
	for ($i = 0; $i < count($fields); $i++) {
		$data[$fields[$i]] = $values[$i];
	}

	if ($action == "WRITE") {

		if ($id > 0) {
			update($name, $data, array("id" => $id));
			$action = "UPDATE";
		} else {
			$id = insert($name, $data);
			$action = "INSERT";
		}

	} else if ($action == "DELETE") {

		delete($name, array("id" => $id));

	} else if ($action == "DELETE_ALL") {

		foreach ($values as $id) delete($name, array("id" => $id));

	}

	$response = array();
	$response["status"] = ($id > 0) ? "OK" : "ERROR";
	$response["action"] = $action;

	return $response;

}

function api_tablemanage(WP_REST_Request $request) {

	$body = getData($request);

	$name = $body->name;
	$action = $body->action;
	$data = $body->data;

	if ($action == "DELETE" && $name != "") {

		deleteTable($name);

	} else if ($action == "EMPTY" && $name != "") {

		emptyTable($name);

	} else if ($action == "CHANGE") {

		$tableRename = $data->tableRename;
		$colRename = $data->colRename;
		$newOrder = $data->newOrder;
		$typeChange = $data->typeChange;
		$newColumns = $data->newColumns;

		if (count($colRename) > 0) {
			for ($i = 0; $i < count($colRename); $i++) tableColumnChange($name, $colRename[$i]->from, $colRename[$i]->to, $colRename[$i]->type);
		}

		if (count($typeChange) > 0) {
			for ($i = 0; $i < count($typeChange); $i++) tableColumnChange($name, $typeChange[$i]->from, $typeChange[$i]->from, $typeChange[$i]->type);
		}

		if (count($newColumns) > 0) {
			for ($i = 0; $i < count($newColumns); $i++) tableColumnAdd($name, $newColumns[$i]->from, $newColumns[$i]->type);
		}

		if (count($newOrder) > 0) {
			for ($i = 0; $i < count($newOrder); $i++) {
				$after = ($i == 0) ? "id" : $newOrder[$i-1]->from;
				tableColumnChange($name, $newOrder[$i]->from, $newOrder[$i]->from, $newOrder[$i]->type, "AFTER ".$after);
			}
		}

		if ($tableRename != "") tableRename($name, "tfur_".$tableRename);

	} else if ($action == "DELETECOLUMNS") {

		if (count($data) > 0) {
			for ($i = 0; $i < count($data); $i++) tableColumnDelete($name, $data[$i]->name);
		}

	} else if ($action == "ADDCOLUMNS") {

		if (count($data) > 0) {
			for ($i = 0; $i < count($data); $i++) {

				$col = $data[$i]->name;
				$type = $data[$i]->type;
				if ($type != "TEXT" && $type != "DATETIME"  && $type != "FLOAT") $type .= "(" . $data[$i]->size . ")";
				$null = ($data[$i]->null) ? "" : "NOT NULL";

				tableColumnAdd($name, $col, $type);

			}
		}
		
	}

	updateJSONfield("tfdb_config", "data", array("config_update" => getTodayDate()), "1");

	$info = getInfo();

	$response = array();
	$response["status"] = ($info["error"] == "") ? "OK" : "ERROR";
	$response["info"] = $info;
	$response["action"] = $action;	

	return $response;

}

function api_apimanage(WP_REST_Request $request) {

	$body = getData($request);
	$action = $body->action;
	$group = $body->group;

	$data = array();

	$baseUrl = (isset($group->name)) ? $group->name : "";
	
	if ($action == "SAVE") {

		$toDelete = $body->toDelete;

		$file = file("UNIREST/unirest.api.php", FILE_IGNORE_NEW_LINES);
		array_pop($file);

		foreach ($group->APIs as $API) {

			$apiUrl = $baseUrl . "/" . $API->name;
			$file = fileResetAPI($file, "//[UNIREST_API]|$apiUrl");

		}

		$apiFunction = array();
		foreach ($group->APIs as $API) {

			if (!in_array($API->name, $toDelete)) {

				$apiUrl = $baseUrl . "/" . $API->name;

				$apiFunction[] = "//[UNIREST_API]|$apiUrl";
				$apiFunction[] = "//" . $API->desc;
				$apiFunction[] = "function api_custom_" . $baseUrl . "_" . $API->name . '(WP_REST_Request $request) {';
	
				$apiFunction[] = '$unirest_db = array();';
	
				$apiFunction[] = '$unirest_db["table"] = "tfur_' . $API->selectedTable . '";';
				$apiFunction[] = '$unirest_db["hasR"] = ' .  bool($API->skills->R) .';';
				$apiFunction[] = '$unirest_db["hasW"] = ' .  bool($API->skills->W) .';';
				$apiFunction[] = '$unirest_db["hasU"] = ' .  bool($API->skills->U) .';';
				$apiFunction[] = '$unirest_db["hasD"] = ' .  bool($API->skills->D) .';';
				$apiFunction[] = '$unirest_db["hasC"] = ' .  bool($API->skills->C) .';';
	
				$apiFunction[] = '$unirest_db["read_type"] = "' . (($API->read->one) ? "ONE" : "ALL") . '";';
				$apiFunction[] = '$unirest_db["read_select"] = "' . getFieldsList($API->R, "Read", true) . '";';
				$apiFunction[] = '$unirest_db["read_where"] = "' . getFieldsList($API->R, "Key", $API->read->useID) . '";';
				$apiFunction[] = '$unirest_db["read_orderby"] = "' . orderBy($API->read->orderby, $API->read->orderdir) . '";';
				$apiFunction[] = '$unirest_db["read_custom_query"] = "' . $API->custom->R . '";';
	
				$apiFunction[] = '$unirest_db["write_fields"] = "' . getFieldsList($API->W, "Write", false) . '";';
				$apiFunction[] = '$unirest_db["write_custom_query"] = "' . $API->custom->W . '";';
	
				$apiFunction[] = '$unirest_db["update_dynamic"] = ' . bool($API->update->dynamic) . ';';
				$apiFunction[] = '$unirest_db["update_canWrite"] = ' . bool($API->update->canWrite) . ';';
				$apiFunction[] = '$unirest_db["update_fields"] = "' . getFieldsList($API->U, "Update", false) . '";';
				$apiFunction[] = '$unirest_db["update_where"] = "' . getFieldsList($API->U, "Key", $API->update->useID) . '";';
				$apiFunction[] = '$unirest_db["update_custom_query"] = "' . $API->custom->U . '";';
	
				$apiFunction[] = '$unirest_db["delete_where"] = "' . getFieldsList($API->D, "Key", $API->delete->useID) . '";';
				$apiFunction[] = '$unirest_db["delete_custom_query"] = "' . $API->custom->D . '";';

				$apiFunction[] = 'return apiEngine($request, $unirest_db);';
	
				$apiFunction[] = "}";
				$apiFunction[] = "//[/UNIREST_API]";

			}			

		}

		$file = array_merge($file, $apiFunction);

		$file[] = "?>";

		$file = prepareFileContent($file);

		file_put_contents("UNIREST/unirest.api.php", $file);


		$file = file("UNIREST/unirest.init.php", FILE_IGNORE_NEW_LINES);
		array_pop($file);

		foreach ($group->APIs as $API) {

			$apiUrl = $baseUrl . "/" . $API->name;
			$file = fileResetAPI($file, "//[UNIREST_API]|$apiUrl");

		}

		$apiFunction = array();
		foreach ($group->APIs as $API) {

			if (!in_array($API->name, $toDelete)) {
			
				$apiUrl = $baseUrl . "/" . $API->name;

				$apiFunction[] = "//[UNIREST_API]|$apiUrl";
				$apiFunction[] = 'api("custom_' . $baseUrl . "_" . $API->name . '", "' . $apiUrl .'");';
				$apiFunction[] = "//[/UNIREST_API]";
			
			}


		}

		$file = array_merge($file, $apiFunction);

		$file[] = "?>";

		$file = prepareFileContent($file);

		file_put_contents("UNIREST/unirest.init.php", $file);

	} else if ($action == "LOAD") {

		$data = file("UNIREST/unirest.api.php", FILE_IGNORE_NEW_LINES);

	} else if ($action == "LOAD_UPDATE") {

		$data = file("UNIREST/unirest.api.php", FILE_IGNORE_NEW_LINES);
		updateJSONfield("tfdb_config", "data", array("config_date" => getTodayDate()), "1");

	}else if ($action == "RENAMEAPI") {

		$gName = $group[0];
		$oldName = $group[1];
		$newName = $group[2];

		$file = file_get_contents("UNIREST/unirest.api.php");

		$file = str_replace("//[UNIREST_API]|$gName/$oldName\n", "//[UNIREST_API]|$gName/$newName\n", $file);
		$file = str_replace("api_custom_" . $gName . "_" . $oldName . "(", "api_custom_" . $gName . "_" . $newName . "(", $file);

		file_put_contents("UNIREST/unirest.api.php", $file);

		$file = file_get_contents("UNIREST/unirest.init.php");

		$file = str_replace("//[UNIREST_API]|$gName/$oldName\n", "//[UNIREST_API]|$gName/$newName\n", $file);
		$file = str_replace('api("custom_' . $gName . '_' . $oldName .'", "' . $gName . '/'. $oldName . '");', 'api("custom_' . $gName . '_' . $newName .'", "' . $gName . '/'. $newName . '");', $file);

		file_put_contents("UNIREST/unirest.init.php", $file);

	} else if ($action == "RENAMEGROUP") {

		$oldName = $group[0];
		$newName = $group[1];

		$file = file_get_contents("UNIREST/unirest.api.php");

		$file = str_replace("//[UNIREST_API]|$oldName/", "//[UNIREST_API]|$newName/", $file);
		$file = str_replace("api_custom_" . $oldName . "_", "api_custom_" . $newName . "_", $file);

		file_put_contents("UNIREST/unirest.api.php", $file);

		$file = file_get_contents("UNIREST/unirest.init.php");

		$file = str_replace("//[UNIREST_API]|$oldName/", "//[UNIREST_API]|$newName/", $file);
		$file = str_replace('"custom_' . $oldName . "_", '"custom_' . $newName . "_", $file);
		$file = str_replace('"' . $oldName . "/", '"' . $newName . "/", $file);

		file_put_contents("UNIREST/unirest.init.php", $file);

	} else if ($action == "DELETEGROUP") {

		$file = file("UNIREST/unirest.api.php", FILE_IGNORE_NEW_LINES);
		foreach ($group->APIs as $API) $file = fileResetAPI($file, "//[UNIREST_API]|".$baseUrl . "/" . $API->name);
		file_put_contents("UNIREST/unirest.api.php", prepareFileContent($file));

		$file = file("UNIREST/unirest.init.php", FILE_IGNORE_NEW_LINES);
		foreach ($group->APIs as $API) $file = fileResetAPI($file, "//[UNIREST_API]|".$baseUrl . "/" . $API->name);
		file_put_contents("UNIREST/unirest.init.php", prepareFileContent($file));

	}

	if ($action != "LOAD") updateJSONfield("tfdb_config", "data", array("config_update" => getTodayDate()), "1");

	$response = array();
	$response["status"] = "OK";
	$response["action"] = $action;
	$response["data"] = $data;

	//$response["group"] = "$gName $oldName $newName";
	//$response["file"] = $file;


	return $response;

}

function fileResetAPI($file, $string)
{
	$n = count($file);
	$index = array_search($string, $file);

	$pos[] = -1;
	$pos[] = -1;

	if ($index !== false) {
	
		$pos[0] = $index;
		$pos[1] = -1;

		for ($i = $index; $i < $n; $i++) {
			if ($file[$i] == "//[/UNIREST_API]") {
				$pos[1] = $i;
				break;
			}
		}

		if ($pos[1] > $pos[0]) {
			for ($i = $pos[0]; $i <= $pos[1]; $i++) {
				$file[$i] = "";
			}
		}

	} else {
	}

	return $file;
}

function getFieldsList($list, $type, $includeID) {

	$fields = array();

	if ($includeID) $fields[] = "id";

	foreach ($list as $l) {

		if (isset($l->value)) {
			if (strpos($l->value, $type) !== false) $fields[] = $l->field;
		}

	}

	return implode(" ", $fields);

}

function bool($value) {
	if ($value) return "true"; else return "false";
}

function orderBy($orderby, $orderdir)
{
	if ($orderby == "None") {
		return "";
	} else {
		$orderby = str_replace(" ", ",", $orderby);
		return "ORDER BY $orderby $orderdir";
	}
}

function prepareFileContent($file) {

	$newFile = array();

	foreach ($file as $f) {
		if ($f != "") $newFile[] = $f . "\n";
	}

	if (!startsWith($newFile[0], "<?php")) $newFile[0] = "<?php\n" . $newFile[0];

	return $newFile;

}

function api_apibackup(WP_REST_Request $request) {

	$body = getData($request);
	$action = $body->action;
	$type = $body->type;

	if ($action == "EXPORT") {

		$response = array();
		$response["status"] = "OK";
		$response["api"] = "";
		$response["init"] = "";
		$response["db"] = array();
		$response["action"] = $action;
		$response["type"] = $type;

		if ($type == "API" || $type == "ALL") {
			$response["api"] = file_get_contents("UNIREST/unirest.api.php");
			$response["init"] = file_get_contents("UNIREST/unirest.init.php");
		}

		if ($type == "DB" || $type == "ALL") {

			$tables = tableList("tfur_", "ARRAY_N");
			for ($i = 0; $i < count($tables); $i++) {
				$tb = $tables[$i][0];
				if ($tb != "tfur_users") $response["db"][] = tableCreationQuery($tb);
			}

		}

		return $response;

	} else if ($action == "IMPORT") {

		$response = array();
		$response["status"] = "OK";

		if ($body->api != "") file_put_contents("UNIREST/unirest.api.php", $body->api);
		if ($body->init != "") file_put_contents("UNIREST/unirest.init.php", $body->init);

		if (count($body->db) > 0) {
			for ($i = 0; $i < count($body->db); $i++) {
				$query = $body->db[$i][0][1];
				queryRun($query);
			}
		}

		return $response;

	}

}

function api_system(WP_REST_Request $request) {

	$body = getData($request);
	$action = $body->action;

	$response = array();
	$response["status"] = "OK";

	if ($action == "RESET") {

		delete_files(ABSPATH."UNIREST/");
	
		$tables = tableList("tfur_", "ARRAY_N");
		$toDelete = array();
		foreach ($tables as $t) {
			$toDelete[] = $t[0];
		}
		$tables = tableList("tfdb_", "ARRAY_N");
		foreach ($tables as $t) {
			$toDelete[] = $t[0];
		}
	
		foreach ($toDelete as $t) {
			deleteTable($t);
		}

	} else if ($action == "CHECK") {

		$response["url"] = home_url();
		$response["api"] = home_url() . "/wp-json/api/v2/";
		$response["api2"] = home_url() . "/UNIREST/api/v2/";
		$response["path"] = ABSPATH;
		$response["urpath"] = ABSPATH . "UNIREST/";
		$response["plugin"] = rtrim(plugin_dir_url(__FILE__), "api/");

		$response["folderWriteTest"] = mkdir("TEST");
		$response["fileWriteTest"] = file_put_contents("TEST/test.php", "TEST!");
		$response["fileDeleteTest"] = unlink("TEST/test.php");
		$response["folderDeleteTest"] = rmdir("TEST");
		$response["wp_version"] = get_bloginfo('version');
		$response["getallheaders"] = function_exists('getallheaders');
		$response["phpversion"] = PHP_VERSION;
		$response["phpversioncheck"] = (version_compare(PHP_VERSION, '7.4.0') >= 0);
		

	} else if ($action == "DBAPICHECK") {

		$file = file("UNIREST/unirest.api.php", FILE_IGNORE_NEW_LINES);
		$API = array();
		$DB = array();
		$code = "";
		
		$response["API"] = array();
		foreach($file as $row) {

			if (startsWith($row, "//[UNIREST_API]|")) {
				$code = str_replace("//[UNIREST_API]|", "", $row);
				$DB = array();
				$DB["url"] = $code;
			}

			if (contains($row, '["table"]')) $DB["table"] = str_replace('$unirest_db["table"] = ', '', $row);
			if (contains($row, '["hasR"]')) $DB["hasR"] = str_replace('$unirest_db["hasR"] = ', '', $row);
			if (contains($row, '["hasW"]')) $DB["hasW"] = str_replace('$unirest_db["hasW"] = ', '', $row);
			if (contains($row, '["hasU"]')) $DB["hasU"] = str_replace('$unirest_db["hasU"] = ', '', $row);
			if (contains($row, '["hasD"]')) $DB["hasD"] = str_replace('$unirest_db["hasD"] = ', '', $row);
			if (contains($row, '["hasC"]')) $DB["hasC"] = str_replace('$unirest_db["hasC"] = ', '', $row);
			if (contains($row, '["read_select"]')) $DB["read_select"] = str_replace('$unirest_db["read_select"] = ', '', $row);
			if (contains($row, '["read_where"]')) $DB["read_where"] = str_replace('$unirest_db["read_where"] = ', '', $row);
			if (contains($row, '["write_fields"]')) $DB["write_fields"] = str_replace('$unirest_db["write_fields"] = ', '', $row);
			if (contains($row, '["update_fields"]')) $DB["update_fields"] = str_replace('$unirest_db["update_fields"] = ', '', $row);
			if (contains($row, '["update_where"]')) $DB["update_where"] = str_replace('$unirest_db["update_where"] = ', '', $row);
			if (contains($row, '["delete_where"]')) $DB["delete_where"] = str_replace('$unirest_db["delete_where"] = ', '', $row);
			if (contains($row, '["read_custom_query"]')) $DB["read_custom_query"] = str_replace('$unirest_db["read_custom_query"] = ', '', $row);

			if (startsWith($row, "//[/UNIREST_API]")) {
				$response["API"][] = $DB;
			}

		}

		$list = tableList("tfur_", "ARRAY_N");
		$tableCols = array();
		foreach ($list as $table) {
			$tableCols[$table[0]] = tableStructure($table[0]);
		}
		$response["DB"] = $tableCols;

	} else if ($action == "UNIRESTAPIENGINE") {

		$config = selectOne("tfdb_config", "", "*", "LIMIT 1");
		$ae = new UniRESTApiEngine($config);
		$response["engine"] = $ae->run();

	}

	return $response;

}

function delete_files($target) {

	if (strlen($target) < 7) return;
	if (strpos($target, "UNIREST") === false) return;

	if(!is_link($target) && is_dir($target))
	{
		$files = array_diff( scandir($target), array('.', '..') );
		foreach($files as $file) {
			delete_files("$target/$file");
		}
		rmdir($target);
	}
	else
	{
		if (file_exists($target)) unlink($target);
	}

}

function api_userfilesmanage(WP_REST_Request $request) {
	global $uniREST;

	$response = array();
	$response["status"] = "OK";

	$body = getData($request);
	$action = $body->action;

	$user = null;
	if ($action == "byusername") {

		$search = $body->search;
		if ($search == "") return $response;
		$user = selectOne("tfur_users", "username='$search'", "id,username");

	} else if ($action == "byid") {

		$search = $body->search;
		if ($search == "") return $response;
		$user = selectOne("tfur_users", "id='$search'", "id,username");

	} else if ($action == "DELETE") {

		$file = $body->file;
		$userID = $body->search;

		if ($userID == 0) $target = $file; else $target = "UNIREST/" . substr($uniREST["Key2"], 4, 4) . "USER/" . $file;
		
		if (file_exists($target)) unlink($target);
		$response["target"] = $target;
	}

	if ($user != null || $body->search == "0") {

		$directory = "UNIREST/" . substr($uniREST["Key2"], 4, 4) . "USER/" . $user->id;
		if ($body->search == 0) $directory = "UNIREST/" . substr($uniREST["Key2"], 4, 4) . "GAME/";

		if (file_exists($directory)) {

			foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($directory)) as $filename)
			{
				if ($filename->isDir()) continue;
				$fname = $filename->getPathname();
				$fname = str_replace($directory . "/", "", $fname);
				$response["list"][] = $fname;
			}

		}

		$response["id"] = $user->id;
	}

	return $response;

}


?>