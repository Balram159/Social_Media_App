<?php

// ===================================================================================================
// ===================================================================================================
// ==== DATABASE HELPERS =============================================================================

function select($table, $where = "", $what = "*", $options = "", $return = "OBJECT") {
	global $wpdb; 

	$query = "SELECT $what FROM $table ";
	if ($where != "") $query .= "WHERE $where ";
	if ($options != "") $query .= $options;

	return $wpdb->get_results($query, $return);

}

function selectOne($table, $where = "", $what = "*", $options = "") {
	global $wpdb; 

	$query = "SELECT $what FROM $table ";
	if ($where != "") $query .= "WHERE $where ";
	if ($options != "") $query .= $options;

	return $wpdb->get_row($query);

}

function selectAll($table, $options = "") {
	global $wpdb; 

	$query = "SELECT * FROM $table $options";

	return $wpdb->get_results($query);
}

function insert($table, $data) {
	global $wpdb; 

	$wpdb->insert(
		$table,
		$data
	);

	return $wpdb->insert_id;
}

function insertMulti($table, $dataList) {

	$ids = array();
	$n = count($dataList);

	for ($i = 0; $i < $n; $i++) {
		$ids[] = insert($table, $dataList[$i]);
	}

	return $ids;

}

function update($table, $data, $where) {
	global $wpdb; 

	return $wpdb->update(
		$table,
		$data,
		$where
	);
}

function updateById($table, $data, $id)
{
	return update($table, $data, array( "id" => $id ));
}

function delete($table, $where) {
	global $wpdb; 

	return $wpdb->delete($table, $where);
}

function deleteTable($table) {
	global $wpdb;

    return $wpdb->query( "DROP TABLE IF EXISTS $table" );
}

function emptyTable($table) {
	global $wpdb;

    return $wpdb->query( "TRUNCATE TABLE $table" );
}


function exists($table, $where) {
	global $wpdb; 

	$count = $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE $where");
	return $count > 0;
}

function counter($table)
{
	global $wpdb; 

	$count = $wpdb->get_var("SELECT COUNT(id) FROM $table");
	return $count;
}

function tableCreate($name, $fields) 
{
	global $wpdb; 

	$sql = "CREATE TABLE $name (
		id BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		$fields
		)";

	return $wpdb->query($sql);
}

function tableCreationQuery($name)
{
	global $wpdb; 

	$sql = "SHOW CREATE TABLE $name";

	return $wpdb->get_results($sql, "ARRAY_N");
}

function tableList($name, $output = "OBJECT") 
{
	global $wpdb; 

	return $wpdb->get_results("SHOW TABLES LIKE '$name%'", $output);
}

function tableStructure($name)
{
	global $wpdb; 

	return $wpdb->get_results("DESCRIBE $name");
}

function tableRename($old, $new)
{
	global $wpdb; 

	$sql = "ALTER TABLE $old RENAME TO $new";

	return $wpdb->query($sql);
}

function tableColumnChange($name, $old, $new, $type, $after = "") 
{
	global $wpdb; 

	$sql = "ALTER TABLE $name CHANGE $old $new $type $after";

	return $wpdb->query($sql);
}

function tableColumnDelete($name, $col)
{
	global $wpdb; 

	$sql = "ALTER TABLE $name DROP $col";

	return $wpdb->query($sql);
}

function tableColumnAdd($name, $col, $type)
{
	global $wpdb; 

	$sql = "ALTER TABLE $name ADD $col $type";

	return $wpdb->query($sql);
}

function tableColumnExists($name, $col) {
	global $wpdb; 

	$row = $wpdb->get_results("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = '$name' AND column_name = '$col'");
	
	return !empty($row);
}

function updateJSONfield($table, $col, $data, $id) {
	global $wpdb; 

	$row = selectOne($table,  "id='$id'", $col);
	$colValue = $row->$col;

	if ($colValue == null) {
		$colValue = json_encode($data);
	} else {
		$colValue = json_decode($colValue);
		foreach ($data as $key => $value) { 
			$colValue->$key = $value;
		}
		$colValue = json_encode($colValue);
	}

	update($table, array($col => $colValue), array("id" => $id));

	return "OK";
}

function readJSONfield($table, $col, $id) {
	global $wpdb; 

	$row = selectOne($table,  "id='$id'", $col);
	$colValue = $row->$col;

	return $colValue;
}

function getTodayDate() {
	return date("Y-m-d H:i:s");
}

function getInfo()
{
	global $wpdb;
	$response = array();
	$response["query"] = $wpdb->last_query;
	$response["error"] = $wpdb->last_error;
	return $response;
}

function keysRemove($data, $keys) {
	foreach ($keys as $k) {
		unset($data[$k]);
	}
	unset($data["id"]);
	return $data;
}

function keysRemoveUnknown($data, $keys) {
	foreach ($data as $key => $value) {
		if (!in_array($key, $keys)) unset($data[$key]);
	}
	if (isset($data["id"])) unset($data["id"]);
	return $data;
}

function arrayExtract($data, $keys) {
	$newArray = array();
	foreach ($keys as $k) {
		$newArray[$k] = $data[$k];
	}
	return $newArray;
}

function arraysFromKeys($data, $keys, $implodeString = "") {
	
	$strArray = array();
	$assArray = array();

	foreach ($keys as $k) {

		$assArray[$k] = $data[$k];
		$strArray[] = $k . "='" . addslashes($data[$k]) . "'";

	}

	$response = array();
	$response["strArray"] = $strArray;
	$response["assArray"] = $assArray;
	$response["query"] = ($implodeString == "") ? "" : implode(" $implodeString ", $strArray);
	return $response;
}

function getUserToken($the_user)
{
	global $wpdb;
	$query = "SELECT user_pass FROM $wpdb->users WHERE user_login='$the_user'";
	$token = $wpdb->get_var($wpdb->prepare($query));

	return $token;
}

function queryGetResults($query, $data) 
{
	global $wpdb;

	$query = str_replace("[[", "tfur_", $query);
	$query = str_replace("]]", "", $query);

	foreach ($data as $key => $value) {
		$query = str_replace("{" . $key . "}", $value, $query);
	}

	return $wpdb->get_results($query);
}

function queryExecute($query, $data) 
{
	global $wpdb; 

	$query = str_replace("[[", "tfur_", $query);
	$query = str_replace("]]", "", $query);

	foreach ($data as $key => $value) {
		$query = str_replace("{" . $key . "}", $value, $query);
	}

	try {
		return $wpdb->query($query);
	} catch (Exception $e) {
		return "0";
	}
	
}

function queryRun($query) 
{
	global $wpdb; 

	return $wpdb->query($query);
	
}


function tablesPrefix() {
	global $wpdb; 

	return $wpdb->prefix;
}

?>